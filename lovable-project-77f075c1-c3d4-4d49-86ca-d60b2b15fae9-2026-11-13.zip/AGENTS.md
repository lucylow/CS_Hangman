<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- Keep the game provider and workspace in the root layout, with each screen on its own TanStack leaf route, so navigation preserves an active challenge.
- Read offline browser progress only after hydration and keep pure game rules in the feature module so SSR stays safe and scoring stays testable.
- Preserve this imported game's browser-local save rather than adding accounts or a remote data store because restoration must retain its offline behavior.
- Transfer uploaded game imagery through project-scoped asset pointers so original images resolve on this project's domains.
- Keep the Engineering Lab provider in the root layout with its own versioned browser save so navigation retains an active decision without changing classic Hangman progress.
- Score lab decisions in pure rules against authored challenges, with XP only on first clears, so repeated reviews cannot duplicate rewards.
- Render Code Workshop examples as inert text, never evaluate them, because educational snippets are not an isolated execution environment.
- Keep expansion styles token-based in a global CSS import so both new modes inherit the existing visual system.
