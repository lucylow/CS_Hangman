# CS_HANGMAN restoration
- [x] Restore the original design, five pages, question bank, and portraits.
- [x] Verify scoring tests and desktop/mobile gameplay, receipts, profile, and saved progress.
- [x] Record verification results and commit the restored app.

# V2 game improvements
- [x] Inspect the V2 archive and integrate its new game modes without losing existing progress.
- [x] Test the new rules and verify complete desktop and phone play flows.
- [x] Save the updated game and report any remaining limitations: workshop examples remain read-only, as in V2.

# V5 integration
- [ ] Import campaign, evidence workbench, academy curriculum, and synthetic demo fixtures.
- [ ] Preserve offline saves, adapt navigation and styling, and verify gameplay and academy progress.
- [ ] Record remaining limitations and commit the update.