import { createFileRoute } from "@tanstack/react-router";
import { GameScreen } from "@/features/hangman/workspace";
export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Engineer Profile | CS_HANGMAN" },
      {
        name: "description",
        content: "Manage your engineering callsign, achievements, and local career record.",
      },
      { property: "og:title", content: "Engineer Profile | CS_HANGMAN" },
      {
        property: "og:description",
        content: "Manage your engineering callsign, achievements, and local career record.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GameScreen,
});
