import { createFileRoute } from "@tanstack/react-router";
import { GameScreen } from "@/features/hangman/workspace";

// The home route ships no og:image, so serve-time hosting can inject the
// project's social preview (explicit og:image or latest screenshot).
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Command Center | CS_HANGMAN" },
      {
        name: "description",
        content: "Your engineering record, missions, and management opposition at Vantage Systems.",
      },
      { property: "og:title", content: "Command Center | CS_HANGMAN" },
      {
        property: "og:description",
        content: "Your engineering record, missions, and management opposition at Vantage Systems.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GameScreen,
});
