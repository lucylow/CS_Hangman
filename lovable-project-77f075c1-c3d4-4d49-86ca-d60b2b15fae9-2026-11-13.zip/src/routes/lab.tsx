import { createFileRoute } from "@tanstack/react-router";
import { EngineeringLab } from "@/features/engineering/lab";
export const Route = createFileRoute("/lab")({
  head: () => ({ meta: [
    { title: "Engineering Lab | CS_HANGMAN" },
    { name: "description", content: "Make practical engineering decisions across 120 scenarios and earn first-clear lab rewards at Vantage Systems." },
    { property: "og:title", content: "Engineering Lab | CS_HANGMAN" },
    { property: "og:description", content: "Make practical engineering decisions across 120 scenarios and earn first-clear lab rewards at Vantage Systems." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: EngineeringLab,
});