import { createFileRoute } from "@tanstack/react-router";
import { GameScreen } from "@/features/hangman/workspace";
export const Route = createFileRoute("/receipts")({
  head: () => ({
    meta: [
      { title: "Technical Receipts | CS_HANGMAN" },
      {
        name: "description",
        content: "Search your earned technical evidence and verified challenge achievements.",
      },
      { property: "og:title", content: "Technical Receipts | CS_HANGMAN" },
      {
        property: "og:description",
        content: "Search your earned technical evidence and verified challenge achievements.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GameScreen,
});
