import { createFileRoute } from "@tanstack/react-router";
import { CodeWorkshop } from "@/features/engineering/workshop";
export const Route = createFileRoute("/workshop")({
  head: () => ({ meta: [
    { title: "Code Workshop | CS_HANGMAN" },
    { name: "description", content: "Review 150 debugging exercises with starter implementations, acceptance checklists, and explained reference solutions." },
    { property: "og:title", content: "Code Workshop | CS_HANGMAN" },
    { property: "og:description", content: "Review 150 debugging exercises with starter implementations, acceptance checklists, and explained reference solutions." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: CodeWorkshop,
});