import { createFileRoute } from "@tanstack/react-router";
import { GameScreen } from "@/features/hangman/workspace";
export const Route = createFileRoute("/departments")({
  head: () => ({
    meta: [
      { title: "Departments | CS_HANGMAN" },
      {
        name: "description",
        content: "Explore the ten technical departments and executive floor of Vantage Systems.",
      },
      { property: "og:title", content: "Departments | CS_HANGMAN" },
      {
        property: "og:description",
        content: "Explore the ten technical departments and executive floor of Vantage Systems.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GameScreen,
});
