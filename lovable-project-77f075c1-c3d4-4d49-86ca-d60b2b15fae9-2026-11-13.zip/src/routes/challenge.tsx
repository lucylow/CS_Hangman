import { createFileRoute } from "@tanstack/react-router";
import { GameScreen } from "@/features/hangman/workspace";
export const Route = createFileRoute("/challenge")({
  head: () => ({
    meta: [
      { title: "Challenge Terminal | CS_HANGMAN" },
      {
        name: "description",
        content: "Face technical examinations across ten computer-science disciplines.",
      },
      { property: "og:title", content: "Challenge Terminal | CS_HANGMAN" },
      {
        property: "og:description",
        content: "Face technical examinations across ten computer-science disciplines.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GameScreen,
});
