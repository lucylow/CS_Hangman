import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { emptyLabProfile, loadLabProfile, recordDecision, saveLabProfile } from "./rules";
import { labChallenges } from "./data/challenges";
import type { LabChallenge } from "./types";

function useEngineeringState() {
  const [profile, setProfile] = useState(emptyLabProfile);
  const [ready, setReady] = useState(false);
  const [challenge, setChallenge] = useState<LabChallenge | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [awarded, setAwarded] = useState<number | null>(null);
  const started = useRef(0);
  const submitted = useRef(false);
  useEffect(() => { setProfile(loadLabProfile()); setReady(true); }, []);
  useEffect(() => { if (ready) saveLabProfile(profile); }, [profile, ready]);
  function begin(item: LabChallenge) {
    setChallenge(item); setSelected(null); setAwarded(null);
    started.current = performance.now(); submitted.current = false;
  }
  function submit() {
    if (!ready || !challenge || selected === null || submitted.current) return;
    submitted.current = true;
    const points = selected === challenge.correctIndex && !profile.completed.includes(challenge.id) ? challenge.points : 0;
    setAwarded(points);
    setProfile((current) => recordDecision(current, challenge, selected, labChallenges.length, Math.max(0, performance.now() - started.current)));
  }
  function clear() { setProfile(emptyLabProfile()); setChallenge(null); setAwarded(null); setSelected(null); submitted.current = false; }
  return { profile, ready, challenge, selected, setSelected, awarded, begin, submit, clear, close: () => setChallenge(null) };
}
const EngineeringContext = createContext<ReturnType<typeof useEngineeringState> | null>(null);
export function EngineeringProvider({ children }: { children: ReactNode }) {
  const value = useEngineeringState();
  return <EngineeringContext.Provider value={value}>{children}</EngineeringContext.Provider>;
}
export function useEngineering() {
  const value = useContext(EngineeringContext);
  if (!value) throw new Error("Engineering provider missing");
  return value;
}