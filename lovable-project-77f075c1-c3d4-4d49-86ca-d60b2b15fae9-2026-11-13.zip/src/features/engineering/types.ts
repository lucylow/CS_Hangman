export type Difficulty = "FOUNDATION" | "INTERMEDIATE" | "ADVANCED";
export interface LabChallenge {
  id: string; category: string; title: string; scenario: string; prompt: string;
  options: string[]; correctIndex: number; explanation: string; difficulty: Difficulty;
  points: number; skill: string; boss: string;
}
export interface LabAttempt {
  challengeId: string; selectedIndex: number; correct: boolean; points: number;
  completedAt: string; durationMs: number;
}
export interface LabProfile {
  version: number; completed: string[]; attempts: LabAttempt[]; unlockedBadges: string[];
  totalPoints: number; bestStreak: number; currentStreak: number;
}
export interface CodeExercise {
  id: string; category: string; title: string; starterCode: string; referenceSolution: string;
  task: string; acceptanceChecks: string[]; explanation: string; difficulty: Difficulty;
}