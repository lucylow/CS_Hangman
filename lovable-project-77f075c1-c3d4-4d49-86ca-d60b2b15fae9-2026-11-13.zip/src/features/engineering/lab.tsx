import { useMemo, useState, type ReactNode } from "react";
import { Activity, ArrowRight, Award, Check, ChevronLeft, CircleHelp, Lock, Search, ShieldCheck, Target, Terminal, X, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { labChallenges } from "./data/challenges";
import { useEngineering } from "./provider";
import { labAccuracy } from "./rules";

const badges = [
  ["lab-first-proof", "First decision"], ["lab-double-digits", "Ten clearances"],
  ["lab-quarter-century", "Twenty-five proofs"], ["lab-five-streak", "Five in a row"],
  ["lab-quality-engineer", "Quality engineer"], ["lab-complete", "Lab certified"],
];
export function EngineeringLab() {
  const { profile, ready, challenge, selected, setSelected, awarded, begin, submit, clear, close } = useEngineering();
  const [category, setCategory] = useState("ALL");
  const [difficulty, setDifficulty] = useState("ALL");
  const [search, setSearch] = useState("");
  const [showReset, setShowReset] = useState(false);
  const categories = useMemo(() => ["ALL", ...new Set(labChallenges.map((q) => q.category))], []);
  const filtered = useMemo(() => labChallenges.filter((q) => (category === "ALL" || q.category === category) && (difficulty === "ALL" || q.difficulty === difficulty) && `${q.title} ${q.scenario} ${q.category} ${q.skill}`.toLowerCase().includes(search.toLowerCase())), [category, difficulty, search]);
  const submitted = awarded !== null;
  function next() {
    const index = filtered.findIndex((q) => q.id === challenge?.id);
    const item = filtered[(index + 1) % filtered.length];
    if (item) begin(item); else close();
  }
  return <div className="page expansion-page">
    <div className="eyebrow"><i /> ENGINEERING DIVISION / PRACTICAL ASSESSMENT</div>
    <div className="expansion-heading"><div><h1>Engineering <em>lab.</em></h1><p>The right decision is worth more than the loudest opinion.</p></div><span><Terminal size={16} /> LAB / 02</span></div>
    <div className="expansion-metrics">
      <Metric icon={<Target size={20} />} label="COMPLETED" value={`${profile.completed.length}/120`} note="UNIQUE SCENARIOS" />
      <Metric icon={<Activity size={20} />} label="ACCURACY" value={`${labAccuracy(profile)}%`} note={`${profile.attempts.length} RECORDED ATTEMPTS`} />
      <Metric icon={<Zap size={20} />} label="LAB XP" value={profile.totalPoints.toLocaleString()} note="FIRST-CLEAR REWARDS" />
      <Metric icon={<Award size={20} />} label="BEST STREAK" value={String(profile.bestStreak)} note="CONSECUTIVE CORRECT" />
    </div>
    <div className="curriculum-progress"><div><span>CURRICULUM PROGRESS</span><b>{Math.round(profile.completed.length / 120 * 100)}%</b><Button variant="game" className="link" onClick={() => setShowReset(true)}>RESET LAB RECORD</Button></div><progress aria-label="Lab curriculum completion" value={profile.completed.length} max={120} /></div>
    {challenge ? <section className="lab-workbench" aria-label="Active scenario">
      <div className="lab-workbench-top"><Button variant="game" className="link" onClick={close}><ChevronLeft size={15} /> ALL SCENARIOS</Button><span>{challenge.category.toUpperCase()} / {challenge.difficulty}</span><span>{challenge.id.toUpperCase()}</span></div>
      <div className="lab-workbench-body"><div className="scenario-brief"><small>SCENARIO BRIEF / {challenge.skill.toUpperCase()}</small><h2>{challenge.title}</h2><p>{challenge.scenario}</p><div className="scenario-opposition"><ShieldCheck size={18} /><span>OPPOSITION<br /><b>{challenge.boss}</b></span></div></div>
        <div className="decision-question"><small>DECISION REQUIRED</small><h3>{challenge.prompt}</h3><div className="decision-options" role="group" aria-label="Decision choices">
          {challenge.options.map((option, index) => <Button variant="game" key={option} disabled={submitted} aria-pressed={selected === index} onClick={() => setSelected(index)} className={`decision-option ${selected === index ? "chosen" : ""} ${submitted && index === challenge.correctIndex ? "right" : ""} ${submitted && selected === index && index !== challenge.correctIndex ? "wrong" : ""}`}><span>{String.fromCharCode(65 + index)}</span>{option}{submitted && index === challenge.correctIndex && <Check size={16} />}{submitted && selected === index && index !== challenge.correctIndex && <X size={16} />}</Button>)}
        </div>
        {submitted && <div className={`lab-feedback ${selected === challenge.correctIndex ? "good" : "bad"}`} role="status"><b>{selected === challenge.correctIndex ? <Check size={16} /> : <X size={16} />}{selected === challenge.correctIndex ? "DECISION ACCEPTED" : "REVIEW REQUIRED"}</b><p>{challenge.explanation}</p><small>{selected !== challenge.correctIndex ? "0 LAB XP · RETRY AVAILABLE" : awarded > 0 ? `+${awarded} LAB XP · FIRST CLEAR` : "ALREADY CLEARED · NO DUPLICATE XP"}</small></div>}
        {!submitted ? <Button variant="game" className="primary" disabled={selected === null || !ready} onClick={submit}>SUBMIT DECISION <ArrowRight size={15} /></Button> : <Button variant="game" className="primary" onClick={next}>NEXT SCENARIO <ArrowRight size={15} /></Button>}
        </div></div>
    </section> : <>
      <div className="expansion-toolbar"><div className="expansion-search"><Search size={16} /><input aria-label="Search scenarios" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search scenarios, skills, categories…" /></div><select className="expansion-select" aria-label="Scenario difficulty" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}><option value="ALL">All levels</option><option value="FOUNDATION">Foundation</option><option value="INTERMEDIATE">Intermediate</option><option value="ADVANCED">Advanced</option></select></div>
      <div className="expansion-tabs" aria-label="Scenario disciplines">{categories.map((c) => <Button variant="game" key={c} aria-pressed={category === c} onClick={() => setCategory(c)}>{c === "ALL" ? "All disciplines" : c}</Button>)}</div>
      <div className="expansion-list-heading"><div><small>MISSION SELECTOR</small><h2>Practical decision bank.</h2></div><span>{filtered.length} SCENARIOS FOUND</span></div>
      {filtered.length ? <div className="scenario-grid">{filtered.map((q) => {
        const done = profile.completed.includes(q.id);
        return <Button variant="game" className={`scenario-card ${done ? "cleared" : ""}`} key={q.id} onClick={() => begin(q)} aria-label={`Open scenario: ${q.title}`}><div className="scenario-card-top"><span>{q.id.toUpperCase()}</span><span>{done ? <><Check size={12} /> CLEARED</> : "AVAILABLE"}</span></div><small>{q.category.toUpperCase()} / {q.difficulty}</small><h3>{q.title}</h3><p>{q.scenario}</p><footer><span>{q.points} XP · {profile.attempts.filter((a) => a.challengeId === q.id).length} ATTEMPTS</span><b>OPEN BRIEF <ArrowRight size={13} /></b></footer></Button>;
      })}</div> : <div className="expansion-empty"><CircleHelp size={24} /><h2>No matching scenarios.</h2><Button variant="game" className="secondary" onClick={() => { setSearch(""); setCategory("ALL"); setDifficulty("ALL"); }}>CLEAR FILTERS</Button></div>}
    </>}
    <section className="expansion-badges"><h3>Lab merit badges.</h3><div className="badge-list">{badges.map(([id, name]) => <div key={id} className={`lab-badge ${id && profile.unlockedBadges.includes(id) ? "unlocked" : ""}`}>{id && profile.unlockedBadges.includes(id) ? <Award size={17} /> : <Lock size={15} />}{name}</div>)}</div></section>
    <Dialog open={showReset} onOpenChange={setShowReset}><DialogContent className="game-dialog"><DialogTitle>Reset lab progress?</DialogTitle><DialogDescription>This removes lab XP, decisions, and badges from this browser. Your classic Hangman record stays untouched.</DialogDescription><div className="dialog-actions"><Button variant="game" className="secondary" onClick={() => setShowReset(false)}>CANCEL</Button><Button variant="game" className="danger" onClick={() => { clear(); setShowReset(false); }}>RESET LAB</Button></div></DialogContent></Dialog>
  </div>;
}
function Metric({ icon, label, value, note }: { icon: ReactNode; label: string; value: string; note: string }) {
  return <div className="expansion-metric">{icon}<small>{label}</small><strong>{value}</strong><span>{note}</span></div>;
}