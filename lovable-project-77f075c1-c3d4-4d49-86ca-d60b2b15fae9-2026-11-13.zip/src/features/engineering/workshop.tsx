import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, BookOpen, Check, ChevronDown, Code2, Copy, Eye, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { codeExercises } from "./data/code-exercises";

export function CodeWorkshop() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("ALL");
  const [difficulty, setDifficulty] = useState("ALL");
  const [activeId, setActiveId] = useState(codeExercises[0]?.id || "");
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const categories = useMemo(() => ["ALL", ...new Set(codeExercises.map((e) => e.category))], []);
  const visible = useMemo(() => codeExercises.filter((e) => (category === "ALL" || e.category === category) && (difficulty === "ALL" || e.difficulty === difficulty) && `${e.title} ${e.task} ${e.category}`.toLowerCase().includes(query.toLowerCase())), [query, category, difficulty]);
  const active = visible.find((e) => e.id === activeId) || visible[0];
  function choose(id: string) { setActiveId(id); setRevealed(false); setCopied(false); setCopyError(false); }
  function move(direction: number) {
    const index = visible.findIndex((e) => e.id === active?.id);
    const next = visible[(index + direction + visible.length) % visible.length];
    if (next) choose(next.id);
  }
  async function copy() {
    if (!active) return;
    try { await navigator.clipboard.writeText(active.referenceSolution); setCopied(true); setCopyError(false); }
    catch { setCopyError(true); }
  }
  return <div className="page expansion-page">
    <div className="eyebrow"><i /> ENGINEERING DIVISION / CODE REVIEW FLOOR</div>
    <div className="expansion-heading"><div><h1>Code <em>workshop.</em></h1><p>Broken implementations. Better judgment. A paper trail for every fix.</p></div><span><Code2 size={17} /> 150 REVIEW EXERCISES</span></div>
    <div className="workshop-layout"><aside className="workshop-library"><small><BookOpen size={14} /> EXERCISE LIBRARY / {visible.length}</small><div className="expansion-toolbar"><div className="expansion-search"><Search size={15} /><input aria-label="Search code exercises" value={query} onChange={(e) => { setQuery(e.target.value); setRevealed(false); }} placeholder="Find a bug or skill…" /></div><div className="workshop-filters"><select className="expansion-select" aria-label="Code discipline" value={category} onChange={(e) => { setCategory(e.target.value); setRevealed(false); }}>{categories.map((c) => <option key={c} value={c}>{c === "ALL" ? "All disciplines" : c}</option>)}</select><select className="expansion-select" aria-label="Code difficulty" value={difficulty} onChange={(e) => { setDifficulty(e.target.value); setRevealed(false); }}><option value="ALL">All levels</option><option value="FOUNDATION">Foundation</option><option value="INTERMEDIATE">Intermediate</option><option value="ADVANCED">Advanced</option></select></div></div>
      <div className="workshop-items">{visible.map((e, i) => <Button variant="game" key={e.id} className={e.id === active?.id ? "active" : ""} aria-current={e.id === active?.id ? "true" : undefined} onClick={() => choose(e.id)}><span>{String(i + 1).padStart(2, "0")}</span><section><b>{e.title}</b><small>{e.category} · {e.difficulty}</small></section><ArrowRight size={13} /></Button>)}</div>
    </aside>
    {active ? <section className="workshop-editor" aria-label="Code review exercise"><div className="workshop-editor-head"><div><small>{active.id.toUpperCase()} / {active.category.toUpperCase()}</small><h2>{active.title}</h2></div><span>{active.difficulty}</span></div><div className="workshop-task"><small>ENGINEERING REQUIREMENT</small><p>{active.task}</p></div>
      <div className="workshop-code-head"><span>BEFORE / STARTER IMPLEMENTATION</span><span>READ ONLY</span></div><pre className="workshop-code" tabIndex={0} aria-label="Starter implementation"><code>{active.starterCode}</code></pre>
      <div className="workshop-acceptance"><b>ACCEPTANCE CHECKLIST</b>{active.acceptanceChecks.map((c) => <div key={c}><Check size={13} />{c}</div>)}</div>
      <Button variant="game" className="workshop-reveal" aria-expanded={revealed} onClick={() => setRevealed((v) => !v)}><Eye size={15} />{revealed ? "HIDE REVIEWED SOLUTION" : "REVEAL REVIEWED SOLUTION"}<ChevronDown size={15} /></Button>
      {revealed && <div className="workshop-solution"><div className="workshop-code-head"><span>AFTER / REFERENCE SOLUTION</span><Button variant="game" title={copied ? "Solution copied" : "Copy solution"} aria-label={copied ? "Solution copied" : "Copy solution"} onClick={copy}>{copied ? <Check size={16} /> : <Copy size={16} />}</Button></div><pre className="workshop-code solution" tabIndex={0} aria-label="Reference solution"><code>{active.referenceSolution}</code></pre>{copyError && <p role="status">Copy unavailable. You can select the solution text.</p>}<div className="workshop-explanation"><b>WHY THIS FIX WORKS</b><p>{active.explanation}</p></div></div>}
      <div className="workshop-footer"><Button variant="game" className="secondary" disabled={visible.length < 2} onClick={() => move(-1)}><ArrowLeft size={14} /> PREVIOUS</Button><Button variant="game" className="secondary" disabled={visible.length < 2} onClick={() => move(1)}>NEXT EXERCISE <ArrowRight size={14} /></Button></div>
    </section> : <div className="expansion-empty"><Search size={24} /><h2>No matching exercises.</h2><Button variant="game" className="secondary" onClick={() => { setQuery(""); setCategory("ALL"); setDifficulty("ALL"); }}>CLEAR FILTERS</Button></div>}
    </div>
  </div>;
}