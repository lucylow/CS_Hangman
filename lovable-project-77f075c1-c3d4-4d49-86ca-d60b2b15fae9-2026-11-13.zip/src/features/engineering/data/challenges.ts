import type { LabChallenge } from "../types";

// Correct answer positions audited against each scenario explanation.
export const labChallenges: LabChallenge[] = [
  {
    "id": "lab-001",
    "category": "Programming",
    "title": "Variable scope",
    "scenario": "A function declares a local variable named total. Which statement best describes its visibility?",
    "prompt": "A function declares a local variable named total. Which statement best describes its visibility? Select the strongest answer.",
    "options": [
      "It is available only within that function",
      "It is global to every module",
      "It is stored permanently in the database",
      "It is visible only in CSS"
    ],
    "correctIndex": 0,
    "explanation": "Local bindings are limited by their lexical scope.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Variable scope",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-002",
    "category": "Programming",
    "title": "Pure functions",
    "scenario": "A pricing helper returns the same output for the same input and changes no external state. What property does it demonstrate?",
    "prompt": "A pricing helper returns the same output for the same input and changes no external state. What property does it demonstrate? Select the strongest answer.",
    "options": [
      "Inheritance",
      "Mutation",
      "Reflection",
      "Purity"
    ],
    "correctIndex": 3,
    "explanation": "A pure function has no observable side effects and its result depends only on its inputs.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Pure functions",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-003",
    "category": "Programming",
    "title": "Parameter versus argument",
    "scenario": "In calculateTax(rate), what is rate in the function declaration?",
    "prompt": "In calculateTax(rate), what is rate in the function declaration? Select the strongest answer.",
    "options": [
      "An exception",
      "A module",
      "A parameter",
      "A return value"
    ],
    "correctIndex": 2,
    "explanation": "A parameter is the named input slot; the supplied value at a call site is an argument.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Parameter versus argument",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-004",
    "category": "Programming",
    "title": "Boolean condition",
    "scenario": "A feature should run only when consent is true. Which type best represents that state?",
    "prompt": "A feature should run only when consent is true. Which type best represents that state? Select the strongest answer.",
    "options": [
      "Date",
      "Boolean",
      "Float",
      "Array"
    ],
    "correctIndex": 1,
    "explanation": "A Boolean represents one of two truth values.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Boolean condition",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-005",
    "category": "Programming",
    "title": "Exception handling",
    "scenario": "A file may be missing. Which construct lets a program handle that failure without crashing unexpectedly?",
    "prompt": "A file may be missing. Which construct lets a program handle that failure without crashing unexpectedly? Select the strongest answer.",
    "options": [
      "Try/catch or try/except",
      "A for loop",
      "A class decorator",
      "A CSS selector"
    ],
    "correctIndex": 0,
    "explanation": "Exception handling lets code recover from exceptional runtime conditions.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Exception handling",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-006",
    "category": "Programming",
    "title": "Recursion base case",
    "scenario": "A recursive function never stops calling itself. What essential condition is probably missing?",
    "prompt": "A recursive function never stops calling itself. What essential condition is probably missing? Select the strongest answer.",
    "options": [
      "A constructor",
      "A foreign key",
      "A callback URL",
      "A base case"
    ],
    "correctIndex": 3,
    "explanation": "A base case terminates recursion for sufficiently small inputs.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Recursion base case",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-007",
    "category": "Programming",
    "title": "Immutability",
    "scenario": "A shared configuration object should not be changed after initialization. Which design goal applies?",
    "prompt": "A shared configuration object should not be changed after initialization. Which design goal applies? Select the strongest answer.",
    "options": [
      "Overloading",
      "Serialization",
      "Immutability",
      "Polymorphism"
    ],
    "correctIndex": 2,
    "explanation": "Immutable data reduces accidental shared-state changes.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Immutability",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-008",
    "category": "Programming",
    "title": "Encapsulation",
    "scenario": "A class hides its internal fields and exposes validated methods. Which principle is this?",
    "prompt": "A class hides its internal fields and exposes validated methods. Which principle is this? Select the strongest answer.",
    "options": [
      "Sharding",
      "Encapsulation",
      "Memoization",
      "Broadcasting"
    ],
    "correctIndex": 1,
    "explanation": "Encapsulation protects internal representation behind a public interface.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Encapsulation",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-009",
    "category": "Programming",
    "title": "Composition",
    "scenario": "A report object uses a formatter object rather than inheriting from it. Which relationship is this?",
    "prompt": "A report object uses a formatter object rather than inheriting from it. Which relationship is this? Select the strongest answer.",
    "options": [
      "Composition",
      "Recursion",
      "Normalization",
      "Replication"
    ],
    "correctIndex": 0,
    "explanation": "Composition builds behavior by combining collaborating objects.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Composition",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-010",
    "category": "Programming",
    "title": "Debugging",
    "scenario": "A bug appears only for empty input. What should be added first?",
    "prompt": "A bug appears only for empty input. What should be added first? Select the strongest answer.",
    "options": [
      "A larger font",
      "A global variable",
      "A second database",
      "An empty-input test"
    ],
    "correctIndex": 3,
    "explanation": "Edge-case tests expose assumptions that ordinary examples may miss.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Debugging",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-011",
    "category": "Python",
    "title": "List append",
    "scenario": "A Python list named jobs needs one new item at its end. Which method should be called?",
    "prompt": "A Python list named jobs needs one new item at its end. Which method should be called? Select the strongest answer.",
    "options": [
      "enqueue()",
      "attach()",
      "append()",
      "push()"
    ],
    "correctIndex": 2,
    "explanation": "list.append(value) adds one element to the end of a list.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "List append",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-012",
    "category": "Python",
    "title": "Dictionary lookup",
    "scenario": "A dictionary maps employee IDs to names. Which operation retrieves the value for key 42 safely?",
    "prompt": "A dictionary maps employee IDs to names. Which operation retrieves the value for key 42 safely? Select the strongest answer.",
    "options": [
      "employees.map(42)",
      "employees.get(42)",
      "employees.append(42)",
      "employees.shift(42)"
    ],
    "correctIndex": 1,
    "explanation": "dict.get returns the value or a default without raising KeyError for a missing key.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Dictionary lookup",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-013",
    "category": "Python",
    "title": "Comprehension",
    "scenario": "You need a new list of squared values from numbers. Which construct is idiomatic?",
    "prompt": "You need a new list of squared values from numbers. Which construct is idiomatic? Select the strongest answer.",
    "options": [
      "[n*n for n in numbers]",
      "{n*n while numbers}",
      "numbers -> n*n",
      "square(numbers) as list"
    ],
    "correctIndex": 0,
    "explanation": "A list comprehension transforms each element into a new list.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Comprehension",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-014",
    "category": "Python",
    "title": "Generator",
    "scenario": "A huge stream should be processed one item at a time. Which Python feature can yield values lazily?",
    "prompt": "A huge stream should be processed one item at a time. Which Python feature can yield values lazily? Select the strongest answer.",
    "options": [
      "Tuple unpacking",
      "Metaclass",
      "Property setter",
      "Generator"
    ],
    "correctIndex": 3,
    "explanation": "Generators produce values on demand and can reduce peak memory use.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Generator",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-015",
    "category": "Python",
    "title": "Context manager",
    "scenario": "A file should close even if an exception occurs. Which syntax is preferred?",
    "prompt": "A file should close even if an exception occurs. Which syntax is preferred? Select the strongest answer.",
    "options": [
      "try file = open(path) forever",
      "defer open(path)",
      "with open(path) as file:",
      "open(path).never_close()"
    ],
    "correctIndex": 2,
    "explanation": "The with statement uses a context manager to guarantee cleanup.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Context manager",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-016",
    "category": "Python",
    "title": "Type hint",
    "scenario": "What does def add(a: int, b: int) -> int communicate?",
    "prompt": "What does def add(a: int, b: int) -> int communicate? Select the strongest answer.",
    "options": [
      "Thread priority",
      "Expected input and return types",
      "Runtime encryption",
      "Database schema"
    ],
    "correctIndex": 1,
    "explanation": "Annotations document intended types but do not enforce them by themselves.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Type hint",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-017",
    "category": "Python",
    "title": "Virtual environment",
    "scenario": "Why create a Python virtual environment per project?",
    "prompt": "Why create a Python virtual environment per project? Select the strongest answer.",
    "options": [
      "Isolate project dependencies",
      "Speed up the CPU clock",
      "Encrypt source files",
      "Replace the interpreter"
    ],
    "correctIndex": 0,
    "explanation": "Virtual environments keep dependency versions separate between projects.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Virtual environment",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-018",
    "category": "Python",
    "title": "Exception type",
    "scenario": "Which exception commonly indicates a dictionary key is absent?",
    "prompt": "Which exception commonly indicates a dictionary key is absent? Select the strongest answer.",
    "options": [
      "IndexError",
      "ZeroDivisionError",
      "StopIteration",
      "KeyError"
    ],
    "correctIndex": 3,
    "explanation": "Dictionary indexing with a missing key raises KeyError.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Exception type",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-019",
    "category": "Python",
    "title": "Async await",
    "scenario": "What does await do inside an async function?",
    "prompt": "What does await do inside an async function? Select the strongest answer.",
    "options": [
      "Converts a list to a tuple",
      "Makes code run on the GPU",
      "Suspends until an awaitable completes",
      "Starts a new operating system"
    ],
    "correctIndex": 2,
    "explanation": "await yields control while an awaitable is pending.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Async await",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-020",
    "category": "Python",
    "title": "Testing",
    "scenario": "Which standard-library module provides Python unit testing classes?",
    "prompt": "Which standard-library module provides Python unit testing classes? Select the strongest answer.",
    "options": [
      "assertions",
      "unittest",
      "pytestcore",
      "doctypes"
    ],
    "correctIndex": 1,
    "explanation": "unittest includes TestCase and test discovery; pytest is a popular third-party alternative.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Testing",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-021",
    "category": "JavaScript",
    "title": "Strict equality",
    "scenario": "What does === check in JavaScript?",
    "prompt": "What does === check in JavaScript? Select the strongest answer.",
    "options": [
      "Equality without type coercion",
      "Only object identity",
      "Whether a value is truthy",
      "Whether a variable is constant"
    ],
    "correctIndex": 0,
    "explanation": "Strict equality does not coerce operands to a common type.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Strict equality",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-022",
    "category": "JavaScript",
    "title": "Block scope",
    "scenario": "Which declaration is block-scoped and can be reassigned?",
    "prompt": "Which declaration is block-scoped and can be reassigned? Select the strongest answer.",
    "options": [
      "var",
      "function",
      "package",
      "let"
    ],
    "correctIndex": 3,
    "explanation": "let is block-scoped and allows reassignment.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Block scope",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-023",
    "category": "JavaScript",
    "title": "Promise",
    "scenario": "A network request completes later. Which abstraction represents its eventual result?",
    "prompt": "A network request completes later. Which abstraction represents its eventual result? Select the strongest answer.",
    "options": [
      "Map iterator",
      "RegExp",
      "Promise",
      "Symbol"
    ],
    "correctIndex": 2,
    "explanation": "A Promise represents an asynchronous operation that may fulfill or reject.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Promise",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-024",
    "category": "JavaScript",
    "title": "Array map",
    "scenario": "You need a transformed array with one output per input. Which method fits?",
    "prompt": "You need a transformed array with one output per input. Which method fits? Select the strongest answer.",
    "options": [
      "findIndex()",
      "map()",
      "filter()",
      "some()"
    ],
    "correctIndex": 1,
    "explanation": "map creates a new array from the callback result for each element.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Array map",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-025",
    "category": "JavaScript",
    "title": "Array filter",
    "scenario": "You need only active users from a list. Which method returns matching elements?",
    "prompt": "You need only active users from a list. Which method returns matching elements? Select the strongest answer.",
    "options": [
      "filter()",
      "reduceRight()",
      "join()",
      "flat()"
    ],
    "correctIndex": 0,
    "explanation": "filter returns a shallow copy containing elements whose callback is truthy.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Array filter",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-026",
    "category": "JavaScript",
    "title": "Closure",
    "scenario": "A callback remembers variables from the function where it was created. What is this called?",
    "prompt": "A callback remembers variables from the function where it was created. What is this called? Select the strongest answer.",
    "options": [
      "Prototype pollution",
      "Hoisting error",
      "Event capture",
      "Closure"
    ],
    "correctIndex": 3,
    "explanation": "A closure retains access to its lexical environment.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Closure",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-027",
    "category": "JavaScript",
    "title": "Event bubbling",
    "scenario": "A click on a child reaches a parent listener. Which DOM behavior is occurring?",
    "prompt": "A click on a child reaches a parent listener. Which DOM behavior is occurring? Select the strongest answer.",
    "options": [
      "Tree shaking",
      "Hydration",
      "Event bubbling",
      "Garbage collection"
    ],
    "correctIndex": 2,
    "explanation": "Bubbling propagates an event from the target toward ancestor elements.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Event bubbling",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-028",
    "category": "JavaScript",
    "title": "Optional chaining",
    "scenario": "Which operator safely accesses a possibly nullish nested property?",
    "prompt": "Which operator safely accesses a possibly nullish nested property? Select the strongest answer.",
    "options": [
      "=>",
      "?.",
      "!!",
      "??="
    ],
    "correctIndex": 1,
    "explanation": "Optional chaining short-circuits when the left side is null or undefined.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Optional chaining",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-029",
    "category": "JavaScript",
    "title": "Nullish coalescing",
    "scenario": "Which operator uses a fallback only for null or undefined?",
    "prompt": "Which operator uses a fallback only for null or undefined? Select the strongest answer.",
    "options": [
      "??",
      "||",
      "&&",
      "=="
    ],
    "correctIndex": 0,
    "explanation": "Nullish coalescing preserves valid falsy values such as 0 and empty string.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Nullish coalescing",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-030",
    "category": "JavaScript",
    "title": "Module export",
    "scenario": "Which syntax exposes a named binding from an ES module?",
    "prompt": "Which syntax exposes a named binding from an ES module? Select the strongest answer.",
    "options": [
      "publish",
      "module.show",
      "include",
      "export"
    ],
    "correctIndex": 3,
    "explanation": "ES modules use export and import for explicit module interfaces.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Module export",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-031",
    "category": "Algorithms",
    "title": "Binary search",
    "scenario": "A sorted array is searched by repeatedly halving the remaining range. What is its time complexity?",
    "prompt": "A sorted array is searched by repeatedly halving the remaining range. What is its time complexity? Select the strongest answer.",
    "options": [
      "O(n log n)",
      "O(n\u00b2)",
      "O(log n)",
      "O(n)"
    ],
    "correctIndex": 2,
    "explanation": "Binary search discards half the search interval each step.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Binary search",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-032",
    "category": "Algorithms",
    "title": "Linear scan",
    "scenario": "An unsorted list is checked item by item. What is the worst-case time complexity?",
    "prompt": "An unsorted list is checked item by item. What is the worst-case time complexity? Select the strongest answer.",
    "options": [
      "O(n log n)",
      "O(n)",
      "O(1)",
      "O(log n)"
    ],
    "correctIndex": 1,
    "explanation": "In the worst case every element is inspected once.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Linear scan",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-033",
    "category": "Algorithms",
    "title": "Stable sorting",
    "scenario": "A sort preserves the original order of equal-key records. What property is this?",
    "prompt": "A sort preserves the original order of equal-key records. What property is this? Select the strongest answer.",
    "options": [
      "Stability",
      "Completeness",
      "Idempotence",
      "Associativity"
    ],
    "correctIndex": 0,
    "explanation": "A stable sort does not reorder equal-key elements relative to each other.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Stable sorting",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-034",
    "category": "Algorithms",
    "title": "Breadth-first search",
    "scenario": "An unweighted graph shortest path is needed. Which traversal explores by distance layers?",
    "prompt": "An unweighted graph shortest path is needed. Which traversal explores by distance layers? Select the strongest answer.",
    "options": [
      "Depth-first search",
      "Quickselect",
      "Heapify",
      "Breadth-first search"
    ],
    "correctIndex": 3,
    "explanation": "BFS explores vertices in increasing edge distance from the source.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Breadth-first search",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-035",
    "category": "Algorithms",
    "title": "Depth-first search",
    "scenario": "Which traversal follows a path deeply before backtracking?",
    "prompt": "Which traversal follows a path deeply before backtracking? Select the strongest answer.",
    "options": [
      "Counting sort",
      "Binary search",
      "Depth-first search",
      "Breadth-first search"
    ],
    "correctIndex": 2,
    "explanation": "DFS explores a branch until it cannot continue, then backtracks.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Depth-first search",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-036",
    "category": "Algorithms",
    "title": "Dynamic programming",
    "scenario": "Overlapping subproblems and optimal substructure suggest which technique?",
    "prompt": "Overlapping subproblems and optimal substructure suggest which technique? Select the strongest answer.",
    "options": [
      "Linear probing",
      "Dynamic programming",
      "Randomized hashing",
      "Busy waiting"
    ],
    "correctIndex": 1,
    "explanation": "Dynamic programming stores subproblem results to avoid repeated work.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Dynamic programming",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-037",
    "category": "Algorithms",
    "title": "Memoization",
    "scenario": "A recursive function caches previously computed inputs. What technique is used?",
    "prompt": "A recursive function caches previously computed inputs. What technique is used? Select the strongest answer.",
    "options": [
      "Memoization",
      "Sharding",
      "Pipelining",
      "Normalization"
    ],
    "correctIndex": 0,
    "explanation": "Memoization is caching function results keyed by their inputs.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Memoization",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-038",
    "category": "Algorithms",
    "title": "Heap",
    "scenario": "A priority queue needs fast access to its smallest item. Which structure is commonly used?",
    "prompt": "A priority queue needs fast access to its smallest item. Which structure is commonly used? Select the strongest answer.",
    "options": [
      "Stack",
      "Linked list",
      "Trie",
      "Min-heap"
    ],
    "correctIndex": 3,
    "explanation": "A min-heap keeps the smallest key at the root.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Heap",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-039",
    "category": "Algorithms",
    "title": "Hash collision",
    "scenario": "Two keys map to the same hash-table slot. What has occurred?",
    "prompt": "Two keys map to the same hash-table slot. What has occurred? Select the strongest answer.",
    "options": [
      "Overflow",
      "Underflow",
      "Collision",
      "Deadlock"
    ],
    "correctIndex": 2,
    "explanation": "Hash collisions are handled with strategies such as chaining or open addressing.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Hash collision",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-040",
    "category": "Algorithms",
    "title": "Recurrence",
    "scenario": "Merge sort divides input and merges sorted halves. What is its typical time complexity?",
    "prompt": "Merge sort divides input and merges sorted halves. What is its typical time complexity? Select the strongest answer.",
    "options": [
      "O(1)",
      "O(n log n)",
      "O(n\u00b2)",
      "O(log n)"
    ],
    "correctIndex": 1,
    "explanation": "The recurrence T(n)=2T(n/2)+O(n) yields O(n log n).",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Recurrence",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-041",
    "category": "Databases",
    "title": "Primary key",
    "scenario": "Which column constraint uniquely identifies each row in a table?",
    "prompt": "Which column constraint uniquely identifies each row in a table? Select the strongest answer.",
    "options": [
      "PRIMARY KEY",
      "FOREIGN KEY",
      "CHECK",
      "DEFAULT"
    ],
    "correctIndex": 0,
    "explanation": "A primary key enforces unique, non-null row identity.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Primary key",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-042",
    "category": "Databases",
    "title": "Foreign key",
    "scenario": "Which constraint references a candidate or primary key in another table?",
    "prompt": "Which constraint references a candidate or primary key in another table? Select the strongest answer.",
    "options": [
      "UNIQUE INDEX",
      "TRIGGER",
      "VIEW",
      "FOREIGN KEY"
    ],
    "correctIndex": 3,
    "explanation": "A foreign key enforces referential integrity between related tables.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Foreign key",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-043",
    "category": "Databases",
    "title": "Join",
    "scenario": "You need columns from matching rows in two tables. Which SQL operation is used?",
    "prompt": "You need columns from matching rows in two tables. Which SQL operation is used? Select the strongest answer.",
    "options": [
      "ORDER BY",
      "LIMIT",
      "JOIN",
      "GROUP BY"
    ],
    "correctIndex": 2,
    "explanation": "JOIN combines rows based on a related-column condition.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Join",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-044",
    "category": "Databases",
    "title": "Transaction atomicity",
    "scenario": "A transaction either fully succeeds or has no effect. Which ACID property is this?",
    "prompt": "A transaction either fully succeeds or has no effect. Which ACID property is this? Select the strongest answer.",
    "options": [
      "Durability",
      "Atomicity",
      "Consistency",
      "Isolation"
    ],
    "correctIndex": 1,
    "explanation": "Atomicity makes a transaction all-or-nothing.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Transaction atomicity",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-045",
    "category": "Databases",
    "title": "Index tradeoff",
    "scenario": "Why can adding many indexes slow down writes?",
    "prompt": "Why can adding many indexes slow down writes? Select the strongest answer.",
    "options": [
      "Each affected index must also be maintained",
      "Indexes disable transactions",
      "Indexes remove primary keys",
      "Indexes force table scans"
    ],
    "correctIndex": 0,
    "explanation": "Insert, update, and delete operations may need to update every relevant index.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Index tradeoff",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-046",
    "category": "Databases",
    "title": "Normalization",
    "scenario": "What is a key goal of relational normalization?",
    "prompt": "What is a key goal of relational normalization? Select the strongest answer.",
    "options": [
      "Encrypt every row",
      "Eliminate all joins",
      "Store every value as JSON",
      "Reduce redundancy and update anomalies"
    ],
    "correctIndex": 3,
    "explanation": "Normalization organizes relations to reduce duplication and anomalies.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Normalization",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-047",
    "category": "Databases",
    "title": "Isolation",
    "scenario": "Which ACID property governs how concurrent transactions see each other?",
    "prompt": "Which ACID property governs how concurrent transactions see each other? Select the strongest answer.",
    "options": [
      "Atomicity",
      "Consistency",
      "Isolation",
      "Durability"
    ],
    "correctIndex": 2,
    "explanation": "Isolation controls concurrency effects between transactions.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Isolation",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-048",
    "category": "Databases",
    "title": "Migration",
    "scenario": "A version-controlled change to database schema is commonly called what?",
    "prompt": "A version-controlled change to database schema is commonly called what? Select the strongest answer.",
    "options": [
      "Replica",
      "Migration",
      "Snapshot",
      "Cursor"
    ],
    "correctIndex": 1,
    "explanation": "Migrations make schema changes repeatable and trackable.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Migration",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-049",
    "category": "Databases",
    "title": "Parameterized query",
    "scenario": "What is the main benefit of parameterized SQL queries?",
    "prompt": "What is the main benefit of parameterized SQL queries? Select the strongest answer.",
    "options": [
      "Separate data from SQL syntax to prevent injection",
      "Automatically shard the database",
      "Compress result rows",
      "Avoid all query planning"
    ],
    "correctIndex": 0,
    "explanation": "Parameters prevent untrusted input from being interpreted as SQL code.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Parameterized query",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-050",
    "category": "Databases",
    "title": "Explain plan",
    "scenario": "Which SQL command family helps inspect how a query will execute?",
    "prompt": "Which SQL command family helps inspect how a query will execute? Select the strongest answer.",
    "options": [
      "DESCRIBE USER",
      "SHOW PROCESS",
      "ANALYZE TABLE ONLY",
      "EXPLAIN"
    ],
    "correctIndex": 3,
    "explanation": "EXPLAIN displays the query plan; ANALYZE can collect execution statistics.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Explain plan",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-051",
    "category": "Networking",
    "title": "DNS",
    "scenario": "Which service resolves a domain name to an IP address?",
    "prompt": "Which service resolves a domain name to an IP address? Select the strongest answer.",
    "options": [
      "NTP",
      "SMTP",
      "DNS",
      "DHCP"
    ],
    "correctIndex": 2,
    "explanation": "DNS maps domain names to records such as IP addresses.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "DNS",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-052",
    "category": "Networking",
    "title": "TCP",
    "scenario": "Which transport protocol provides ordered, reliable byte-stream delivery?",
    "prompt": "Which transport protocol provides ordered, reliable byte-stream delivery? Select the strongest answer.",
    "options": [
      "ARP",
      "TCP",
      "UDP",
      "ICMP"
    ],
    "correctIndex": 1,
    "explanation": "TCP provides connection-oriented reliable delivery with sequencing and retransmission.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "TCP",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-053",
    "category": "Networking",
    "title": "UDP",
    "scenario": "A real-time voice app prefers low overhead and can tolerate some packet loss. Which transport may fit?",
    "prompt": "A real-time voice app prefers low overhead and can tolerate some packet loss. Which transport may fit? Select the strongest answer.",
    "options": [
      "UDP",
      "TCP only",
      "FTP",
      "SSH"
    ],
    "correctIndex": 0,
    "explanation": "UDP avoids TCP connection and retransmission semantics, leaving recovery to the application.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "UDP",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-054",
    "category": "Networking",
    "title": "HTTP status",
    "scenario": "Which status code indicates a successful resource creation?",
    "prompt": "Which status code indicates a successful resource creation? Select the strongest answer.",
    "options": [
      "301",
      "401",
      "500",
      "201"
    ],
    "correctIndex": 3,
    "explanation": "201 Created indicates that the request created a resource.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "HTTP status",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-055",
    "category": "Networking",
    "title": "TLS",
    "scenario": "What does TLS primarily provide for network connections?",
    "prompt": "What does TLS primarily provide for network connections? Select the strongest answer.",
    "options": [
      "Packet routing",
      "Load balancing",
      "Encryption and authenticated integrity",
      "IP address assignment"
    ],
    "correctIndex": 2,
    "explanation": "TLS protects data in transit and authenticates the server through certificates.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "TLS",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-056",
    "category": "Networking",
    "title": "Subnet",
    "scenario": "What does a subnet mask help determine?",
    "prompt": "What does a subnet mask help determine? Select the strongest answer.",
    "options": [
      "The Wi-Fi password",
      "Which IP bits identify the network portion",
      "The DNS provider",
      "The TCP window size"
    ],
    "correctIndex": 1,
    "explanation": "A subnet mask separates network and host portions of an IP address.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Subnet",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-057",
    "category": "Networking",
    "title": "Load balancer",
    "scenario": "What component distributes incoming requests across multiple servers?",
    "prompt": "What component distributes incoming requests across multiple servers? Select the strongest answer.",
    "options": [
      "Load balancer",
      "Compiler",
      "Message serializer",
      "Cache invalidator"
    ],
    "correctIndex": 0,
    "explanation": "Load balancers spread traffic and can improve availability.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Load balancer",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-058",
    "category": "Networking",
    "title": "WebSocket",
    "scenario": "Which protocol enables a persistent bidirectional browser-server channel?",
    "prompt": "Which protocol enables a persistent bidirectional browser-server channel? Select the strongest answer.",
    "options": [
      "SMTP",
      "POP3",
      "TFTP",
      "WebSocket"
    ],
    "correctIndex": 3,
    "explanation": "WebSocket supports full-duplex communication over a single connection.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "WebSocket",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-059",
    "category": "Networking",
    "title": "CDN",
    "scenario": "What is a content delivery network designed to do?",
    "prompt": "What is a content delivery network designed to do? Select the strongest answer.",
    "options": [
      "Replace DNS records with SQL",
      "Encrypt database backups only",
      "Serve content from geographically distributed edge locations",
      "Compile JavaScript on the server"
    ],
    "correctIndex": 2,
    "explanation": "A CDN caches and serves content closer to users.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "CDN",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-060",
    "category": "Networking",
    "title": "Rate limiting",
    "scenario": "Which control limits how many requests a client can make in a time window?",
    "prompt": "Which control limits how many requests a client can make in a time window? Select the strongest answer.",
    "options": [
      "Sharding",
      "Rate limiting",
      "Connection pooling",
      "Compression"
    ],
    "correctIndex": 1,
    "explanation": "Rate limits protect services from abuse and unexpected traffic spikes.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Rate limiting",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-061",
    "category": "Cybersecurity",
    "title": "Least privilege",
    "scenario": "A service account should access only the resources it needs. Which principle applies?",
    "prompt": "A service account should access only the resources it needs. Which principle applies? Select the strongest answer.",
    "options": [
      "Least privilege",
      "Open access",
      "Fail open",
      "Security by obscurity"
    ],
    "correctIndex": 0,
    "explanation": "Least privilege minimizes the impact of compromised identities.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Least privilege",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-062",
    "category": "Cybersecurity",
    "title": "SQL injection",
    "scenario": "Untrusted input is concatenated into a SQL string. What vulnerability may result?",
    "prompt": "Untrusted input is concatenated into a SQL string. What vulnerability may result? Select the strongest answer.",
    "options": [
      "Cross-site request forgery",
      "DNS rebinding",
      "Clickjacking",
      "SQL injection"
    ],
    "correctIndex": 3,
    "explanation": "Attackers may alter query structure when input is treated as SQL syntax.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "SQL injection",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-063",
    "category": "Cybersecurity",
    "title": "XSS",
    "scenario": "Untrusted content is rendered as executable script in a browser. What is this?",
    "prompt": "Untrusted content is rendered as executable script in a browser. What is this? Select the strongest answer.",
    "options": [
      "SSRF",
      "Directory traversal",
      "Cross-site scripting",
      "SQL injection"
    ],
    "correctIndex": 2,
    "explanation": "XSS occurs when attacker-controlled content executes in another user\u2019s browser.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "XSS",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-064",
    "category": "Cybersecurity",
    "title": "MFA",
    "scenario": "Which control requires two or more independent authentication factors?",
    "prompt": "Which control requires two or more independent authentication factors? Select the strongest answer.",
    "options": [
      "Network address translation",
      "Multi-factor authentication",
      "Single sign-on",
      "Password hashing"
    ],
    "correctIndex": 1,
    "explanation": "MFA combines factors such as knowledge, possession, or inherence.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "MFA",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-065",
    "category": "Cybersecurity",
    "title": "Password storage",
    "scenario": "How should application passwords generally be stored?",
    "prompt": "How should application passwords generally be stored? Select the strongest answer.",
    "options": [
      "Salted, slow password hashes",
      "Reversible encryption with a shared key",
      "Plain text in a database",
      "Base64 encoding"
    ],
    "correctIndex": 0,
    "explanation": "Use dedicated password hashing algorithms such as Argon2id, scrypt, or bcrypt.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Password storage",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-066",
    "category": "Cybersecurity",
    "title": "CSRF",
    "scenario": "A browser is tricked into sending an unwanted authenticated request. Which attack is this?",
    "prompt": "A browser is tricked into sending an unwanted authenticated request. Which attack is this? Select the strongest answer.",
    "options": [
      "Cross-site scripting",
      "Buffer overflow",
      "Race condition",
      "Cross-site request forgery"
    ],
    "correctIndex": 3,
    "explanation": "CSRF abuses ambient browser credentials to induce state-changing requests.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "CSRF",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-067",
    "category": "Cybersecurity",
    "title": "Secrets management",
    "scenario": "Where should production API keys be stored?",
    "prompt": "Where should production API keys be stored? Select the strongest answer.",
    "options": [
      "A client-side JavaScript bundle",
      "A screenshot in the wiki",
      "A managed secret store or protected environment configuration",
      "A public Git repository"
    ],
    "correctIndex": 2,
    "explanation": "Secrets should be access-controlled, rotated, and excluded from source control.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Secrets management",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-068",
    "category": "Cybersecurity",
    "title": "Patch management",
    "scenario": "Why apply security updates promptly?",
    "prompt": "Why apply security updates promptly? Select the strongest answer.",
    "options": [
      "They disable authentication",
      "They remediate known vulnerabilities",
      "They guarantee zero bugs",
      "They remove need for backups"
    ],
    "correctIndex": 1,
    "explanation": "Updates often fix publicly known weaknesses that attackers may exploit.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Patch management",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-069",
    "category": "Cybersecurity",
    "title": "Threat modeling",
    "scenario": "What is the purpose of threat modeling?",
    "prompt": "What is the purpose of threat modeling? Select the strongest answer.",
    "options": [
      "Identify assets, threats, trust boundaries, and mitigations",
      "Benchmark CSS rendering",
      "Generate user passwords",
      "Replace penetration testing entirely"
    ],
    "correctIndex": 0,
    "explanation": "Threat modeling helps prioritize security controls before and during development.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Threat modeling",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-070",
    "category": "Cybersecurity",
    "title": "Incident response",
    "scenario": "What should happen early in a suspected security incident?",
    "prompt": "What should happen early in a suspected security incident? Select the strongest answer.",
    "options": [
      "Delete all logs immediately",
      "Post credentials in chat",
      "Reboot every system without coordination",
      "Follow the incident plan and preserve evidence"
    ],
    "correctIndex": 3,
    "explanation": "A coordinated response preserves evidence and limits impact while avoiding destructive improvisation.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Incident response",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-071",
    "category": "AI / ML",
    "title": "Training data",
    "scenario": "What is the dataset used to fit model parameters called?",
    "prompt": "What is the dataset used to fit model parameters called? Select the strongest answer.",
    "options": [
      "Feature flag",
      "Serving queue",
      "Training dataset",
      "Inference cache"
    ],
    "correctIndex": 2,
    "explanation": "Training data provides examples from which model parameters are learned.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Training data",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-072",
    "category": "AI / ML",
    "title": "Inference",
    "scenario": "A trained model predicts an output for a new input. What is this process?",
    "prompt": "A trained model predicts an output for a new input. What is this process? Select the strongest answer.",
    "options": [
      "Tokenization only",
      "Inference",
      "Backpropagation",
      "Normalization"
    ],
    "correctIndex": 1,
    "explanation": "Inference applies a trained model to new inputs.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Inference",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-073",
    "category": "AI / ML",
    "title": "Overfitting",
    "scenario": "A model performs well on training data but poorly on unseen data. What is this?",
    "prompt": "A model performs well on training data but poorly on unseen data. What is this? Select the strongest answer.",
    "options": [
      "Overfitting",
      "Underflow",
      "Sharding",
      "Quantization"
    ],
    "correctIndex": 0,
    "explanation": "Overfitting means the model has learned training-specific patterns that do not generalize.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Overfitting",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-074",
    "category": "AI / ML",
    "title": "Validation set",
    "scenario": "Which dataset is commonly used to tune hyperparameters during development?",
    "prompt": "Which dataset is commonly used to tune hyperparameters during development? Select the strongest answer.",
    "options": [
      "Production secrets",
      "Compiler cache",
      "Schema registry",
      "Validation set"
    ],
    "correctIndex": 3,
    "explanation": "Validation data guides model selection without being used for gradient updates.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Validation set",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-075",
    "category": "AI / ML",
    "title": "Gradient descent",
    "scenario": "Which optimization method updates parameters using the loss gradient?",
    "prompt": "Which optimization method updates parameters using the loss gradient? Select the strongest answer.",
    "options": [
      "K-means assignment only",
      "Binary search",
      "Gradient descent",
      "Breadth-first search"
    ],
    "correctIndex": 2,
    "explanation": "Gradient descent moves parameters in a direction that reduces the objective.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Gradient descent",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-076",
    "category": "AI / ML",
    "title": "Embedding",
    "scenario": "What is an embedding in machine learning?",
    "prompt": "What is an embedding in machine learning? Select the strongest answer.",
    "options": [
      "A source map",
      "A dense vector representation of an item",
      "A database transaction",
      "A network firewall rule"
    ],
    "correctIndex": 1,
    "explanation": "Embeddings encode semantic or structural information as numeric vectors.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Embedding",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-077",
    "category": "AI / ML",
    "title": "Transformer",
    "scenario": "Which architecture uses self-attention as a central mechanism?",
    "prompt": "Which architecture uses self-attention as a central mechanism? Select the strongest answer.",
    "options": [
      "Transformer",
      "Decision stump",
      "Linked list",
      "Convolution-only perceptron"
    ],
    "correctIndex": 0,
    "explanation": "Transformers use attention mechanisms to model relationships among tokens.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Transformer",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-078",
    "category": "AI / ML",
    "title": "RAG",
    "scenario": "What does retrieval-augmented generation combine?",
    "prompt": "What does retrieval-augmented generation combine? Select the strongest answer.",
    "options": [
      "Image compression with encryption",
      "SQL joins with CSS",
      "Compiler optimization with routing",
      "External retrieval with generative model output"
    ],
    "correctIndex": 3,
    "explanation": "RAG retrieves relevant context and supplies it to a generative model.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "RAG",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-079",
    "category": "AI / ML",
    "title": "Precision",
    "scenario": "In binary classification, precision measures what?",
    "prompt": "In binary classification, precision measures what? Select the strongest answer.",
    "options": [
      "Overall number of samples",
      "Average training time",
      "Fraction of predicted positives that are true positives",
      "Fraction of actual positives found"
    ],
    "correctIndex": 2,
    "explanation": "Precision = TP / (TP + FP).",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Precision",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-080",
    "category": "AI / ML",
    "title": "Data leakage",
    "scenario": "A feature includes information unavailable at prediction time. What problem is this?",
    "prompt": "A feature includes information unavailable at prediction time. What problem is this? Select the strongest answer.",
    "options": [
      "Model distillation",
      "Data leakage",
      "Gradient clipping",
      "Batch normalization"
    ],
    "correctIndex": 1,
    "explanation": "Leakage gives a model access to information that would not legitimately exist at prediction time.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Data leakage",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-081",
    "category": "System Design",
    "title": "Horizontal scaling",
    "scenario": "Adding more application instances is which scaling approach?",
    "prompt": "Adding more application instances is which scaling approach? Select the strongest answer.",
    "options": [
      "Horizontal scaling",
      "Vertical scaling",
      "Denormalization",
      "Code splitting"
    ],
    "correctIndex": 0,
    "explanation": "Horizontal scaling adds machines or instances to share load.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Horizontal scaling",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-082",
    "category": "System Design",
    "title": "Caching",
    "scenario": "Frequently requested read data is stored closer to the application. What technique is this?",
    "prompt": "Frequently requested read data is stored closer to the application. What technique is this? Select the strongest answer.",
    "options": [
      "Sharding",
      "Dead lettering",
      "Serialization",
      "Caching"
    ],
    "correctIndex": 3,
    "explanation": "Caching reduces repeated expensive work at the cost of freshness and invalidation complexity.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Caching",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-083",
    "category": "System Design",
    "title": "Queue",
    "scenario": "A system needs to decouple request intake from background processing. What component helps?",
    "prompt": "A system needs to decouple request intake from background processing. What component helps? Select the strongest answer.",
    "options": [
      "Primary key",
      "Compiler",
      "Message queue",
      "CSS grid"
    ],
    "correctIndex": 2,
    "explanation": "A queue buffers work and decouples producers from consumers.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Queue",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-084",
    "category": "System Design",
    "title": "Idempotency",
    "scenario": "Repeating the same request should not create duplicate payments. Which property is needed?",
    "prompt": "Repeating the same request should not create duplicate payments. Which property is needed? Select the strongest answer.",
    "options": [
      "Compression",
      "Idempotency",
      "Eventual consistency",
      "Polymorphism"
    ],
    "correctIndex": 1,
    "explanation": "An idempotent operation has the same effect when repeated with the same key or intent.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Idempotency",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-085",
    "category": "System Design",
    "title": "Circuit breaker",
    "scenario": "A downstream service is failing repeatedly. Which pattern can stop cascading calls?",
    "prompt": "A downstream service is failing repeatedly. Which pattern can stop cascading calls? Select the strongest answer.",
    "options": [
      "Circuit breaker",
      "Observer",
      "Factory",
      "Decorator"
    ],
    "correctIndex": 0,
    "explanation": "A circuit breaker temporarily blocks calls to an unhealthy dependency.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Circuit breaker",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-086",
    "category": "System Design",
    "title": "Sharding",
    "scenario": "A very large dataset is partitioned across database nodes by key. What is this?",
    "prompt": "A very large dataset is partitioned across database nodes by key. What is this? Select the strongest answer.",
    "options": [
      "Replication",
      "Indexing",
      "Serialization",
      "Sharding"
    ],
    "correctIndex": 3,
    "explanation": "Sharding distributes data horizontally across multiple partitions.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Sharding",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-087",
    "category": "System Design",
    "title": "Replication",
    "scenario": "Multiple database copies are maintained for availability or read scaling. What is this?",
    "prompt": "Multiple database copies are maintained for availability or read scaling. What is this? Select the strongest answer.",
    "options": [
      "Memoization",
      "Compilation",
      "Replication",
      "Normalization"
    ],
    "correctIndex": 2,
    "explanation": "Replication maintains copies of data across nodes, with consistency tradeoffs.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Replication",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-088",
    "category": "System Design",
    "title": "SLO",
    "scenario": "A reliability target for service behavior over a time window is called what?",
    "prompt": "A reliability target for service behavior over a time window is called what? Select the strongest answer.",
    "options": [
      "Secure login option",
      "Service level objective",
      "Source line output",
      "System load operation"
    ],
    "correctIndex": 1,
    "explanation": "An SLO is an internal reliability target, often measured with an indicator.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "SLO",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-089",
    "category": "System Design",
    "title": "Backpressure",
    "scenario": "A consumer signals that producers should slow down. What mechanism is this?",
    "prompt": "A consumer signals that producers should slow down. What mechanism is this? Select the strongest answer.",
    "options": [
      "Backpressure",
      "Autoscaling only",
      "Failover",
      "Compression"
    ],
    "correctIndex": 0,
    "explanation": "Backpressure prevents overloaded downstream components from being overwhelmed.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Backpressure",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-090",
    "category": "System Design",
    "title": "CAP tradeoff",
    "scenario": "During a network partition, a distributed system must choose between which two guarantees in CAP?",
    "prompt": "During a network partition, a distributed system must choose between which two guarantees in CAP? Select the strongest answer.",
    "options": [
      "Latency and throughput",
      "Authentication and authorization",
      "Durability and atomicity",
      "Consistency and availability"
    ],
    "correctIndex": 3,
    "explanation": "CAP describes the tradeoff between consistency and availability when a partition occurs.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "CAP tradeoff",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-091",
    "category": "Git & DevOps",
    "title": "Commit",
    "scenario": "What does a Git commit represent?",
    "prompt": "What does a Git commit represent? Select the strongest answer.",
    "options": [
      "A deployment secret",
      "A package manager",
      "A recorded snapshot in repository history",
      "A remote server restart"
    ],
    "correctIndex": 2,
    "explanation": "A commit records a project snapshot and metadata in the repository graph.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Commit",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-092",
    "category": "Git & DevOps",
    "title": "Branch",
    "scenario": "What is a Git branch best understood as?",
    "prompt": "What is a Git branch best understood as? Select the strongest answer.",
    "options": [
      "A release binary",
      "A movable reference to a commit",
      "A complete duplicate server",
      "A database index"
    ],
    "correctIndex": 1,
    "explanation": "A branch name points to a commit and advances as new commits are made.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Branch",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-093",
    "category": "Git & DevOps",
    "title": "Rebase",
    "scenario": "What does git rebase generally do?",
    "prompt": "What does git rebase generally do? Select the strongest answer.",
    "options": [
      "Replays commits onto a new base",
      "Deletes every remote branch",
      "Compresses images",
      "Runs unit tests automatically"
    ],
    "correctIndex": 0,
    "explanation": "Rebase reapplies commits onto another base, rewriting commit identities.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Rebase",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-094",
    "category": "Git & DevOps",
    "title": "Merge conflict",
    "scenario": "Why does Git report a merge conflict?",
    "prompt": "Why does Git report a merge conflict? Select the strongest answer.",
    "options": [
      "The repository has no README",
      "The network uses TLS",
      "The branch name is too long",
      "It cannot automatically reconcile overlapping changes"
    ],
    "correctIndex": 3,
    "explanation": "Conflicts require a human or tool to choose how overlapping edits should combine.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Merge conflict",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-095",
    "category": "Git & DevOps",
    "title": "CI",
    "scenario": "What does continuous integration commonly automate?",
    "prompt": "What does continuous integration commonly automate? Select the strongest answer.",
    "options": [
      "DNS registration",
      "Production password sharing",
      "Builds and tests on proposed changes",
      "Manual promotion decisions"
    ],
    "correctIndex": 2,
    "explanation": "CI provides repeatable automated checks on code changes.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "CI",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-096",
    "category": "Git & DevOps",
    "title": "Artifact",
    "scenario": "What is a build artifact?",
    "prompt": "What is a build artifact? Select the strongest answer.",
    "options": [
      "A code review comment",
      "A produced package or binary from a build",
      "A Git username",
      "A database foreign key"
    ],
    "correctIndex": 1,
    "explanation": "Artifacts are outputs that can be stored, tested, signed, and deployed.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Artifact",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-097",
    "category": "Git & DevOps",
    "title": "Container",
    "scenario": "What does a container image package?",
    "prompt": "What does a container image package? Select the strongest answer.",
    "options": [
      "Application filesystem and runtime dependencies",
      "A physical server rack",
      "Only source control metadata",
      "A cloud billing account"
    ],
    "correctIndex": 0,
    "explanation": "Container images package an application environment for consistent execution.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Container",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-098",
    "category": "Git & DevOps",
    "title": "Rollback",
    "scenario": "A deployment introduces a critical regression. What action restores a prior known-good release?",
    "prompt": "A deployment introduces a critical regression. What action restores a prior known-good release? Select the strongest answer.",
    "options": [
      "Rebase",
      "Squash",
      "Cherry-pick",
      "Rollback"
    ],
    "correctIndex": 3,
    "explanation": "Rollback returns service to a previous release or configuration.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Rollback",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-099",
    "category": "Git & DevOps",
    "title": "Observability",
    "scenario": "Which three pillars are commonly associated with observability?",
    "prompt": "Which three pillars are commonly associated with observability? Select the strongest answer.",
    "options": [
      "CPU, RAM, and disk only",
      "DNS, DHCP, and ARP",
      "Logs, metrics, and traces",
      "HTML, CSS, and JavaScript"
    ],
    "correctIndex": 2,
    "explanation": "Logs, metrics, and traces provide complementary views into system behavior.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Observability",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-100",
    "category": "Git & DevOps",
    "title": "Infrastructure as code",
    "scenario": "What is the benefit of defining infrastructure declaratively in versioned files?",
    "prompt": "What is the benefit of defining infrastructure declaratively in versioned files? Select the strongest answer.",
    "options": [
      "Guaranteed lower cloud costs",
      "Repeatable, reviewable infrastructure changes",
      "No need for access controls",
      "Automatic elimination of outages"
    ],
    "correctIndex": 1,
    "explanation": "Infrastructure as code enables review, repeatability, and drift detection.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Infrastructure as code",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-101",
    "category": "TypeScript & React",
    "title": "TypeScript",
    "scenario": "What does TypeScript add to JavaScript?",
    "prompt": "What does TypeScript add to JavaScript? Select the strongest answer.",
    "options": [
      "A static type system with compile-time checks",
      "A new browser engine",
      "A relational database",
      "A CSS preprocessor only"
    ],
    "correctIndex": 0,
    "explanation": "TypeScript checks types during development and emits JavaScript.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "TypeScript",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-102",
    "category": "TypeScript & React",
    "title": "React state",
    "scenario": "Which hook stores component state in a function component?",
    "prompt": "Which hook stores component state in a function component? Select the strongest answer.",
    "options": [
      "useRoute",
      "useFetchNow",
      "useClass",
      "useState"
    ],
    "correctIndex": 3,
    "explanation": "useState returns a state value and setter that triggers re-rendering.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "React state",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-103",
    "category": "TypeScript & React",
    "title": "Effect cleanup",
    "scenario": "Why should an effect clean up an event listener?",
    "prompt": "Why should an effect clean up an event listener? Select the strongest answer.",
    "options": [
      "To force a full page reload",
      "To encrypt props",
      "To avoid stale listeners and resource leaks",
      "To prevent JSX parsing"
    ],
    "correctIndex": 2,
    "explanation": "Cleanup removes subscriptions or listeners when dependencies change or a component unmounts.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Effect cleanup",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-104",
    "category": "TypeScript & React",
    "title": "Keys",
    "scenario": "Why should list elements have stable keys in React?",
    "prompt": "Why should list elements have stable keys in React? Select the strongest answer.",
    "options": [
      "Prevent all rerenders",
      "Help React match items between renders",
      "Encrypt the item values",
      "Sort the array alphabetically"
    ],
    "correctIndex": 1,
    "explanation": "Keys preserve element identity during reconciliation.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Keys",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-105",
    "category": "TypeScript & React",
    "title": "Props",
    "scenario": "How should a child component receive data from its parent?",
    "prompt": "How should a child component receive data from its parent? Select the strongest answer.",
    "options": [
      "Through props",
      "Through global CSS variables only",
      "By editing parent source at runtime",
      "Through localStorage only"
    ],
    "correctIndex": 0,
    "explanation": "Props are the standard read-only input interface to a React component.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Props",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-106",
    "category": "TypeScript & React",
    "title": "Controlled input",
    "scenario": "What makes a React input controlled?",
    "prompt": "What makes a React input controlled? Select the strongest answer.",
    "options": [
      "It has a disabled attribute",
      "It uses a placeholder",
      "It has no onChange handler",
      "Its value is driven by React state"
    ],
    "correctIndex": 3,
    "explanation": "A controlled input receives value and updates state through an event handler.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Controlled input",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-107",
    "category": "TypeScript & React",
    "title": "Memoization",
    "scenario": "Which hook memoizes a computed value between renders?",
    "prompt": "Which hook memoizes a computed value between renders? Select the strongest answer.",
    "options": [
      "useId",
      "useContextMenu",
      "useMemo",
      "useState"
    ],
    "correctIndex": 2,
    "explanation": "useMemo caches a calculation result until its dependencies change.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Memoization",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-108",
    "category": "TypeScript & React",
    "title": "Error boundary",
    "scenario": "What React pattern catches rendering errors in a subtree?",
    "prompt": "What React pattern catches rendering errors in a subtree? Select the strongest answer.",
    "options": [
      "Fragment",
      "Error boundary",
      "Context provider",
      "Portal"
    ],
    "correctIndex": 1,
    "explanation": "Error boundaries catch errors during rendering and lifecycle in descendant components.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Error boundary",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-109",
    "category": "TypeScript & React",
    "title": "Semantic HTML",
    "scenario": "Which element should represent the primary page content?",
    "prompt": "Which element should represent the primary page content? Select the strongest answer.",
    "options": [
      "main",
      "span",
      "b",
      "small"
    ],
    "correctIndex": 0,
    "explanation": "The main element identifies the dominant content of the document.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Semantic HTML",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-110",
    "category": "TypeScript & React",
    "title": "Accessibility",
    "scenario": "What should an icon-only button provide?",
    "prompt": "What should an icon-only button provide? Select the strongest answer.",
    "options": [
      "A random animation",
      "A hidden database",
      "A hover-only tooltip as the sole label",
      "An accessible name"
    ],
    "correctIndex": 3,
    "explanation": "An accessible name communicates the control purpose to assistive technology.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Accessibility",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-111",
    "category": "Operating Systems & Architecture",
    "title": "Process",
    "scenario": "What is a process?",
    "prompt": "What is a process? Select the strongest answer.",
    "options": [
      "A database view",
      "A Git tag",
      "A running program with its own execution context",
      "A CSS class"
    ],
    "correctIndex": 2,
    "explanation": "A process is an executing program with resources and an address space.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Process",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-112",
    "category": "Operating Systems & Architecture",
    "title": "Thread",
    "scenario": "What do threads in one process typically share?",
    "prompt": "What do threads in one process typically share? Select the strongest answer.",
    "options": [
      "A unique database server",
      "The process address space",
      "Independent page tables in all cases",
      "Separate executable files"
    ],
    "correctIndex": 1,
    "explanation": "Threads share process resources while maintaining their own stacks and registers.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Thread",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-113",
    "category": "Operating Systems & Architecture",
    "title": "Deadlock",
    "scenario": "Which condition means processes wait forever for resources held by each other?",
    "prompt": "Which condition means processes wait forever for resources held by each other? Select the strongest answer.",
    "options": [
      "Deadlock",
      "Starvation-free scheduling",
      "Cache hit",
      "Context switch"
    ],
    "correctIndex": 0,
    "explanation": "Deadlock is a circular wait state where progress cannot occur.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Deadlock",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-114",
    "category": "Operating Systems & Architecture",
    "title": "Virtual memory",
    "scenario": "What abstraction gives processes their own address spaces?",
    "prompt": "What abstraction gives processes their own address spaces? Select the strongest answer.",
    "options": [
      "RAID",
      "DNS",
      "TLS",
      "Virtual memory"
    ],
    "correctIndex": 3,
    "explanation": "Virtual memory maps process addresses to physical memory and storage-backed pages.",
    "difficulty": "FOUNDATION",
    "points": 50,
    "skill": "Virtual memory",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-115",
    "category": "Operating Systems & Architecture",
    "title": "Cache locality",
    "scenario": "Why can sequential memory access be faster than random access?",
    "prompt": "Why can sequential memory access be faster than random access? Select the strongest answer.",
    "options": [
      "It avoids all instructions",
      "It changes the language runtime",
      "It benefits from spatial locality and cache lines",
      "It disables the CPU cache"
    ],
    "correctIndex": 2,
    "explanation": "Nearby memory accesses often reuse cache lines efficiently.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Cache locality",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-116",
    "category": "Operating Systems & Architecture",
    "title": "Big endian",
    "scenario": "What does endianness describe?",
    "prompt": "What does endianness describe? Select the strongest answer.",
    "options": [
      "Disk redundancy level",
      "Byte order for multi-byte values",
      "CPU clock frequency",
      "Thread scheduling fairness"
    ],
    "correctIndex": 1,
    "explanation": "Endianness determines which byte of a multi-byte value is stored first.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Big endian",
    "boss": "THE ARCHITECT"
  },
  {
    "id": "lab-117",
    "category": "Operating Systems & Architecture",
    "title": "System call",
    "scenario": "How does a user program request a privileged operating-system service?",
    "prompt": "How does a user program request a privileged operating-system service? Select the strongest answer.",
    "options": [
      "System call",
      "CSS selector",
      "SQL trigger",
      "Git hook"
    ],
    "correctIndex": 0,
    "explanation": "System calls provide a controlled interface to kernel services.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "System call",
    "boss": "THE NEPOTISM KING"
  },
  {
    "id": "lab-118",
    "category": "Operating Systems & Architecture",
    "title": "Garbage collection",
    "scenario": "What does a tracing garbage collector identify?",
    "prompt": "What does a tracing garbage collector identify? Select the strongest answer.",
    "options": [
      "Every file on disk",
      "Unused network ports",
      "All database indexes",
      "Objects reachable from roots"
    ],
    "correctIndex": 3,
    "explanation": "Tracing collectors mark reachable objects and reclaim unreachable managed memory.",
    "difficulty": "INTERMEDIATE",
    "points": 75,
    "skill": "Garbage collection",
    "boss": "THE CREDIT THIEF"
  },
  {
    "id": "lab-119",
    "category": "Operating Systems & Architecture",
    "title": "Race condition",
    "scenario": "Two threads update shared state without coordination. What risk arises?",
    "prompt": "Two threads update shared state without coordination. What risk arises? Select the strongest answer.",
    "options": [
      "Static typing",
      "Normalization",
      "Race condition",
      "Deterministic output"
    ],
    "correctIndex": 2,
    "explanation": "A race condition makes outcomes depend on timing or interleaving.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Race condition",
    "boss": "THE PROMOTION GATEKEEPER"
  },
  {
    "id": "lab-120",
    "category": "Operating Systems & Architecture",
    "title": "Mutex",
    "scenario": "Which primitive grants exclusive access to a critical section?",
    "prompt": "Which primitive grants exclusive access to a critical section? Select the strongest answer.",
    "options": [
      "Compiler flag",
      "Mutex",
      "Semaphore-free queue",
      "DNS resolver"
    ],
    "correctIndex": 1,
    "explanation": "A mutex allows one owner at a time to enter a protected critical section.",
    "difficulty": "ADVANCED",
    "points": 100,
    "skill": "Mutex",
    "boss": "THE ARCHITECT"
  }
];
