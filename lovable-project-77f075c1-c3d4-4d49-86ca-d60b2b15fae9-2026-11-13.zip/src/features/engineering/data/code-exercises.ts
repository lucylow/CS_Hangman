import type { CodeExercise } from "../types";

// Source examples are educational text; never execute them in the app.
export const codeExercises: CodeExercise[] = [
  {
    "id": "code-001",
    "category": "Python",
    "title": "Guard an empty average",
    "starterCode": "def average(values):\n    return sum(values) / len(values)",
    "referenceSolution": "def average(values):\n    if not values:\n        return None\n    return sum(values) / len(values)",
    "task": "Return None for an empty sequence and the arithmetic mean otherwise.",
    "acceptanceChecks": [
      "average([2, 4]) == 3",
      "average([]) is None",
      "average([5]) == 5"
    ],
    "explanation": "Empty input must be handled before division.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-002",
    "category": "Python",
    "title": "Count values above a threshold",
    "starterCode": "def count_high(values, threshold):\n    count = 0\n    for value in values:\n        if value > threshold:\n            count =+ 1\n    return count",
    "referenceSolution": "def count_high(values, threshold):\n    count = 0\n    for value in values:\n        if value > threshold:\n            count += 1\n    return count",
    "task": "Count values strictly greater than the threshold.",
    "acceptanceChecks": [
      "count_high([1, 5, 7], 5) == 1",
      "count_high([], 2) == 0"
    ],
    "explanation": "The original assignment resets count to positive one instead of incrementing it.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-003",
    "category": "Python",
    "title": "Return a defensive copy",
    "starterCode": "def get_tags(record):\n    return record[\"tags\"]",
    "referenceSolution": "def get_tags(record):\n    return list(record.get(\"tags\", []))",
    "task": "Return a new list so callers cannot mutate the record through the returned value.",
    "acceptanceChecks": [
      "get_tags({'tags': ['a']}) == ['a']",
      "get_tags({}) == []",
      "Changing the returned list does not change the original tags."
    ],
    "explanation": "A defensive copy prevents aliasing and get handles a missing field.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-004",
    "category": "Python",
    "title": "Use a context manager",
    "starterCode": "def read_text(path):\n    file = open(path)\n    data = file.read()\n    return data",
    "referenceSolution": "def read_text(path):\n    with open(path, encoding=\"utf-8\") as file:\n        return file.read()",
    "task": "Read UTF-8 text and guarantee the file is closed.",
    "acceptanceChecks": [
      "file is closed after read",
      "Unicode text is decoded as UTF-8"
    ],
    "explanation": "The with statement ensures cleanup when the block exits.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-005",
    "category": "Python",
    "title": "Avoid mutating a default list",
    "starterCode": "def add_item(item, items=[]):\n    items.append(item)\n    return items",
    "referenceSolution": "def add_item(item, items=None):\n    if items is None:\n        items = []\n    items.append(item)\n    return items",
    "task": "Each call without an explicit list should start with a fresh list.",
    "acceptanceChecks": [
      "add_item(1) == [1]",
      "add_item(2) == [2]"
    ],
    "explanation": "Default argument objects are created once when the function is defined.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-006",
    "category": "JavaScript",
    "title": "Fix an off-by-one loop",
    "starterCode": "function sum(values) {\n  let total = 0;\n  for (let i = 0; i <= values.length; i++) total += values[i];\n  return total;\n}",
    "referenceSolution": "function sum(values) {\n  let total = 0;\n  for (let i = 0; i < values.length; i++) total += values[i];\n  return total;\n}",
    "task": "Sum every array element exactly once without reading beyond the final index.",
    "acceptanceChecks": [
      "sum([2, 3]) === 5",
      "sum([]) === 0"
    ],
    "explanation": "Array indexes end at length - 1, so the loop condition must be strictly less than length.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-007",
    "category": "JavaScript",
    "title": "Preserve zero with nullish coalescing",
    "starterCode": "function pageSize(input) {\n  return input || 20;\n}",
    "referenceSolution": "function pageSize(input) {\n  return input ?? 20;\n}",
    "task": "Use 20 only when input is null or undefined; preserve a valid zero.",
    "acceptanceChecks": [
      "pageSize(0) === 0",
      "pageSize(null) === 20",
      "pageSize(10) === 10"
    ],
    "explanation": "Logical OR treats zero as falsy; nullish coalescing only falls back for nullish values.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-008",
    "category": "JavaScript",
    "title": "Avoid mutating the source array",
    "starterCode": "function sortedCopy(values) {\n  return values.sort();\n}",
    "referenceSolution": "function sortedCopy(values) {\n  return [...values].sort((a, b) => a - b);\n}",
    "task": "Return a numerically sorted copy and leave the input untouched.",
    "acceptanceChecks": [
      "sortedCopy([10, 2]) deepEquals [2, 10]",
      "input order remains unchanged"
    ],
    "explanation": "sort mutates its receiver and default sorting compares string representations.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-009",
    "category": "JavaScript",
    "title": "Handle rejected promises",
    "starterCode": "async function loadProfile() {\n  const response = await fetch(\"/profile\");\n  return response.json();\n}",
    "referenceSolution": "async function loadProfile() {\n  const response = await fetch(\"/profile\");\n  if (!response.ok) throw new Error(`HTTP ${response.status}`);\n  return response.json();\n}",
    "task": "Reject non-success HTTP responses before attempting to parse the body.",
    "acceptanceChecks": [
      "404 response rejects",
      "200 JSON response resolves"
    ],
    "explanation": "fetch rejects on network errors, not on HTTP 4xx or 5xx responses.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-010",
    "category": "JavaScript",
    "title": "Remove an event listener",
    "starterCode": "function subscribe(button, handler) {\n  button.addEventListener(\"click\", handler);\n}",
    "referenceSolution": "function subscribe(button, handler) {\n  button.addEventListener(\"click\", handler);\n  return () => button.removeEventListener(\"click\", handler);\n}",
    "task": "Return an unsubscribe function for deterministic cleanup.",
    "acceptanceChecks": [
      "handler runs after subscribe",
      "handler does not run after unsubscribe"
    ],
    "explanation": "Listeners need a matching removal call to avoid leaks and duplicate callbacks.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-011",
    "category": "SQL",
    "title": "Filter before grouping",
    "starterCode": "SELECT department, COUNT(*) FROM employees;",
    "referenceSolution": "SELECT department, COUNT(*) FROM employees GROUP BY department;",
    "task": "Return one employee count per department.",
    "acceptanceChecks": [
      "one row per department",
      "count matches source rows"
    ],
    "explanation": "Every selected non-aggregated column must be grouped in standard SQL.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-012",
    "category": "SQL",
    "title": "Protect a parameterized lookup",
    "starterCode": "const sql = `SELECT * FROM users WHERE email = '${email}'`;",
    "referenceSolution": "const sql = \"SELECT * FROM users WHERE email = ?\";\n// Pass [email] separately through the database driver.",
    "task": "Keep user input as a bound value, not SQL syntax.",
    "acceptanceChecks": [
      "email containing quote is treated as data",
      "query structure is constant"
    ],
    "explanation": "Parameterized queries prevent user input from changing the SQL statement structure.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-013",
    "category": "SQL",
    "title": "Use a transaction for paired writes",
    "starterCode": "UPDATE accounts SET balance = balance - 50 WHERE id = 1;\nUPDATE accounts SET balance = balance + 50 WHERE id = 2;",
    "referenceSolution": "BEGIN;\nUPDATE accounts SET balance = balance - 50 WHERE id = 1;\nUPDATE accounts SET balance = balance + 50 WHERE id = 2;\nCOMMIT;",
    "task": "Ensure both balance updates commit together or roll back together on failure.",
    "acceptanceChecks": [
      "both balances change on success",
      "neither change on failure"
    ],
    "explanation": "A transaction makes the pair of writes atomic when executed in one transaction.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-014",
    "category": "Algorithms",
    "title": "Return early for an empty search",
    "starterCode": "function findIndex(items, target) {\n  let low = 0, high = items.length - 1;\n  while (low <= high) { /* binary search */ }\n}",
    "referenceSolution": "function findIndex(items, target) {\n  if (items.length === 0) return -1;\n  let low = 0, high = items.length - 1;\n  while (low <= high) {\n    const mid = Math.floor((low + high) / 2);\n    if (items[mid] === target) return mid;\n    if (items[mid] < target) low = mid + 1; else high = mid - 1;\n  }\n  return -1;\n}",
    "task": "Implement binary search over a sorted numeric array.",
    "acceptanceChecks": [
      "findIndex([1, 3, 5], 3) === 1",
      "findIndex([], 4) === -1",
      "missing target returns -1"
    ],
    "explanation": "The interval shrinks by half per iteration; the empty case naturally returns -1.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-015",
    "category": "Algorithms",
    "title": "Use a set for membership checks",
    "starterCode": "function hasDuplicate(values) {\n  for (let i = 0; i < values.length; i++)\n    for (let j = i + 1; j < values.length; j++)\n      if (values[i] === values[j]) return true;\n  return false;\n}",
    "referenceSolution": "function hasDuplicate(values) {\n  const seen = new Set();\n  for (const value of values) {\n    if (seen.has(value)) return true;\n    seen.add(value);\n  }\n  return false;\n}",
    "task": "Detect duplicates in expected linear time.",
    "acceptanceChecks": [
      "hasDuplicate([1, 2, 1]) === true",
      "hasDuplicate([1, 2]) === false"
    ],
    "explanation": "A set gives expected constant-time membership checks, reducing O(n\u00b2) to O(n).",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-016",
    "category": "React",
    "title": "Keep state updates immutable",
    "starterCode": "setItems(items.push(newItem));",
    "referenceSolution": "setItems((current) => [...current, newItem]);",
    "task": "Append an item without mutating existing state and avoid stale closure values.",
    "acceptanceChecks": [
      "new item appears",
      "previous array reference is not mutated"
    ],
    "explanation": "push mutates and returns a number; the setter needs a new array.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-017",
    "category": "React",
    "title": "Add a stable list key",
    "starterCode": "{users.map((user) => <UserRow user={user} />)}",
    "referenceSolution": "{users.map((user) => <UserRow key={user.id} user={user} />)}",
    "task": "Give each rendered row a stable identity across insertions and reordering.",
    "acceptanceChecks": [
      "no missing-key warning",
      "state remains associated with the correct user"
    ],
    "explanation": "Stable keys help React reconcile list items correctly.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-018",
    "category": "React",
    "title": "Clean up a subscription",
    "starterCode": "useEffect(() => {\n  socket.on(\"message\", onMessage);\n}, [socket]);",
    "referenceSolution": "useEffect(() => {\n  socket.on(\"message\", onMessage);\n  return () => socket.off(\"message\", onMessage);\n}, [socket, onMessage]);",
    "task": "Remove the exact listener when dependencies change or the component unmounts.",
    "acceptanceChecks": [
      "one active listener after rerender",
      "zero listeners after unmount"
    ],
    "explanation": "Effects should clean up external subscriptions and include reactive dependencies.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-019",
    "category": "Security",
    "title": "Validate authorization on the server",
    "starterCode": "// UI hides the delete button for non-admin users.\nreturn deleteRecord(id);",
    "referenceSolution": "// Server-side handler: verify the authenticated principal\n// has delete permission for this specific record before deleting.",
    "task": "Prevent a caller from deleting records by bypassing the user interface.",
    "acceptanceChecks": [
      "unauthorized request returns 403",
      "authorized request succeeds"
    ],
    "explanation": "Client-side visibility is not an authorization boundary; enforce access on the server.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-020",
    "category": "Security",
    "title": "Avoid logging credentials",
    "starterCode": "logger.info(\"Login attempt\", { email, password });",
    "referenceSolution": "logger.info(\"Login attempt\", { email });",
    "task": "Keep secrets and authentication factors out of application logs.",
    "acceptanceChecks": [
      "password absent from logs",
      "event still includes useful non-secret context"
    ],
    "explanation": "Logs are widely accessible and retained; never record passwords or tokens.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-021",
    "category": "Security",
    "title": "Set a restrictive content policy",
    "starterCode": "// No Content-Security-Policy is configured.",
    "referenceSolution": "Content-Security-Policy: default-src 'self'; object-src 'none'; base-uri 'self'",
    "task": "Reduce the sources from which the browser may load executable content.",
    "acceptanceChecks": [
      "inline script blocked unless explicitly allowed",
      "object embedding disabled"
    ],
    "explanation": "A carefully tested CSP reduces the impact of injection vulnerabilities.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-022",
    "category": "Networking",
    "title": "Retry with bounded exponential backoff",
    "starterCode": "for (let i = 0; i < 100; i++) await request();",
    "referenceSolution": "for (let attempt = 0; attempt < 4; attempt++) {\n  try { return await request(); }\n  catch (error) {\n    if (attempt === 3) throw error;\n    await sleep(250 * (2 ** attempt));\n  }\n}",
    "task": "Retry transient failures a limited number of times with increasing delays.",
    "acceptanceChecks": [
      "maximum of four attempts",
      "delay increases per retry",
      "final error is propagated"
    ],
    "explanation": "Unbounded retries can amplify outages; bounded backoff reduces pressure.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-023",
    "category": "System Design",
    "title": "Make a payment request idempotent",
    "starterCode": "POST /payments\n// Every retry creates another payment.",
    "referenceSolution": "POST /payments\nIdempotency-Key: client-generated-unique-key\n// Server stores and reuses the first result for this key.",
    "task": "Ensure client retries do not create duplicate charges.",
    "acceptanceChecks": [
      "same key returns same result",
      "different key can create a distinct payment"
    ],
    "explanation": "The server must persist and enforce idempotency, not merely accept a header.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-024",
    "category": "Git & DevOps",
    "title": "Pin a reproducible runtime",
    "starterCode": "FROM node:latest",
    "referenceSolution": "FROM node:22.11.0-alpine",
    "task": "Use an explicit runtime version to reduce surprise changes between builds.",
    "acceptanceChecks": [
      "same image tag resolves to intended runtime family",
      "build metadata records the chosen version"
    ],
    "explanation": "Floating latest tags can change without a source change.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-025",
    "category": "TypeScript",
    "title": "Narrow an unknown value safely",
    "starterCode": "function label(value: unknown) { return value.name.toUpperCase(); }",
    "referenceSolution": "function label(value: unknown): string {\n  if (typeof value === \"object\" && value !== null && \"name\" in value && typeof value.name === \"string\") return value.name.toUpperCase();\n  return \"UNKNOWN\";\n}",
    "task": "Check an unknown value before accessing nested properties.",
    "acceptanceChecks": [
      "object with string name is uppercased",
      "null and unrelated values return UNKNOWN"
    ],
    "explanation": "unknown requires runtime narrowing before property access.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-026",
    "category": "Python",
    "title": "Use enumerate for indexes",
    "starterCode": "for i in range(len(names)):\n    print(i, names[i])",
    "referenceSolution": "for i, name in enumerate(names):\n    print(i, name)",
    "task": "Iterate with index and value together.",
    "acceptanceChecks": [
      "indexes start at zero",
      "all names are emitted"
    ],
    "explanation": "enumerate expresses the intent directly and avoids repeated indexing.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-027",
    "category": "Python",
    "title": "Sort dictionary items by value",
    "starterCode": "scores.sort()",
    "referenceSolution": "ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)",
    "task": "Return key-value pairs ordered by descending score.",
    "acceptanceChecks": [
      "highest score first",
      "source dictionary unchanged"
    ],
    "explanation": "sorted accepts a key function and returns a new list.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-028",
    "category": "Python",
    "title": "Preserve exception context",
    "starterCode": "try:\n    parse(payload)\nexcept Exception:\n    raise ValueError(\"Invalid payload\")",
    "referenceSolution": "try:\n    parse(payload)\nexcept Exception as error:\n    raise ValueError(\"Invalid payload\") from error",
    "task": "Wrap the parsing error while preserving its cause.",
    "acceptanceChecks": [
      "ValueError is raised",
      "original exception is available as __cause__"
    ],
    "explanation": "Explicit exception chaining preserves diagnostic context.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-029",
    "category": "Python",
    "title": "Avoid broad exception swallowing",
    "starterCode": "try:\n    save(record)\nexcept:\n    pass",
    "referenceSolution": "try:\n    save(record)\nexcept OSError as error:\n    logger.exception(\"Could not save record\")\n    raise",
    "task": "Handle the expected failure type and retain diagnostics.",
    "acceptanceChecks": [
      "OSError is logged",
      "unexpected exceptions are not silently swallowed"
    ],
    "explanation": "Bare except hides programming errors and makes failures difficult to diagnose.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-030",
    "category": "JavaScript",
    "title": "Use a numeric comparator",
    "starterCode": "[9, 80, 12].sort()",
    "referenceSolution": "[9, 80, 12].sort((a, b) => a - b)",
    "task": "Sort numbers in ascending numeric order.",
    "acceptanceChecks": [
      "result is [9, 12, 80]"
    ],
    "explanation": "The default sort compares string representations.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-031",
    "category": "JavaScript",
    "title": "Use Promise.all for independent work",
    "starterCode": "const user = await getUser();\nconst teams = await getTeams();",
    "referenceSolution": "const [user, teams] = await Promise.all([getUser(), getTeams()]);",
    "task": "Run independent requests concurrently and wait for both.",
    "acceptanceChecks": [
      "both results returned",
      "requests overlap in time"
    ],
    "explanation": "Promise.all coordinates independent promises concurrently.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-032",
    "category": "JavaScript",
    "title": "Check array existence before access",
    "starterCode": "const first = users[0].name;",
    "referenceSolution": "const first = users[0]?.name ?? \"Unknown\";",
    "task": "Avoid a crash when the array is empty or the first item is nullish.",
    "acceptanceChecks": [
      "empty array returns Unknown",
      "valid first user returns name"
    ],
    "explanation": "Optional chaining and nullish coalescing make the fallback explicit.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-033",
    "category": "JavaScript",
    "title": "Prevent duplicate form submission",
    "starterCode": "async function submit() { await sendForm(); }",
    "referenceSolution": "let submitting = false;\nasync function submit() {\n  if (submitting) return;\n  submitting = true;\n  try { await sendForm(); } finally { submitting = false; }\n}",
    "task": "Ignore overlapping submits and always release the in-flight guard.",
    "acceptanceChecks": [
      "second call during request is ignored",
      "guard resets after success and failure"
    ],
    "explanation": "A guarded state transition prevents duplicate in-flight actions.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-034",
    "category": "SQL",
    "title": "Use a left join to retain unmatched rows",
    "starterCode": "SELECT c.name, o.id FROM customers c JOIN orders o ON o.customer_id = c.id;",
    "referenceSolution": "SELECT c.name, o.id FROM customers c LEFT JOIN orders o ON o.customer_id = c.id;",
    "task": "List every customer, including those with no orders.",
    "acceptanceChecks": [
      "customers without orders remain in results",
      "order id is null when unmatched"
    ],
    "explanation": "LEFT JOIN retains all rows from the left relation.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-035",
    "category": "SQL",
    "title": "Prevent divide-by-zero in a ratio",
    "starterCode": "SELECT revenue / visits AS rate FROM metrics;",
    "referenceSolution": "SELECT revenue / NULLIF(visits, 0) AS rate FROM metrics;",
    "task": "Return NULL rather than raising a division-by-zero error when visits is zero.",
    "acceptanceChecks": [
      "visits=0 produces NULL",
      "positive visits computes the ratio"
    ],
    "explanation": "NULLIF converts a zero denominator to NULL.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-036",
    "category": "Algorithms",
    "title": "Use a queue for BFS",
    "starterCode": "const stack = [start]; // pop from end",
    "referenceSolution": "const queue = [start];\nlet head = 0;\nwhile (head < queue.length) { const node = queue[head++]; /* visit and enqueue neighbors */ }",
    "task": "Process graph vertices in first-in-first-out order.",
    "acceptanceChecks": [
      "vertices visited by nondecreasing distance",
      "each vertex enqueued once with visited set"
    ],
    "explanation": "BFS uses a queue to visit the graph layer by layer.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-037",
    "category": "Algorithms",
    "title": "Avoid repeated Fibonacci work",
    "starterCode": "function fib(n) { return n < 2 ? n : fib(n-1) + fib(n-2); }",
    "referenceSolution": "function fib(n) {\n  const memo = new Map([[0, 0], [1, 1]]);\n  function visit(k) { if (!memo.has(k)) memo.set(k, visit(k-1) + visit(k-2)); return memo.get(k); }\n  return visit(n);\n}",
    "task": "Compute Fibonacci values without exponential repeated recursion.",
    "acceptanceChecks": [
      "fib(10) === 55",
      "each n is computed once"
    ],
    "explanation": "Memoization reduces repeated subproblem work.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-038",
    "category": "React",
    "title": "Avoid state derived from props duplication",
    "starterCode": "const [title, setTitle] = useState(props.title);",
    "referenceSolution": "const title = props.title;",
    "task": "Render a value that should always reflect the latest prop.",
    "acceptanceChecks": [
      "updated prop appears after rerender",
      "no stale local copy"
    ],
    "explanation": "Duplicating derived props in state can drift out of sync.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-039",
    "category": "React",
    "title": "Use a label for an input",
    "starterCode": "<input id=\"email\" />",
    "referenceSolution": "<label htmlFor=\"email\">Email</label>\n<input id=\"email\" name=\"email\" type=\"email\" autoComplete=\"email\" />",
    "task": "Associate the input with a visible accessible label and useful semantics.",
    "acceptanceChecks": [
      "label activates input",
      "screen reader announces Email"
    ],
    "explanation": "A programmatic label improves accessibility and click target.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-040",
    "category": "Security",
    "title": "Use constant-time secret comparison",
    "starterCode": "if (providedToken === expectedToken) allow();",
    "referenceSolution": "if (timingSafeEqual(Buffer.from(providedToken), Buffer.from(expectedToken))) allow();",
    "task": "Compare fixed-length secret tokens with a timing-safe primitive.",
    "acceptanceChecks": [
      "matching tokens pass",
      "different tokens fail",
      "length is validated before comparison"
    ],
    "explanation": "Timing-safe comparison reduces timing side-channel leakage; validate lengths first.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-041",
    "category": "Security",
    "title": "Validate uploaded file content",
    "starterCode": "if (file.name.endsWith(\".png\")) accept(file);",
    "referenceSolution": "// Enforce size limits, inspect file signatures, decode safely,\n// store outside the web root, and serve with a safe content type.",
    "task": "Do not trust a filename extension as proof of file type.",
    "acceptanceChecks": [
      "renamed executable is rejected",
      "oversized upload is rejected"
    ],
    "explanation": "File names and client MIME types are attacker-controlled.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-042",
    "category": "Networking",
    "title": "Respect HTTP 429 retry guidance",
    "starterCode": "if (response.status === 429) retryImmediately();",
    "referenceSolution": "if (response.status === 429) {\n  const delay = Number(response.headers.get(\"Retry-After\") ?? 1);\n  await sleep(Math.max(1, delay) * 1000);\n  retryWithinBudget();\n}",
    "task": "Back off when the server signals rate limiting.",
    "acceptanceChecks": [
      "Retry-After is respected",
      "retry budget is bounded"
    ],
    "explanation": "Retrying immediately can worsen throttling and service load.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-043",
    "category": "System Design",
    "title": "Add a timeout to a downstream call",
    "starterCode": "const result = await dependency.fetchData();",
    "referenceSolution": "const result = await withTimeout(dependency.fetchData(), 3000);",
    "task": "Prevent a stalled dependency from holding a request indefinitely.",
    "acceptanceChecks": [
      "resolves under timeout",
      "rejects after timeout"
    ],
    "explanation": "Timeouts bound resource occupancy; cancellation should be propagated where supported.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-044",
    "category": "System Design",
    "title": "Avoid a single shared mutable cache",
    "starterCode": "cache[key] = value;",
    "referenceSolution": "cache.set(key, { value, expiresAt: Date.now() + ttlMs });\n// Evict expired entries on read and cap total size.",
    "task": "Add expiration and bounded growth to an in-memory cache.",
    "acceptanceChecks": [
      "expired value is not served",
      "cache size stays within configured cap"
    ],
    "explanation": "Caches need explicit freshness and memory policies.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-045",
    "category": "Git & DevOps",
    "title": "Run tests before packaging",
    "starterCode": "npm run build",
    "referenceSolution": "npm ci && npm test && npm run build",
    "task": "Install from the lockfile, run tests, and only build after checks pass.",
    "acceptanceChecks": [
      "lockfile controls dependency resolution",
      "test failure blocks release"
    ],
    "explanation": "Reproducible CI should fail fast when tests fail.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-046",
    "category": "Git & DevOps",
    "title": "Keep secrets out of the image",
    "starterCode": "ENV API_TOKEN=super-secret",
    "referenceSolution": "// Inject API_TOKEN at runtime from a managed secret store.\n// Never bake credentials into the image layers.",
    "task": "Ensure secrets are not recoverable from a container image.",
    "acceptanceChecks": [
      "image history contains no secret",
      "runtime receives secret securely"
    ],
    "explanation": "Build-time image layers can persist secrets even after deletion.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-047",
    "category": "TypeScript",
    "title": "Make a discriminated union exhaustive",
    "starterCode": "if (event.type === \"created\") handleCreated(event);",
    "referenceSolution": "switch (event.type) {\n  case \"created\": return handleCreated(event);\n  case \"deleted\": return handleDeleted(event);\n  default: { const neverEvent: never = event; return neverEvent; }\n}",
    "task": "Handle every event variant and let the compiler flag missing cases.",
    "acceptanceChecks": [
      "all known variants handled",
      "adding a new variant causes compile error"
    ],
    "explanation": "A never check makes union handling exhaustive.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-048",
    "category": "TypeScript",
    "title": "Avoid unsafe any",
    "starterCode": "function parse(input: any) { return input.user.name; }",
    "referenceSolution": "function parse(input: unknown) {\n  if (typeof input === \"object\" && input !== null && \"user\" in input) {\n    const user = input.user;\n    if (typeof user === \"object\" && user !== null && \"name\" in user && typeof user.name === \"string\") return user.name;\n  }\n  throw new Error(\"Invalid input\");\n}",
    "task": "Validate untrusted data before reading nested fields.",
    "acceptanceChecks": [
      "valid payload returns name",
      "malformed payload throws a clear error"
    ],
    "explanation": "unknown forces explicit validation where any would disable type checking.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-049",
    "category": "Operating Systems",
    "title": "Protect a shared counter",
    "starterCode": "counter = counter + 1",
    "referenceSolution": "lock.acquire();\ntry { counter = counter + 1; }\nfinally { lock.release(); }",
    "task": "Make a read-modify-write counter update atomic across threads.",
    "acceptanceChecks": [
      "parallel increments are not lost",
      "lock is released after exceptions"
    ],
    "explanation": "A mutex protects the critical section and finally guarantees release.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-050",
    "category": "Operating Systems",
    "title": "Close a socket after use",
    "starterCode": "const socket = connect();\nawait socket.send(payload);",
    "referenceSolution": "const socket = connect();\ntry { await socket.send(payload); }\nfinally { socket.close(); }",
    "task": "Release the socket even when sending fails.",
    "acceptanceChecks": [
      "socket closes on success",
      "socket closes on failure"
    ],
    "explanation": "Resource cleanup belongs in a finally or structured resource scope.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-051",
    "category": "Python",
    "title": "Validate a positive page limit",
    "starterCode": "def page_limit(value):\n    return int(value)",
    "referenceSolution": "def page_limit(value):\n    parsed = int(value)\n    if parsed < 1 or parsed > 200:\n        raise ValueError(\"page limit out of range\")\n    return parsed",
    "task": "Accept integer-like values only inside the documented 1\u2013200 range.",
    "acceptanceChecks": [
      "0 is rejected",
      "200 is accepted",
      "201 is rejected"
    ],
    "explanation": "Validate bounds after parsing, and fail clearly instead of accepting unsafe limits.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-052",
    "category": "Python",
    "title": "Avoid shadowing a built-in",
    "starterCode": "list = [1, 2, 3]\nresult = list((4, 5))",
    "referenceSolution": "values = [1, 2, 3]\nresult = list((4, 5))",
    "task": "Keep the built-in list constructor available.",
    "acceptanceChecks": [
      "list((4, 5)) creates a list",
      "values remains unchanged"
    ],
    "explanation": "Binding a variable named list hides the built-in in the current scope.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-053",
    "category": "Python",
    "title": "Use a set for allowed roles",
    "starterCode": "if role == \"admin\" or role == \"editor\" or role == \"reviewer\":\n    allow()",
    "referenceSolution": "if role in {\"admin\", \"editor\", \"reviewer\"}:\n    allow()",
    "task": "Make a membership policy concise and easy to extend.",
    "acceptanceChecks": [
      "all allowed roles pass",
      "unknown role is denied"
    ],
    "explanation": "A set communicates membership and is efficient for repeated checks.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-054",
    "category": "Python",
    "title": "Make JSON serialization explicit",
    "starterCode": "json.dumps(record, default=str)",
    "referenceSolution": "json.dumps(record)",
    "task": "Reject unsupported values instead of silently converting them to strings.",
    "acceptanceChecks": [
      "unsupported value raises TypeError",
      "supported JSON values serialize"
    ],
    "explanation": "A permissive fallback can hide schema mistakes and change data semantics.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-055",
    "category": "Python",
    "title": "Avoid catching cancellation as success",
    "starterCode": "try:\n    await worker()\nexcept BaseException:\n    return None",
    "referenceSolution": "try:\n    await worker()\nexcept Exception:\n    raise",
    "task": "Do not swallow process-level cancellation and termination signals.",
    "acceptanceChecks": [
      "cancellation propagates",
      "ordinary worker exceptions propagate"
    ],
    "explanation": "BaseException includes control-flow exceptions that applications should not usually suppress.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-056",
    "category": "JavaScript",
    "title": "Use textContent for plain text",
    "starterCode": "node.innerHTML = userComment;",
    "referenceSolution": "node.textContent = userComment;",
    "task": "Display user-provided text without parsing it as HTML.",
    "acceptanceChecks": [
      "script-like text remains text",
      "no new elements are created"
    ],
    "explanation": "textContent treats input as text and avoids an HTML injection sink.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-057",
    "category": "JavaScript",
    "title": "Use a map for repeated lookups",
    "starterCode": "const names = users.map(u => u.id);\nconst user = users.find(u => u.id === target);",
    "referenceSolution": "const byId = new Map(users.map((user) => [user.id, user]));\nconst user = byId.get(target);",
    "task": "Build an index when many lookups will be performed against the same collection.",
    "acceptanceChecks": [
      "known id returns matching user",
      "unknown id returns undefined"
    ],
    "explanation": "A map avoids rescanning the entire array for every lookup.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-058",
    "category": "JavaScript",
    "title": "Avoid floating point money errors",
    "starterCode": "const total = 0.1 + 0.2;",
    "referenceSolution": "const cents = 10 + 20;\nconst total = cents / 100;",
    "task": "Represent fixed decimal currency using integer minor units or a decimal library.",
    "acceptanceChecks": [
      "10 cents plus 20 cents equals 30 cents",
      "no binary floating point accumulation"
    ],
    "explanation": "Binary floating point cannot exactly represent many decimal fractions.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-059",
    "category": "JavaScript",
    "title": "Debounce a search input",
    "starterCode": "input.addEventListener(\"input\", search);",
    "referenceSolution": "let timer;\ninput.addEventListener(\"input\", () => {\n  clearTimeout(timer);\n  timer = setTimeout(search, 250);\n});",
    "task": "Wait briefly after typing stops before issuing an expensive search.",
    "acceptanceChecks": [
      "rapid keystrokes produce one search",
      "final query is used"
    ],
    "explanation": "Debouncing coalesces rapid events into one delayed action.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-060",
    "category": "JavaScript",
    "title": "Avoid unhandled fire-and-forget promises",
    "starterCode": "saveDraft();",
    "referenceSolution": "void saveDraft().catch((error) => reportError(error));",
    "task": "Handle failures from a deliberately unawaited asynchronous task.",
    "acceptanceChecks": [
      "rejection is observed",
      "error is reported"
    ],
    "explanation": "A floating promise can reject without an explicit handler.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-061",
    "category": "SQL",
    "title": "Filter dates with a half-open interval",
    "starterCode": "WHERE created_at BETWEEN :start AND :end",
    "referenceSolution": "WHERE created_at >= :start AND created_at < :next_day",
    "task": "Select a calendar day without double-counting the next day boundary.",
    "acceptanceChecks": [
      "start instant included",
      "next day midnight excluded"
    ],
    "explanation": "Half-open intervals compose cleanly across adjacent time windows.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-062",
    "category": "SQL",
    "title": "Avoid selecting every column",
    "starterCode": "SELECT * FROM employees WHERE id = :id;",
    "referenceSolution": "SELECT id, display_name, department FROM employees WHERE id = :id;",
    "task": "Retrieve only fields required by the caller.",
    "acceptanceChecks": [
      "response excludes private columns",
      "query returns required fields"
    ],
    "explanation": "Explicit projections reduce accidental data exposure and unnecessary transfer.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-063",
    "category": "SQL",
    "title": "Enforce uniqueness in the database",
    "starterCode": "-- Application checks for duplicate email before insert.",
    "referenceSolution": "ALTER TABLE users ADD CONSTRAINT users_email_unique UNIQUE (email);",
    "task": "Make email uniqueness race-safe across concurrent requests.",
    "acceptanceChecks": [
      "duplicate insert is rejected",
      "concurrent inserts cannot both claim same value"
    ],
    "explanation": "Application pre-checks race; the database constraint is authoritative.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-064",
    "category": "SQL",
    "title": "Use a window function for ranking",
    "starterCode": "-- Sort all employees and calculate rank in application code.",
    "referenceSolution": "SELECT employee_id, salary, RANK() OVER (ORDER BY salary DESC) AS salary_rank FROM employees;",
    "task": "Calculate rank without collapsing individual rows.",
    "acceptanceChecks": [
      "ties share rank",
      "all employee rows remain present"
    ],
    "explanation": "Window functions compute values across related rows while preserving row detail.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-065",
    "category": "Algorithms",
    "title": "Use two pointers for a sorted pair sum",
    "starterCode": "// Check every pair with nested loops.",
    "referenceSolution": "let left = 0, right = values.length - 1;\nwhile (left < right) {\n  const sum = values[left] + values[right];\n  if (sum === target) return [left, right];\n  if (sum < target) left++; else right--;\n}\nreturn null;",
    "task": "Find a pair in a sorted array using linear time.",
    "acceptanceChecks": [
      "matching pair is returned",
      "no pair returns null",
      "pointers move inward"
    ],
    "explanation": "Sorted order allows each comparison to eliminate one side.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-066",
    "category": "Algorithms",
    "title": "Mark nodes when enqueued",
    "starterCode": "for (const neighbor of graph[node]) {\n  if (!visited.has(neighbor)) queue.push(neighbor);\n}",
    "referenceSolution": "for (const neighbor of graph[node]) {\n  if (!visited.has(neighbor)) {\n    visited.add(neighbor);\n    queue.push(neighbor);\n  }\n}",
    "task": "Prevent a graph vertex from entering the BFS queue multiple times.",
    "acceptanceChecks": [
      "each vertex enqueued at most once",
      "cycles terminate"
    ],
    "explanation": "Marking on enqueue prevents duplicate pending work in cyclic graphs.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-067",
    "category": "Algorithms",
    "title": "Use a monotonic stack for next greater element",
    "starterCode": "// For each value, scan every later value.",
    "referenceSolution": "const result = Array(values.length).fill(-1);\nconst stack = [];\nfor (let i = 0; i < values.length; i++) {\n  while (stack.length && values[i] > values[stack.at(-1)]) result[stack.pop()] = values[i];\n  stack.push(i);\n}",
    "task": "Find the next greater value to the right for every array element.",
    "acceptanceChecks": [
      "unmatched values remain -1",
      "each index pushed and popped at most once"
    ],
    "explanation": "The monotonic stack makes the total work linear.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-068",
    "category": "Algorithms",
    "title": "Avoid integer overflow in midpoint",
    "starterCode": "const mid = (low + high) >> 1;",
    "referenceSolution": "const mid = low + Math.floor((high - low) / 2);",
    "task": "Calculate a safe midpoint for large index bounds.",
    "acceptanceChecks": [
      "mid lies between low and high",
      "no signed 32-bit truncation"
    ],
    "explanation": "Bitwise operators coerce JavaScript numbers to signed 32-bit integers.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-069",
    "category": "React",
    "title": "Use a functional update for dependent state",
    "starterCode": "setCount(count + 1);\nsetCount(count + 1);",
    "referenceSolution": "setCount((value) => value + 1);\nsetCount((value) => value + 1);",
    "task": "Apply two increments based on the latest queued state.",
    "acceptanceChecks": [
      "count increases by two",
      "no stale render value used"
    ],
    "explanation": "Functional updates compose correctly when multiple updates are queued.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-070",
    "category": "React",
    "title": "Keep effect dependencies complete",
    "starterCode": "useEffect(() => {\n  loadUser(userId);\n}, []);",
    "referenceSolution": "useEffect(() => {\n  loadUser(userId);\n}, [userId]);",
    "task": "Reload the user when the identifier changes.",
    "acceptanceChecks": [
      "new userId triggers load",
      "same userId does not trigger unnecessary reload"
    ],
    "explanation": "Effects must declare reactive values they read.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-071",
    "category": "React",
    "title": "Use a button for an action",
    "starterCode": "<div onClick={save}>Save</div>",
    "referenceSolution": "<button type=\"button\" onClick={save}>Save</button>",
    "task": "Provide native keyboard and accessibility behavior for an action.",
    "acceptanceChecks": [
      "Enter and Space activate control",
      "control has button semantics"
    ],
    "explanation": "Native buttons provide focus and activation behavior without custom emulation.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-072",
    "category": "React",
    "title": "Prevent stale async response wins",
    "starterCode": "useEffect(() => { fetchUser(id).then(setUser); }, [id]);",
    "referenceSolution": "useEffect(() => {\n  let active = true;\n  fetchUser(id).then((value) => { if (active) setUser(value); });\n  return () => { active = false; };\n}, [id]);",
    "task": "Ignore a slower response for an old identifier after a newer request begins.",
    "acceptanceChecks": [
      "old response cannot overwrite new user",
      "cleanup disables stale completion"
    ],
    "explanation": "An effect cleanup flag prevents stale asynchronous results from committing.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-073",
    "category": "Security",
    "title": "Set secure cookie attributes",
    "starterCode": "Set-Cookie: session=abc; Path=/",
    "referenceSolution": "Set-Cookie: session=abc; Path=/; Secure; HttpOnly; SameSite=Lax",
    "task": "Harden a session cookie for a browser application.",
    "acceptanceChecks": [
      "cookie is HTTPS-only",
      "JavaScript cannot read cookie",
      "cross-site sending is restricted"
    ],
    "explanation": "Secure, HttpOnly, and SameSite reduce common session theft and CSRF risks.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-074",
    "category": "Security",
    "title": "Do not trust client-supplied user IDs",
    "starterCode": "function getOrders(request) { return db.orders.find({ userId: request.body.userId }); }",
    "referenceSolution": "function getOrders(request) {\n  const userId = request.authenticatedPrincipal.id;\n  return db.orders.find({ userId });\n}",
    "task": "Scope private data access to the authenticated principal.",
    "acceptanceChecks": [
      "changing request body userId does not expose another account",
      "own orders remain accessible"
    ],
    "explanation": "Authorization context must come from verified identity, not arbitrary request fields.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-075",
    "category": "Security",
    "title": "Rotate a compromised secret",
    "starterCode": "// Keep using the leaked API token until next release.",
    "referenceSolution": "// Revoke the exposed token, issue a replacement, update consumers,\n// verify the old token fails, and review access logs.",
    "task": "Respond to a leaked credential with revocation and verification.",
    "acceptanceChecks": [
      "old token no longer authenticates",
      "new token works",
      "audit trail is reviewed"
    ],
    "explanation": "A leaked secret remains compromised until it is revoked, not merely hidden.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-076",
    "category": "Security",
    "title": "Restrict CORS origins",
    "starterCode": "Access-Control-Allow-Origin: *",
    "referenceSolution": "Access-Control-Allow-Origin: https://app.example.com\nVary: Origin",
    "task": "Allow only the intended browser origin for credentialed access.",
    "acceptanceChecks": [
      "untrusted origin is not allowed",
      "approved origin is allowed"
    ],
    "explanation": "Wildcard CORS is not an authorization system and is unsafe for sensitive credentialed APIs.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-077",
    "category": "Networking",
    "title": "Honor request cancellation",
    "starterCode": "const response = await fetch(url);",
    "referenceSolution": "const controller = new AbortController();\nconst response = await fetch(url, { signal: controller.signal });\n// Call controller.abort() when the request is no longer needed.",
    "task": "Allow callers to cancel work they no longer need.",
    "acceptanceChecks": [
      "abort stops pending fetch",
      "abort error is handled intentionally"
    ],
    "explanation": "AbortController lets callers cancel fetch and related asynchronous work.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-078",
    "category": "Networking",
    "title": "Validate content type before parsing JSON",
    "starterCode": "const data = await response.json();",
    "referenceSolution": "const contentType = response.headers.get(\"content-type\") ?? \"\";\nif (!contentType.includes(\"application/json\")) throw new Error(\"Unexpected content type\");\nconst data = await response.json();",
    "task": "Reject an unexpected response representation before parsing.",
    "acceptanceChecks": [
      "JSON content type parses",
      "HTML error page is rejected clearly"
    ],
    "explanation": "Content-type validation avoids confusing parse errors and unsafe assumptions.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-079",
    "category": "System Design",
    "title": "Separate liveness and readiness",
    "starterCode": "/health returns 200 only when every dependency is reachable.",
    "referenceSolution": "/live reports whether the process is alive; /ready reports whether it can serve traffic.",
    "task": "Prevent transient dependency failures from causing restart loops.",
    "acceptanceChecks": [
      "liveness stays healthy when process is alive",
      "readiness fails when service cannot serve"
    ],
    "explanation": "Liveness controls restarts; readiness controls traffic routing.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-080",
    "category": "System Design",
    "title": "Use an outbox for reliable event publishing",
    "starterCode": "saveOrder(order);\npublishEvent(orderCreated);",
    "referenceSolution": "BEGIN;\nINSERT INTO orders (...);\nINSERT INTO outbox_events (...);\nCOMMIT;\n// A worker publishes outbox rows and marks them delivered.",
    "task": "Avoid losing an event between a database commit and a message publish.",
    "acceptanceChecks": [
      "order and outbox record commit together",
      "worker retries undelivered event"
    ],
    "explanation": "The transactional outbox records the event in the same transaction as the business write.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-081",
    "category": "System Design",
    "title": "Set a cache invalidation strategy",
    "starterCode": "cache.set(productId, product);",
    "referenceSolution": "cache.set(productId, product, { ttl: 60 });\n// Invalidate the key after a successful product update.",
    "task": "Bound cache staleness and invalidate after writes.",
    "acceptanceChecks": [
      "entry expires after TTL",
      "write invalidates stale cached value"
    ],
    "explanation": "Caching needs explicit expiry and write-through invalidation behavior.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-082",
    "category": "Git & DevOps",
    "title": "Use a lockfile in CI",
    "starterCode": "npm install",
    "referenceSolution": "npm ci",
    "task": "Install exact dependency versions in a clean automated environment.",
    "acceptanceChecks": [
      "lockfile is required",
      "existing node_modules is replaced consistently"
    ],
    "explanation": "npm ci is designed for reproducible clean installs in automation.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-083",
    "category": "Git & DevOps",
    "title": "Separate build-time and runtime config",
    "starterCode": "const apiUrl = \"https://prod.example.com\";",
    "referenceSolution": "const apiUrl = import.meta.env.VITE_API_URL;\n// Keep secrets out of VITE_* variables; client values are public.",
    "task": "Make public endpoint configuration environment-specific without embedding credentials.",
    "acceptanceChecks": [
      "preview can use preview endpoint",
      "no secret is bundled into client code"
    ],
    "explanation": "Frontend build variables are visible to users; only non-secret configuration belongs there.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-084",
    "category": "TypeScript",
    "title": "Model optional fields explicitly",
    "starterCode": "interface User { id: string; nickname: string; }",
    "referenceSolution": "interface User { id: string; nickname?: string | null; }",
    "task": "Represent a nickname that may be omitted or explicitly null.",
    "acceptanceChecks": [
      "object without nickname type-checks",
      "null nickname is represented"
    ],
    "explanation": "Optional and nullable are distinct states and should match the data contract.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-085",
    "category": "TypeScript",
    "title": "Avoid non-null assertions on API data",
    "starterCode": "const name = response.user!.name;",
    "referenceSolution": "if (!response.user) throw new Error(\"User missing from response\");\nconst name = response.user.name;",
    "task": "Handle an absent user field at runtime rather than suppressing the type checker.",
    "acceptanceChecks": [
      "missing user produces a controlled error",
      "present user name is read"
    ],
    "explanation": "The non-null assertion has no runtime effect and can turn malformed data into a crash.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-086",
    "category": "Operating Systems",
    "title": "Bound worker concurrency",
    "starterCode": "await Promise.all(tasks.map(runTask));",
    "referenceSolution": "const limit = 5;\nfor (let i = 0; i < tasks.length; i += limit) {\n  await Promise.all(tasks.slice(i, i + limit).map(runTask));\n}",
    "task": "Avoid launching thousands of resource-intensive tasks at once.",
    "acceptanceChecks": [
      "at most five tasks active per batch",
      "all tasks eventually run"
    ],
    "explanation": "Bounded concurrency controls resource use and protects downstream services.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-087",
    "category": "Operating Systems",
    "title": "Use monotonic time for elapsed duration",
    "starterCode": "const elapsed = Date.now() - startedAt;",
    "referenceSolution": "const startedAt = performance.now();\nconst elapsed = performance.now() - startedAt;",
    "task": "Measure elapsed duration without wall-clock adjustments.",
    "acceptanceChecks": [
      "elapsed is nonnegative",
      "system clock changes do not skew duration"
    ],
    "explanation": "A monotonic clock is designed for measuring intervals.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-088",
    "category": "Python",
    "title": "Use pathlib for filesystem paths",
    "starterCode": "path = base + \"/reports/summary.txt\"",
    "referenceSolution": "from pathlib import Path\npath = Path(base) / \"reports\" / \"summary.txt\"",
    "task": "Build a portable filesystem path without manual separator handling.",
    "acceptanceChecks": [
      "path joins correctly on supported platforms"
    ],
    "explanation": "pathlib models filesystem paths and joins path components safely.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-089",
    "category": "Python",
    "title": "Stream a large file",
    "starterCode": "lines = open(path).readlines()",
    "referenceSolution": "with open(path, encoding=\"utf-8\") as source:\n    for line in source:\n        process(line)",
    "task": "Process a large text file without loading every line into memory.",
    "acceptanceChecks": [
      "each line is processed once",
      "file closes after iteration"
    ],
    "explanation": "File iteration streams lines and the context manager closes the resource.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-090",
    "category": "Python",
    "title": "Make dataclass fields safe",
    "starterCode": "@dataclass\nclass Job:\n    tags: list = []",
    "referenceSolution": "@dataclass\nclass Job:\n    tags: list[str] = field(default_factory=list)",
    "task": "Give every Job instance its own tags list.",
    "acceptanceChecks": [
      "two instances have independent lists"
    ],
    "explanation": "default_factory creates a fresh value per instance.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-091",
    "category": "Python",
    "title": "Use Decimal for decimal arithmetic",
    "starterCode": "total = 0.1 + 0.2",
    "referenceSolution": "from decimal import Decimal\ntotal = Decimal(\"0.1\") + Decimal(\"0.2\")",
    "task": "Represent decimal quantities exactly for financial calculations.",
    "acceptanceChecks": [
      "total equals Decimal(\"0.3\")"
    ],
    "explanation": "Decimal avoids binary floating point representation artifacts.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-092",
    "category": "Python",
    "title": "Avoid blocking the event loop",
    "starterCode": "async def handler():\n    time.sleep(2)",
    "referenceSolution": "async def handler():\n    await asyncio.sleep(2)",
    "task": "Wait asynchronously without blocking the event loop.",
    "acceptanceChecks": [
      "other tasks continue while waiting"
    ],
    "explanation": "A blocking sleep prevents the event loop from scheduling other coroutines.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-093",
    "category": "JavaScript",
    "title": "Normalize user input",
    "starterCode": "const email = input.trim();",
    "referenceSolution": "const email = input.trim().toLowerCase();",
    "task": "Normalize email casing and whitespace before comparison.",
    "acceptanceChecks": [
      "surrounding whitespace removed",
      "case differences normalized"
    ],
    "explanation": "Canonicalization avoids inconsistent comparisons; preserve original display if needed.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-094",
    "category": "JavaScript",
    "title": "Avoid accidental global assignment",
    "starterCode": "function update() {\n  total = 10;\n}",
    "referenceSolution": "function update() {\n  const total = 10;\n  return total;\n}",
    "task": "Declare local bindings explicitly and return the value.",
    "acceptanceChecks": [
      "no global variable is created"
    ],
    "explanation": "Undeclared assignment can leak state or throw in strict mode.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-095",
    "category": "JavaScript",
    "title": "Clone nested data intentionally",
    "starterCode": "const copy = { ...original };",
    "referenceSolution": "const copy = structuredClone(original);",
    "task": "Create a deep clone of supported structured data when nested mutation isolation is required.",
    "acceptanceChecks": [
      "nested objects are not shared"
    ],
    "explanation": "Object spread is shallow; structuredClone supports deep cloning of supported values.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-096",
    "category": "JavaScript",
    "title": "Handle missing local storage",
    "starterCode": "const settings = JSON.parse(localStorage.getItem(\"settings\"));",
    "referenceSolution": "const raw = localStorage.getItem(\"settings\");\nconst settings = raw ? JSON.parse(raw) : {};",
    "task": "Provide a default when the storage key has not been set.",
    "acceptanceChecks": [
      "missing key yields an object default"
    ],
    "explanation": "getItem returns null for an absent key; parsing null does not produce the desired application default.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-097",
    "category": "JavaScript",
    "title": "Avoid stale timer callbacks",
    "starterCode": "setInterval(() => refresh(currentId), 5000);",
    "referenceSolution": "const idAtStart = currentId;\nconst timer = setInterval(() => refresh(idAtStart), 5000);\n// Clear and recreate when currentId changes.",
    "task": "Ensure a polling callback uses the intended identifier and is cleaned up.",
    "acceptanceChecks": [
      "new identifier uses a new timer",
      "old timer is cleared"
    ],
    "explanation": "Timer lifecycle should follow the reactive value it depends on.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-098",
    "category": "SQL",
    "title": "Use a check constraint",
    "starterCode": "-- Application rejects negative inventory only.",
    "referenceSolution": "ALTER TABLE inventory ADD CONSTRAINT inventory_nonnegative CHECK (quantity >= 0);",
    "task": "Enforce nonnegative inventory even when data is written outside the application.",
    "acceptanceChecks": [
      "negative quantity rejected",
      "zero quantity accepted"
    ],
    "explanation": "Database constraints protect invariants across every write path.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-099",
    "category": "SQL",
    "title": "Use a composite index for the query",
    "starterCode": "SELECT * FROM tickets WHERE team_id = 7 AND status = 'open' ORDER BY created_at DESC;",
    "referenceSolution": "CREATE INDEX tickets_team_status_created_idx ON tickets(team_id, status, created_at DESC);",
    "task": "Support the common filter and ordering pattern with an appropriate index.",
    "acceptanceChecks": [
      "query plan can use the composite index",
      "write overhead is considered"
    ],
    "explanation": "Index column order should align with equality filters and ordering needs.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-100",
    "category": "SQL",
    "title": "Avoid updating every row accidentally",
    "starterCode": "UPDATE users SET active = false;",
    "referenceSolution": "UPDATE users SET active = false WHERE last_login_at < :cutoff;",
    "task": "Restrict the update to the intended inactive cohort.",
    "acceptanceChecks": [
      "only rows older than cutoff change"
    ],
    "explanation": "A missing WHERE clause can mutate the entire table.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-101",
    "category": "SQL",
    "title": "Use EXISTS for relationship checks",
    "starterCode": "SELECT u.* FROM users u JOIN orders o ON o.user_id = u.id;",
    "referenceSolution": "SELECT u.* FROM users u WHERE EXISTS (SELECT 1 FROM orders o WHERE o.user_id = u.id);",
    "task": "Return each user once when at least one related order exists.",
    "acceptanceChecks": [
      "users with multiple orders appear once"
    ],
    "explanation": "EXISTS expresses a semijoin and avoids duplicate user rows.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-102",
    "category": "Algorithms",
    "title": "Use a frequency map",
    "starterCode": "// Compare every pair to count equal values.",
    "referenceSolution": "const counts = new Map();\nfor (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);",
    "task": "Count occurrences in expected linear time.",
    "acceptanceChecks": [
      "each value has its frequency"
    ],
    "explanation": "A hash map aggregates counts in one pass.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-103",
    "category": "Algorithms",
    "title": "Use a deque for sliding windows",
    "starterCode": "// Remove the first element with array.shift() each iteration.",
    "referenceSolution": "// Use a deque with O(1) push/pop at both ends.\n// Maintain only indexes that remain inside the active window.",
    "task": "Keep sliding-window updates efficient for large arrays.",
    "acceptanceChecks": [
      "each index enters and leaves deque at most once"
    ],
    "explanation": "A deque avoids repeated array reindexing and supports monotonic-window patterns.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-104",
    "category": "Algorithms",
    "title": "Memoize recursive parsing",
    "starterCode": "function parse(node) { return parseChildren(node); }",
    "referenceSolution": "const memo = new WeakMap();\nfunction parse(node) {\n  if (memo.has(node)) return memo.get(node);\n  const result = parseChildren(node);\n  memo.set(node, result);\n  return result;\n}",
    "task": "Avoid recomputing results for the same object node.",
    "acceptanceChecks": [
      "same node reuses cached result"
    ],
    "explanation": "A WeakMap can cache object-keyed results without keeping keys alive solely because of the cache.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-105",
    "category": "Algorithms",
    "title": "Check bounds before matrix access",
    "starterCode": "const value = matrix[row][column];",
    "referenceSolution": "if (row < 0 || row >= matrix.length || column < 0 || column >= matrix[row].length) return null;\nconst value = matrix[row][column];",
    "task": "Avoid invalid row or column access.",
    "acceptanceChecks": [
      "negative indexes rejected",
      "valid coordinates return cell"
    ],
    "explanation": "Explicit bounds checks make edge behavior predictable.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-106",
    "category": "React",
    "title": "Use an accessible status message",
    "starterCode": "{saved && <span>Saved</span>}",
    "referenceSolution": "{saved && <span role=\"status\" aria-live=\"polite\">Saved</span>}",
    "task": "Announce a save confirmation to assistive technology.",
    "acceptanceChecks": [
      "status is announced without moving focus"
    ],
    "explanation": "A polite live region communicates asynchronous status updates.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-107",
    "category": "React",
    "title": "Avoid nested interactive controls",
    "starterCode": "<button><a href=\"/profile\">Profile</a></button>",
    "referenceSolution": "<a className=\"button-link\" href=\"/profile\">Profile</a>",
    "task": "Use one interactive element for one action.",
    "acceptanceChecks": [
      "keyboard navigation has one stop"
    ],
    "explanation": "Nested interactive controls create invalid semantics and confusing focus behavior.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-108",
    "category": "React",
    "title": "Reset state when entity identity changes",
    "starterCode": "// Reuse editor state when selectedDocument changes.",
    "referenceSolution": "<DocumentEditor key={selectedDocument.id} document={selectedDocument} />",
    "task": "Reset editor-local state when switching to a different document.",
    "acceptanceChecks": [
      "new document starts with fresh editor state"
    ],
    "explanation": "A key changes component identity and resets its local state.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-109",
    "category": "React",
    "title": "Avoid expensive work on every render",
    "starterCode": "const sorted = items.slice().sort(compareItems);",
    "referenceSolution": "const sorted = useMemo(() => items.slice().sort(compareItems), [items]);",
    "task": "Memoize an expensive derived sort while the source array is unchanged.",
    "acceptanceChecks": [
      "same array reference reuses derived value"
    ],
    "explanation": "useMemo can avoid repeated expensive calculations when dependencies are stable.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-110",
    "category": "Security",
    "title": "Escape output for the target context",
    "starterCode": "const html = `<p>${comment}</p>`;",
    "referenceSolution": "const paragraph = document.createElement(\"p\");\nparagraph.textContent = comment;",
    "task": "Render untrusted text without interpreting it as markup.",
    "acceptanceChecks": [
      "HTML-like input displays literally"
    ],
    "explanation": "Output encoding must match the context; DOM text nodes avoid HTML parsing.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-111",
    "category": "Security",
    "title": "Apply CSRF protection to cookie auth",
    "starterCode": "// State-changing endpoint accepts any cross-site form post.",
    "referenceSolution": "// Validate a CSRF token and Origin/Referer policy on state-changing requests.",
    "task": "Prevent cross-site requests from using ambient session cookies.",
    "acceptanceChecks": [
      "missing or invalid token is rejected",
      "legitimate same-site request succeeds"
    ],
    "explanation": "Cookie authentication requires a deliberate CSRF defense for state changes.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-112",
    "category": "Security",
    "title": "Limit authentication attempts",
    "starterCode": "// Accept unlimited password attempts.",
    "referenceSolution": "// Apply per-account and per-source throttling, progressive delays, and monitoring.",
    "task": "Reduce online password guessing while avoiding easy account lockout denial-of-service.",
    "acceptanceChecks": [
      "repeated attempts are throttled",
      "legitimate recovery path remains available"
    ],
    "explanation": "Rate limiting should balance abuse resistance and user recovery.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-113",
    "category": "Security",
    "title": "Verify webhook signatures",
    "starterCode": "if (request.body.event) process(request.body);",
    "referenceSolution": "// Verify provider signature over the raw request body before processing.\nif (verifySignature(rawBody, signature, secret)) process(JSON.parse(rawBody));",
    "task": "Accept webhook events only after verifying their authenticity and integrity.",
    "acceptanceChecks": [
      "invalid signature rejected",
      "valid signed event processed"
    ],
    "explanation": "Webhook payloads are untrusted until the provider signature is validated.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-114",
    "category": "Networking",
    "title": "Use connection pooling",
    "starterCode": "const db = createConnection(); // for every request",
    "referenceSolution": "const db = createPool({ min: 2, max: 10 });",
    "task": "Reuse a bounded set of database connections across requests.",
    "acceptanceChecks": [
      "connections are reused",
      "pool size is capped"
    ],
    "explanation": "Connection pools reduce setup overhead and protect the database from connection storms.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-115",
    "category": "Networking",
    "title": "Set a request body size limit",
    "starterCode": "app.use(express.json());",
    "referenceSolution": "app.use(express.json({ limit: \"1mb\" }));",
    "task": "Reject oversized JSON bodies before they consume excessive memory.",
    "acceptanceChecks": [
      "small payload accepted",
      "oversized payload rejected"
    ],
    "explanation": "Request size limits reduce resource-exhaustion risk.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-116",
    "category": "Networking",
    "title": "Use pagination cursor validation",
    "starterCode": "const rows = await query({ cursor: req.query.cursor });",
    "referenceSolution": "const cursor = validateAndDecodeCursor(req.query.cursor);\nconst rows = await query({ cursor });",
    "task": "Treat pagination cursors as untrusted input and validate their format.",
    "acceptanceChecks": [
      "malformed cursor rejected",
      "valid cursor maps to expected boundary"
    ],
    "explanation": "Cursors are client-controlled input and need validation and integrity checks.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-117",
    "category": "System Design",
    "title": "Design graceful shutdown",
    "starterCode": "process.on(\"SIGTERM\", () => process.exit(0));",
    "referenceSolution": "process.on(\"SIGTERM\", async () => {\n  server.close();\n  await drainInFlightRequests();\n  await closeDependencies();\n  process.exit(0);\n});",
    "task": "Stop accepting new work and drain active requests before process exit.",
    "acceptanceChecks": [
      "new requests stop",
      "in-flight work is drained",
      "dependencies close"
    ],
    "explanation": "Graceful shutdown prevents interrupted requests and resource leaks during deployment.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-118",
    "category": "System Design",
    "title": "Avoid synchronous service chaining",
    "starterCode": "await inventory.reserve();\nawait billing.charge();\nawait shipping.create();",
    "referenceSolution": "// Persist a workflow state and use an orchestrated saga with compensating actions.",
    "task": "Handle partial failure across multiple independently committed services.",
    "acceptanceChecks": [
      "failure after charge triggers compensation or reconciliation",
      "workflow state is observable"
    ],
    "explanation": "A saga models distributed steps and compensations without pretending there is one global transaction.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-119",
    "category": "System Design",
    "title": "Use a bulkhead for dependencies",
    "starterCode": "await Promise.all([search(), billing(), profile()]);",
    "referenceSolution": "// Use separate bounded concurrency pools and timeouts for each dependency.",
    "task": "Prevent one slow dependency from consuming all request capacity.",
    "acceptanceChecks": [
      "search saturation does not exhaust billing capacity"
    ],
    "explanation": "Bulkheads isolate resource pools so one failure domain does not sink others.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-120",
    "category": "Git & DevOps",
    "title": "Use a health check in container image",
    "starterCode": "FROM node:22\nCMD [\"node\", \"server.js\"]",
    "referenceSolution": "FROM node:22\nHEALTHCHECK --interval=30s --timeout=3s CMD node healthcheck.js\nCMD [\"node\", \"server.js\"]",
    "task": "Expose a repeatable health probe for the container runtime.",
    "acceptanceChecks": [
      "healthy service reports success",
      "unavailable service reports failure"
    ],
    "explanation": "Health checks let orchestrators observe service readiness or liveness according to configuration.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-121",
    "category": "Git & DevOps",
    "title": "Sign release artifacts",
    "starterCode": "build();\npublish();",
    "referenceSolution": "build();\nsignArtifact();\nverifySignatureInReleasePipeline();\npublish();",
    "task": "Verify artifact integrity and provenance before release.",
    "acceptanceChecks": [
      "unsigned artifact is blocked",
      "signature verification succeeds"
    ],
    "explanation": "Signing and verification help ensure released artifacts are the ones that were built and approved.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-122",
    "category": "TypeScript",
    "title": "Validate API payload with a schema",
    "starterCode": "const user = response as User;",
    "referenceSolution": "const user = UserSchema.parse(response);",
    "task": "Validate external data at runtime instead of trusting a type assertion.",
    "acceptanceChecks": [
      "invalid payload is rejected",
      "valid payload is typed after parsing"
    ],
    "explanation": "Type assertions do not validate runtime data; schema parsing does.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-123",
    "category": "TypeScript",
    "title": "Use readonly for immutable inputs",
    "starterCode": "function total(items: number[]) { /* read only */ }",
    "referenceSolution": "function total(items: readonly number[]) { /* read only */ }",
    "task": "Prevent the function from mutating the supplied array at compile time.",
    "acceptanceChecks": [
      "push is rejected by type checker",
      "iteration works"
    ],
    "explanation": "Readonly array types communicate and enforce non-mutation in the type system.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-124",
    "category": "Operating Systems",
    "title": "Avoid busy waiting",
    "starterCode": "while (!ready) { /* spin */ }",
    "referenceSolution": "while (!ready) { await waitForSignal(); }",
    "task": "Wait for readiness without burning CPU in a tight loop.",
    "acceptanceChecks": [
      "CPU use remains low while waiting",
      "signal resumes work"
    ],
    "explanation": "Blocking or event-driven waits are preferable to spinning when latency requirements allow.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-125",
    "category": "Operating Systems",
    "title": "Bound an in-memory queue",
    "starterCode": "queue.push(task);",
    "referenceSolution": "if (queue.length >= MAX_QUEUE_SIZE) reject(task);\nelse queue.push(task);",
    "task": "Prevent an overloaded worker queue from growing without limit.",
    "acceptanceChecks": [
      "queue never exceeds cap",
      "overflow is surfaced to caller"
    ],
    "explanation": "A bounded queue provides backpressure and predictable memory usage.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-126",
    "category": "Python",
    "title": "Validate an enum-like value",
    "starterCode": "status = request[\"status\"]",
    "referenceSolution": "allowed = {\"queued\", \"running\", \"complete\"}\nstatus = request.get(\"status\")\nif status not in allowed:\n    raise ValueError(\"Unsupported status\")",
    "task": "Reject unsupported status values before using them.",
    "acceptanceChecks": [
      "known status accepted",
      "unknown status rejected"
    ],
    "explanation": "An allow-list is safer than assuming request data is valid.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-127",
    "category": "Python",
    "title": "Use an iterator without copying",
    "starterCode": "for row in list(rows):\n    process(row)",
    "referenceSolution": "for row in rows:\n    process(row)",
    "task": "Process a potentially large iterable without materializing a second list.",
    "acceptanceChecks": [
      "iterable consumed once",
      "peak memory does not scale with an extra copy"
    ],
    "explanation": "Direct iteration avoids an unnecessary full copy.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-128",
    "category": "Python",
    "title": "Sort with a stable secondary key",
    "starterCode": "sorted(users, key=lambda u: u.age)",
    "referenceSolution": "sorted(users, key=lambda u: (u.age, u.name.casefold()))",
    "task": "Sort by age and then by case-insensitive name.",
    "acceptanceChecks": [
      "age ascending",
      "names sorted within equal ages"
    ],
    "explanation": "A tuple key expresses deterministic multi-field ordering.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-129",
    "category": "Python",
    "title": "Use logging placeholders",
    "starterCode": "logger.info(f\"Imported {count} rows\")",
    "referenceSolution": "logger.info(\"Imported %s rows\", count)",
    "task": "Defer formatting until the logging record is emitted.",
    "acceptanceChecks": [
      "message remains correct",
      "formatting is handled by logger"
    ],
    "explanation": "Parameterized logging avoids unnecessary interpolation when the level is disabled.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-130",
    "category": "Python",
    "title": "Return a typed result",
    "starterCode": "def parse_age(value):\n    return int(value)",
    "referenceSolution": "def parse_age(value: str) -> int:\n    age = int(value)\n    if age < 0:\n        raise ValueError(\"Age cannot be negative\")\n    return age",
    "task": "Document and validate the function contract.",
    "acceptanceChecks": [
      "negative age rejected",
      "valid age returned as int"
    ],
    "explanation": "Annotations clarify intent; runtime checks enforce domain rules.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-131",
    "category": "JavaScript",
    "title": "Use Object.hasOwn for own keys",
    "starterCode": "if (key in record) use(record[key]);",
    "referenceSolution": "if (Object.hasOwn(record, key)) use(record[key]);",
    "task": "Check whether a property belongs directly to an object.",
    "acceptanceChecks": [
      "inherited property is not accepted",
      "own property is accepted"
    ],
    "explanation": "The in operator also checks the prototype chain.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-132",
    "category": "JavaScript",
    "title": "Avoid JSON parse crashes",
    "starterCode": "const value = JSON.parse(raw);",
    "referenceSolution": "let value;\ntry { value = JSON.parse(raw); }\ncatch { value = fallback; }",
    "task": "Handle malformed persisted JSON with a safe default.",
    "acceptanceChecks": [
      "valid JSON parses",
      "malformed JSON falls back"
    ],
    "explanation": "Persisted or external data can be malformed; parsing should be guarded.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-133",
    "category": "JavaScript",
    "title": "Use a stable sort key",
    "starterCode": "items.sort((a, b) => a.name.localeCompare(b.name));",
    "referenceSolution": "items.slice().sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id));",
    "task": "Sort by name and break ties deterministically without mutating input.",
    "acceptanceChecks": [
      "same names ordered by id",
      "original array unchanged"
    ],
    "explanation": "A secondary key ensures deterministic order and slice avoids mutation.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-134",
    "category": "JavaScript",
    "title": "Avoid accidental promise nesting",
    "starterCode": "return fetchUser(id).then(user => Promise.resolve(user));",
    "referenceSolution": "return fetchUser(id);",
    "task": "Return the existing promise directly.",
    "acceptanceChecks": [
      "caller receives same fulfillment value",
      "no redundant wrapper"
    ],
    "explanation": "Promise chains automatically adopt returned promises.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-135",
    "category": "JavaScript",
    "title": "Guard against prototype keys",
    "starterCode": "const config = {}; config[userKey] = value;",
    "referenceSolution": "const config = Object.create(null); config[userKey] = value;",
    "task": "Store arbitrary dictionary keys without inheriting object prototype members.",
    "acceptanceChecks": [
      "toString is stored as a normal key",
      "no inherited properties"
    ],
    "explanation": "A null prototype can be useful for dictionary-like objects with untrusted keys.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-136",
    "category": "SQL",
    "title": "Use a partial index",
    "starterCode": "CREATE INDEX idx_events_status ON events(status);",
    "referenceSolution": "CREATE INDEX idx_events_open_created ON events(created_at) WHERE status = 'open';",
    "task": "Optimize the frequent query for open events while limiting index size.",
    "acceptanceChecks": [
      "open event query can use index",
      "closed rows are not in partial index"
    ],
    "explanation": "Partial indexes cover a filtered subset and can reduce storage and maintenance.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-137",
    "category": "SQL",
    "title": "Prevent lost updates",
    "starterCode": "SELECT balance FROM accounts WHERE id = :id; -- later update",
    "referenceSolution": "BEGIN;\nSELECT balance FROM accounts WHERE id = :id FOR UPDATE;\n-- validate and update while row lock is held\nCOMMIT;",
    "task": "Serialize concurrent balance changes to one account row.",
    "acceptanceChecks": [
      "concurrent transactions do not overwrite each other silently"
    ],
    "explanation": "A row lock protects the read-modify-write sequence within a transaction.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-138",
    "category": "SQL",
    "title": "Use NOT NULL for required data",
    "starterCode": "email TEXT",
    "referenceSolution": "email TEXT NOT NULL",
    "task": "Make the database reject records without a required email value.",
    "acceptanceChecks": [
      "null insert rejected",
      "non-null insert accepted"
    ],
    "explanation": "Schema constraints enforce required data regardless of application path.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-139",
    "category": "SQL",
    "title": "Use a generated identifier safely",
    "starterCode": "INSERT INTO users(id, name) VALUES (MAX(id)+1, :name);",
    "referenceSolution": "INSERT INTO users(name) VALUES (:name) RETURNING id;",
    "task": "Let the database allocate identifiers safely under concurrency.",
    "acceptanceChecks": [
      "concurrent inserts receive distinct IDs"
    ],
    "explanation": "MAX(id)+1 races under concurrent writes; identity or sequence values are safer.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-140",
    "category": "Algorithms",
    "title": "Use a prefix sum for range totals",
    "starterCode": "// Sum every element between left and right for each query.",
    "referenceSolution": "const prefix = [0];\nfor (const value of values) prefix.push(prefix.at(-1) + value);\nconst rangeSum = (left, right) => prefix[right + 1] - prefix[left];",
    "task": "Answer repeated range-sum queries in constant time after preprocessing.",
    "acceptanceChecks": [
      "range boundaries inclusive",
      "empty prefix starts at zero"
    ],
    "explanation": "Prefix sums turn each range query into a difference of two cumulative sums.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-141",
    "category": "Algorithms",
    "title": "Use topological ordering for dependencies",
    "starterCode": "// Process tasks in arbitrary order.",
    "referenceSolution": "// Build indegrees, enqueue zero-indegree nodes, and decrement neighbors as tasks complete.",
    "task": "Produce a valid order for a directed acyclic dependency graph.",
    "acceptanceChecks": [
      "every dependency precedes its dependent",
      "cycle is detected when not all nodes are emitted"
    ],
    "explanation": "Kahn\u2019s algorithm uses indegrees to construct a topological ordering.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-142",
    "category": "Algorithms",
    "title": "Detect a linked-list cycle",
    "starterCode": "// Traverse until node is null; may never finish.",
    "referenceSolution": "let slow = head, fast = head;\nwhile (fast && fast.next) { slow = slow.next; fast = fast.next.next; if (slow === fast) return true; }\nreturn false;",
    "task": "Detect a cycle without extra memory.",
    "acceptanceChecks": [
      "acyclic list returns false",
      "cyclic list returns true"
    ],
    "explanation": "Floyd\u2019s tortoise-and-hare algorithm uses two traversal speeds.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-143",
    "category": "React",
    "title": "Keep event handlers stable only when needed",
    "starterCode": "const handler = () => save(documentId);",
    "referenceSolution": "const handler = useCallback(() => save(documentId), [save, documentId]);",
    "task": "Provide a memoized callback when referential stability is required by a memoized child or effect.",
    "acceptanceChecks": [
      "callback updates when documentId changes"
    ],
    "explanation": "useCallback is useful for specific identity-sensitive boundaries, not automatically for every handler.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-144",
    "category": "React",
    "title": "Use an error fallback for async UI",
    "starterCode": "{data.value.name}",
    "referenceSolution": "{error ? <ErrorState /> : loading ? <LoadingState /> : <Profile data={data} />}",
    "task": "Represent loading, error, and success states explicitly.",
    "acceptanceChecks": [
      "loading state shown",
      "error state shown",
      "success state renders data"
    ],
    "explanation": "Async interfaces should model each state instead of dereferencing missing data.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-145",
    "category": "Security",
    "title": "Limit password reset token lifetime",
    "starterCode": "// Reset token remains valid indefinitely.",
    "referenceSolution": "// Store a cryptographically random, single-use token with a short expiry and hashed storage.",
    "task": "Reduce the risk of a stolen password reset link being reused.",
    "acceptanceChecks": [
      "expired token rejected",
      "used token rejected",
      "token value is not stored in plaintext"
    ],
    "explanation": "Short-lived, single-use reset tokens limit the impact of disclosure.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-146",
    "category": "Security",
    "title": "Avoid open redirects",
    "starterCode": "return redirect(request.query.next);",
    "referenceSolution": "const destination = allowlistedLocalPath(request.query.next) ? request.query.next : \"/\";\nreturn redirect(destination);",
    "task": "Prevent attackers from redirecting users to arbitrary external destinations.",
    "acceptanceChecks": [
      "external URL rejected",
      "approved local path accepted"
    ],
    "explanation": "Redirect targets are untrusted input and should be allow-listed.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-147",
    "category": "Networking",
    "title": "Validate TLS certificates",
    "starterCode": "client = createClient({ rejectUnauthorized: false });",
    "referenceSolution": "client = createClient({ rejectUnauthorized: true });",
    "task": "Verify the server certificate during TLS negotiation.",
    "acceptanceChecks": [
      "invalid certificate fails",
      "trusted certificate succeeds"
    ],
    "explanation": "Disabling certificate verification removes an essential authentication check.",
    "difficulty": "ADVANCED"
  },
  {
    "id": "code-148",
    "category": "Networking",
    "title": "Set explicit cache controls for private data",
    "starterCode": "Cache-Control: public, max-age=3600",
    "referenceSolution": "Cache-Control: private, no-store",
    "task": "Prevent shared caches from retaining sensitive user-specific responses.",
    "acceptanceChecks": [
      "shared cache does not store response",
      "browser does not reuse sensitive response"
    ],
    "explanation": "Private, no-store is appropriate for sensitive responses that should not be cached.",
    "difficulty": "FOUNDATION"
  },
  {
    "id": "code-149",
    "category": "System Design",
    "title": "Add a dead-letter queue",
    "starterCode": "// Failed message is retried forever.",
    "referenceSolution": "// After bounded attempts, move the message to a dead-letter queue with failure metadata.",
    "task": "Prevent poison messages from blocking a queue indefinitely.",
    "acceptanceChecks": [
      "retry count is bounded",
      "failed message can be inspected and replayed"
    ],
    "explanation": "Dead-letter queues isolate persistent failures for investigation.",
    "difficulty": "INTERMEDIATE"
  },
  {
    "id": "code-150",
    "category": "System Design",
    "title": "Make health endpoints cheap",
    "starterCode": "GET /health performs a full analytics query and external report.",
    "referenceSolution": "GET /health returns a lightweight process/dependency status with strict timeouts.",
    "task": "Keep health probes fast and predictable.",
    "acceptanceChecks": [
      "probe completes within budget",
      "probe does not create heavy load"
    ],
    "explanation": "Expensive health checks can amplify an outage by adding more load.",
    "difficulty": "ADVANCED"
  }
];
