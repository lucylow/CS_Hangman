import type { LabChallenge, LabProfile } from "./types";

const KEY = "cs-hangman-lab-v1";
export const emptyLabProfile = (): LabProfile => ({
  version: 1, completed: [], attempts: [], unlockedBadges: [], totalPoints: 0,
  bestStreak: 0, currentStreak: 0,
});
export function recordDecision(profile: LabProfile, challenge: LabChallenge, selectedIndex: number, total: number, durationMs = 0, completedAt = new Date().toISOString()): LabProfile {
  if (!Number.isInteger(selectedIndex) || selectedIndex < 0 || selectedIndex >= challenge.options.length) return profile;
  const correct = selectedIndex === challenge.correctIndex;
  const firstClear = correct && !profile.completed.includes(challenge.id);
  const points = firstClear ? challenge.points : 0;
  const completed = firstClear ? [...profile.completed, challenge.id] : [...profile.completed];
  const attempts = [...profile.attempts, { challengeId: challenge.id, selectedIndex, correct, points, durationMs, completedAt }];
  const currentStreak = correct ? profile.currentStreak + 1 : 0;
  const badges = new Set(profile.unlockedBadges);
  if (completed.length >= 1) badges.add("lab-first-proof");
  if (completed.length >= 10) badges.add("lab-double-digits");
  if (completed.length >= 25) badges.add("lab-quarter-century");
  if (total > 0 && completed.length >= total) badges.add("lab-complete");
  if (currentStreak >= 5) badges.add("lab-five-streak");
  if (attempts.filter((a) => a.correct).length >= 20) badges.add("lab-quality-engineer");
  return { ...profile, completed, attempts, unlockedBadges: [...badges], totalPoints: profile.totalPoints + points, currentStreak, bestStreak: Math.max(profile.bestStreak, currentStreak) };
}
export const labAccuracy = (profile: LabProfile) => profile.attempts.length ? Math.round(profile.attempts.filter((a) => a.correct).length / profile.attempts.length * 100) : 0;

export function loadLabProfile(): LabProfile {
  try {
    const raw: unknown = JSON.parse(localStorage.getItem(KEY) || "null");
    if (!raw || typeof raw !== "object") return emptyLabProfile();
    const p = raw as Record<string, unknown>;
    if (p["version"] !== 1) return emptyLabProfile();
    const strings = (value: unknown) => Array.isArray(value) ? [...new Set(value.filter((v): v is string => typeof v === "string"))] : [];
    const number = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? Math.max(0, value) : 0;
    const attempts = Array.isArray(p["attempts"]) ? p["attempts"].filter((a): a is LabProfile["attempts"][number] => a && typeof a === "object" && typeof a.challengeId === "string" && Number.isInteger(a.selectedIndex) && typeof a.correct === "boolean" && Number.isFinite(a.points) && a.points >= 0 && typeof a.completedAt === "string" && Number.isFinite(a.durationMs) && a.durationMs >= 0) : [];
    return { version: 1, completed: strings(p["completed"]), unlockedBadges: strings(p["unlockedBadges"]), attempts, totalPoints: number(p["totalPoints"]), bestStreak: number(p["bestStreak"]), currentStreak: number(p["currentStreak"]) };
  } catch { return emptyLabProfile(); }
}
export function saveLabProfile(profile: LabProfile) {
  try { localStorage.setItem(KEY, JSON.stringify(profile)); } catch { /* Restricted storage must not interrupt play. */ }
}