import { describe, expect, it, beforeEach } from "vitest";
import { labChallenges } from "./data/challenges";
import { codeExercises } from "./data/code-exercises";
import { emptyLabProfile, recordDecision, labAccuracy, loadLabProfile, saveLabProfile } from "./rules";

const auditedAnswers: Record<string, string> = {
  "lab-001": "It is available only within that function",
  "lab-002": "Purity",
  "lab-003": "A parameter",
  "lab-004": "Boolean",
  "lab-005": "Try/catch or try/except",
  "lab-006": "A base case",
  "lab-007": "Immutability",
  "lab-008": "Encapsulation",
  "lab-009": "Composition",
  "lab-010": "An empty-input test",
  "lab-011": "append()",
  "lab-012": "employees.get(42)",
  "lab-013": "[n*n for n in numbers]",
  "lab-014": "Generator",
  "lab-015": "with open(path) as file:",
  "lab-016": "Expected input and return types",
  "lab-017": "Isolate project dependencies",
  "lab-018": "KeyError",
  "lab-019": "Suspends until an awaitable completes",
  "lab-020": "unittest",
  "lab-021": "Equality without type coercion",
  "lab-022": "let",
  "lab-023": "Promise",
  "lab-024": "map()",
  "lab-025": "filter()",
  "lab-026": "Closure",
  "lab-027": "Event bubbling",
  "lab-028": "?.",
  "lab-029": "??",
  "lab-030": "export",
  "lab-031": "O(log n)",
  "lab-032": "O(n)",
  "lab-033": "Stability",
  "lab-034": "Breadth-first search",
  "lab-035": "Depth-first search",
  "lab-036": "Dynamic programming",
  "lab-037": "Memoization",
  "lab-038": "Min-heap",
  "lab-039": "Collision",
  "lab-040": "O(n log n)",
  "lab-041": "PRIMARY KEY",
  "lab-042": "FOREIGN KEY",
  "lab-043": "JOIN",
  "lab-044": "Atomicity",
  "lab-045": "Each affected index must also be maintained",
  "lab-046": "Reduce redundancy and update anomalies",
  "lab-047": "Isolation",
  "lab-048": "Migration",
  "lab-049": "Separate data from SQL syntax to prevent injection",
  "lab-050": "EXPLAIN",
  "lab-051": "DNS",
  "lab-052": "TCP",
  "lab-053": "UDP",
  "lab-054": "201",
  "lab-055": "Encryption and authenticated integrity",
  "lab-056": "Which IP bits identify the network portion",
  "lab-057": "Load balancer",
  "lab-058": "WebSocket",
  "lab-059": "Serve content from geographically distributed edge locations",
  "lab-060": "Rate limiting",
  "lab-061": "Least privilege",
  "lab-062": "SQL injection",
  "lab-063": "Cross-site scripting",
  "lab-064": "Multi-factor authentication",
  "lab-065": "Salted, slow password hashes",
  "lab-066": "Cross-site request forgery",
  "lab-067": "A managed secret store or protected environment configuration",
  "lab-068": "They remediate known vulnerabilities",
  "lab-069": "Identify assets, threats, trust boundaries, and mitigations",
  "lab-070": "Follow the incident plan and preserve evidence",
  "lab-071": "Training dataset",
  "lab-072": "Inference",
  "lab-073": "Overfitting",
  "lab-074": "Validation set",
  "lab-075": "Gradient descent",
  "lab-076": "A dense vector representation of an item",
  "lab-077": "Transformer",
  "lab-078": "External retrieval with generative model output",
  "lab-079": "Fraction of predicted positives that are true positives",
  "lab-080": "Data leakage",
  "lab-081": "Horizontal scaling",
  "lab-082": "Caching",
  "lab-083": "Message queue",
  "lab-084": "Idempotency",
  "lab-085": "Circuit breaker",
  "lab-086": "Sharding",
  "lab-087": "Replication",
  "lab-088": "Service level objective",
  "lab-089": "Backpressure",
  "lab-090": "Consistency and availability",
  "lab-091": "A recorded snapshot in repository history",
  "lab-092": "A movable reference to a commit",
  "lab-093": "Replays commits onto a new base",
  "lab-094": "It cannot automatically reconcile overlapping changes",
  "lab-095": "Builds and tests on proposed changes",
  "lab-096": "A produced package or binary from a build",
  "lab-097": "Application filesystem and runtime dependencies",
  "lab-098": "Rollback",
  "lab-099": "Logs, metrics, and traces",
  "lab-100": "Repeatable, reviewable infrastructure changes",
  "lab-101": "A static type system with compile-time checks",
  "lab-102": "useState",
  "lab-103": "To avoid stale listeners and resource leaks",
  "lab-104": "Help React match items between renders",
  "lab-105": "Through props",
  "lab-106": "Its value is driven by React state",
  "lab-107": "useMemo",
  "lab-108": "Error boundary",
  "lab-109": "main",
  "lab-110": "An accessible name",
  "lab-111": "A running program with its own execution context",
  "lab-112": "The process address space",
  "lab-113": "Deadlock",
  "lab-114": "Virtual memory",
  "lab-115": "It benefits from spatial locality and cache lines",
  "lab-116": "Byte order for multi-byte values",
  "lab-117": "System call",
  "lab-118": "Objects reachable from roots",
  "lab-119": "Race condition",
  "lab-120": "Mutex"
};

describe("V2 authored content", () => {
  it("preserves 120 unique scenarios across twelve disciplines", () => {
    expect(labChallenges).toHaveLength(120);
    expect(new Set(labChallenges.map((q) => q.id)).size).toBe(120);
    expect(new Set(labChallenges.map((q) => q.category)).size).toBe(12);
  });
  for (const q of labChallenges) it(`${q.id} uses its audited technical answer`, () => {
    expect(q.options).toHaveLength(4);
    expect(q.options[q.correctIndex]).toBe(auditedAnswers[q.id]);
  });
  it("preserves 150 unique code exercises with complete check expressions", () => {
    expect(codeExercises).toHaveLength(150);
    expect(new Set(codeExercises.map((e) => e.id)).size).toBe(150);
    for (const e of codeExercises) {
      expect(e.starterCode.length).toBeGreaterThan(0);
      expect(e.referenceSolution.length).toBeGreaterThan(0);
      expect(e.acceptanceChecks.length).toBeGreaterThan(0);
      for (const check of e.acceptanceChecks) {
        const opening = (check.match(/[([{]/g) || []).length;
        const closing = (check.match(/[)\]}]/g) || []).length;
        expect(opening, e.id).toBe(closing);
      }
    }
  });
});
describe("Lab rewards and offline progress", () => {
  beforeEach(() => localStorage.clear());
  const q = labChallenges[0];
  if (!q) throw new Error("Lab content missing");
  it("awards exactly 50 XP on the first correct foundation decision", () => {
    const next = recordDecision(emptyLabProfile(), q, q.correctIndex, 120);
    expect(next.totalPoints).toBe(50);
    expect(next.completed).toEqual(["lab-001"]);
    expect(next.unlockedBadges).toContain("lab-first-proof");
  });
  it("does not award duplicate XP on a cleared scenario", () => {
    const first = recordDecision(emptyLabProfile(), q, q.correctIndex, 120);
    const repeat = recordDecision(first, q, q.correctIndex, 120);
    expect(repeat.totalPoints).toBe(50);
    expect(repeat.attempts[1]?.points).toBe(0);
    expect(repeat.completed).toHaveLength(1);
    expect(repeat.currentStreak).toBe(2);
  });
  it("gives zero XP for an incorrect decision and resets only the current streak", () => {
    const first = recordDecision(emptyLabProfile(), q, q.correctIndex, 120);
    const failed = recordDecision(first, q, 1, 120);
    expect(failed.totalPoints).toBe(50);
    expect(failed.attempts[1]?.points).toBe(0);
    expect(failed.currentStreak).toBe(0);
    expect(failed.bestStreak).toBe(1);
    expect(labAccuracy(failed)).toBe(50);
  });
  it("rejects a decision outside the four available choices", () => {
    const p = emptyLabProfile();
    expect(recordDecision(p, q, 4, 120)).toBe(p);
  });
  it("awards the listed 75 XP and 100 XP for intermediate and advanced first clears", () => {
    const intermediate = labChallenges.find((item) => item.id === "lab-005");
    const advanced = labChallenges.find((item) => item.id === "lab-009");
    if (!intermediate || !advanced) throw new Error("Tiered challenges missing");
    const first = recordDecision(emptyLabProfile(), intermediate, intermediate.correctIndex, 120);
    expect(first.totalPoints).toBe(75);
    const second = recordDecision(first, advanced, advanced.correctIndex, 120);
    expect(second.totalPoints).toBe(175);
    expect(second.attempts[1]?.points).toBe(100);
  });
  for (const [threshold, badge] of [[10, "lab-double-digits"], [25, "lab-quarter-century"], [120, "lab-complete"]] as const) {
    it(`unlocks ${badge} only at ${threshold} unique clearances`, () => {
      let p = emptyLabProfile();
      for (const item of labChallenges.slice(0, threshold - 1)) p = recordDecision(p, item, item.correctIndex, 120);
      expect(p.unlockedBadges).not.toContain(badge);
      const last = labChallenges[threshold - 1];
      if (!last) throw new Error("Badge threshold challenge missing");
      p = recordDecision(p, last, last.correctIndex, 120);
      expect(p.unlockedBadges).toContain(badge);
    });
  }
  it("unlocks quality engineer at twenty correct decisions", () => {
    let p = emptyLabProfile();
    for (let i = 0; i < 19; i++) p = recordDecision(p, q, q.correctIndex, 120);
    expect(p.unlockedBadges).not.toContain("lab-quality-engineer");
    p = recordDecision(p, q, q.correctIndex, 120);
    expect(p.unlockedBadges).toContain("lab-quality-engineer");
  });
  it("unlocks the five-streak badge at five correct decisions", () => {
    let p = emptyLabProfile();
    for (let i = 0; i < 4; i++) p = recordDecision(p, q, q.correctIndex, 120);
    expect(p.unlockedBadges).not.toContain("lab-five-streak");
    p = recordDecision(p, q, q.correctIndex, 120);
    expect(p.unlockedBadges).toContain("lab-five-streak");
  });
  it("retains lab progress across reload without writing to the original save", () => {
    localStorage.setItem("cs-hangman-save-v1", '{"xp":350}');
    const p = recordDecision(emptyLabProfile(), q, q.correctIndex, 120);
    saveLabProfile(p);
    expect(loadLabProfile()).toEqual(p);
    saveLabProfile(emptyLabProfile());
    expect(loadLabProfile().totalPoints).toBe(0);
    expect(localStorage.getItem("cs-hangman-save-v1")).toBe('{"xp":350}');
  });
  it("falls back safely for malformed or unsupported-version progress", () => {
    localStorage.setItem("cs-hangman-lab-v1", "broken");
    expect(loadLabProfile()).toEqual(emptyLabProfile());
    localStorage.setItem("cs-hangman-lab-v1", '{"version":2,"totalPoints":900}');
    expect(loadLabProfile().totalPoints).toBe(0);
  });
});
