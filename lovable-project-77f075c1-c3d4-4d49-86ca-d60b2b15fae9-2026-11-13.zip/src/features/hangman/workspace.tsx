import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity,
  ArrowUpRight,
  Award,
  BrainCircuit,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  CircleHelp,
  Code2,
  Command,
  Database,
  FileCheck2,
  FolderGit2,
  Gauge,
  GraduationCap,
  Lock,
  LayoutDashboard,
  Menu,
  Network,
  Play,
  RotateCcw,
  Search,
  Shield,
  Sparkles,
  Terminal,
  Trophy,
  X,
  Zap,
  FlaskConical,
  BookOpen,
} from "lucide-react";
import { questions } from "./data/questions";
import { initialSave, loadSave, masked, persistSave, reward, solved, win, lose } from "./lib/game";
import type { Category, Question, Save } from "./types";
import { Outlet, useLocation, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import portraitsAsset from "@/assets/executive-portraits.jpg.asset.json";
const portraits = portraitsAsset.url;
type View = "overview" | "play" | "departments" | "receipts" | "profile" | "lab" | "workshop";
const cats: { name: Category; icon: any; color: string; code: string }[] = [
  { name: "Programming", icon: Code2, color: "primary", code: "CORE" },
  { name: "Python", icon: Terminal, color: "primary", code: "PY" },
  { name: "JavaScript", icon: Command, color: "primary", code: "JS" },
  { name: "Algorithms", icon: BrainCircuit, color: "primary", code: "DSA" },
  { name: "Databases", icon: Database, color: "primary", code: "SQL" },
  { name: "Networking", icon: Network, color: "primary", code: "NET" },
  { name: "Cybersecurity", icon: Shield, color: "primary", code: "SEC" },
  { name: "AI / ML", icon: BrainCircuit, color: "primary", code: "AI" },
  { name: "System Design", icon: Gauge, color: "primary", code: "SYS" },
  { name: "Git", icon: FolderGit2, color: "primary", code: "VCS" },
];
const bosses = [
  {
    name: "THE NEPOTISM KING",
    role: "Director of Strategic Buzzwords",
    weak: "Algorithms & fundamentals",
  },
  { name: "THE CREDIT THIEF", role: "VP of Executive Storytelling", weak: "Git & attribution" },
  {
    name: "THE PROMOTION GATEKEEPER",
    role: "Head of Career Obstruction",
    weak: "Evidence-based evaluation",
  },
  {
    name: "THE ARCHITECT",
    role: "Chief Infrastructure Illusionist",
    weak: "System design & security",
  },
];
const nav = [
  { id: "overview" as View, label: "Command Center", icon: LayoutDashboard },
  { id: "play" as View, label: "Challenge Terminal", icon: Terminal },
  { id: "lab" as View, label: "Engineering Lab", icon: FlaskConical },
  { id: "workshop" as View, label: "Code Workshop", icon: BookOpen },
  { id: "departments" as View, label: "Departments", icon: BriefcaseBusiness },
  { id: "receipts" as View, label: "Technical Receipts", icon: FileCheck2 },
  { id: "profile" as View, label: "Engineer Profile", icon: Award },
];
function useGameState() {
  const [save, setSave] = useState<Save>(initialSave);
  const [ready, setReady] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const paths = {
    overview: "/",
    play: "/challenge",
    lab: "/lab",
    workshop: "/workshop",
    departments: "/departments",
    receipts: "/receipts",
    profile: "/profile",
  } as const;
  const view: View =
    location.pathname === "/lab"
      ? "lab"
      : location.pathname === "/workshop"
        ? "workshop"
        : location.pathname === "/challenge"
      ? "play"
      : location.pathname === "/departments"
        ? "departments"
        : location.pathname === "/receipts"
          ? "receipts"
          : location.pathname === "/profile"
            ? "profile"
            : "overview";
  function setView(v: View) {
    void navigate({ to: paths[v] });
  }
  const [mobile, setMobile] = useState(false);
  const [q, setQ] = useState<Question | null>(null);
  const [cat, setCat] = useState<Category | "ALL">("ALL");
  const [guesses, setGuesses] = useState<string[]>([]);
  const [miss, setMiss] = useState(0);
  const [hint, setHint] = useState(false);
  const [hintOpen, setHintOpen] = useState(false);
  const [result, setResult] = useState<"win" | "loss" | null>(null);
  const [search, setSearch] = useState("");
  const [name, setName] = useState(save.name);
  const [reset, setReset] = useState(false);
  useEffect(() => {
    const stored = loadSave();
    setSave(stored);
    setName(stored.name);
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready) persistSave(save);
  }, [save, ready]);
  const level = Math.floor(save.xp / 500) + 1;
  const accuracy = save.attempts ? Math.round((save.correct / save.attempts) * 100) : 0;
  const display = q ? masked(q.answer, guesses) : [];
  const receipts = useMemo(
    () =>
      save.receipts.filter((r) =>
        (r.title + " " + r.category).toLowerCase().includes(search.toLowerCase()),
      ),
    [save.receipts, search],
  );
  function start(c: Category | "ALL" = "ALL") {
    setCat(c);
    const pool = questions.filter(
      (x) => (c === "ALL" || x.category === c) && !save.solved.includes(x.id),
    );
    const list = pool.length ? pool : questions.filter((x) => c === "ALL" || x.category === c);
    const nextQuestion = list[Math.floor(Math.random() * list.length)];
    if (!nextQuestion) return;
    setQ(nextQuestion);
    setGuesses([]);
    setMiss(0);
    setHint(false);
    setHintOpen(false);
    setResult(null);
    setView("play");
  }
  function guess(l: string) {
    if (!q || result || guesses.includes(l)) return;
    const next = [...guesses, l];
    setGuesses(next);
    if (!q.answer.toUpperCase().includes(l)) {
      const m = miss + 1;
      setMiss(m);
      if (m >= 6) finishLoss();
    } else if (solved(q.answer, next)) {
      setSave((s) => win(s, q, reward(q, miss, hint)));
      setResult("win");
    }
  }
  function finishLoss() {
    if (result) return;
    setSave((s) => lose(s));
    setResult("loss");
  }
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.ctrlKey ||
        e.metaKey ||
        e.altKey
      )
        return;
      const l = e.key.toUpperCase();
      if (/^[A-Z0-9=]$/.test(l) && view === "play") {
        e.preventDefault();
        guess(l);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [q, result, guesses, miss, hint, view]);
  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=".split("");
  return {
    save,
    setSave,
    view,
    setView,
    mobile,
    setMobile,
    q,
    setQ,
    cat,
    guesses,
    miss,
    hint,
    setHint,
    hintOpen,
    setHintOpen,
    result,
    search,
    setSearch,
    name,
    setName,
    reset,
    setReset,
    level,
    accuracy,
    display,
    receipts,
    start,
    guess,
    letters,
    finishLoss,
  };
}
const GameContext = createContext<ReturnType<typeof useGameState> | null>(null);
function useGame() {
  const game = useContext(GameContext);
  if (!game) throw new Error("Game provider missing");
  return game;
}
export function GameProvider({ children }: { children: ReactNode }) {
  const game = useGameState();
  return <GameContext.Provider value={game}>{children}</GameContext.Provider>;
}
export function GameWorkspace() {
  const [helpOpen, setHelpOpen] = useState(false);
  const {
    save,
    setSave,
    view,
    setView,
    mobile,
    setMobile,
    q,
    setQ,
    cat,
    guesses,
    miss,
    hint,
    setHint,
    hintOpen,
    setHintOpen,
    result,
    search,
    setSearch,
    name,
    setName,
    reset,
    setReset,
    level,
    accuracy,
    display,
    receipts,
    start,
    guess,
    letters,
    finishLoss,
  } = useGame();
  return (
    <div className="shell">
      <div className="scan" />
      <aside className={`sidebar ${mobile ? "open" : ""}`}>
        <div className="brand">
          <div className="mark">
            CS<span>_</span>
          </div>
          <div>
            <b>CS_HANGMAN</b>
            <small>THE CORPORATE GATEKEEPER</small>
          </div>
          <Button
            variant="game"
            aria-label="Close navigation"
            className="close mobile"
            onClick={() => setMobile(false)}
          >
            <X size={17} />
          </Button>
        </div>
        <div className="org">
          <i /> VANTAGE SYSTEMS <small>INTERNAL</small>
        </div>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {nav.map((n) => (
            <Button
              variant="game"
              key={n.id}
              className={view === n.id ? "selected" : ""}
              aria-current={view === n.id ? "page" : undefined}
              onClick={() => {
                setView(n.id);
                setMobile(false);
              }}
            >
              <n.icon size={17} />
              {n.label}
              {n.id === "receipts" && save.receipts.length > 0 && <b>{save.receipts.length}</b>}
            </Button>
          ))}
        </nav>
        <div className="side-bottom">
          <div className="case">
            <small>
              <Lock size={12} /> CONFIDENTIAL CASE
            </small>
            <b>
              OPERATION: OPEN
              <br />
              THE ORG CHART
            </b>
            <div className="track">
              <i style={{ width: Math.min(100, save.receipts.length * 10) + "%" }} />
            </div>
            <small>{save.receipts.length}/10 RECEIPTS</small>
          </div>
          <div className="mini-user">
            <div>{name.slice(0, 2)}</div>
            <section>
              <b>{name}</b>
              <small>LEVEL {level} ENGINEER</small>
            </section>
            <Button
              variant="game"
              title="Engineer profile"
              aria-label="Engineer profile"
              onClick={() => setView("profile")}
            >
              <ArrowUpRight size={15} />
            </Button>
          </div>
          <footer>BUILD 01.0.4　•　LOCAL SAVE ACTIVE</footer>
        </div>
      </aside>
      {mobile && <div className="scrim" onClick={() => setMobile(false)} />}
      <main>
        <header>
          <div className="crumb">
            <Button
              variant="game"
              aria-label="Open navigation"
              className="mobile menu"
              onClick={() => setMobile(true)}
            >
              <Menu size={18} />
            </Button>
            <span className="crumb-org">VANTAGE SYSTEMS　›　</span>
            <span>{nav.find((n) => n.id === view)?.label.toUpperCase()}</span>
          </div>
          <div className="head-right">
            <span className="nominal">
              <i /> SYSTEM NOMINAL
            </span>
            <b>
              <Zap size={14} />
              {save.xp.toLocaleString()} XP
            </b>
            <Button variant="game" title="Help" aria-label="Help" onClick={() => setHelpOpen(true)}>
              <CircleHelp size={17} />
            </Button>
          </div>
        </header>
        <div className="content">
          <Outlet />
        </div>
      </main>
      <nav className="mobile-dock" aria-label="Main navigation">
        {nav.map((n) => (
          <Button
            key={n.id}
            variant="game"
            aria-label={n.label}
            aria-current={view === n.id ? "page" : undefined}
            className={view === n.id ? "selected" : ""}
            onClick={() => {
              setView(n.id);
              setMobile(false);
            }}
          >
            <n.icon size={20} />
            <span>
              {n.id === "overview"
                ? "Home"
                : n.id === "play"
                  ? "Challenge"
                  : n.id === "receipts"
                    ? "Receipts"
                    : n.id === "profile"
                      ? "Profile"
                      : n.id === "lab"
                        ? "Lab"
                        : n.id === "workshop"
                          ? "Code"
                          : "Explore"}
            </span>
          </Button>
        ))}
      </nav>
      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent className="game-dialog">
          <small className="eyebrow">VANTAGE // PERSONNEL SUPPORT</small>
          <DialogTitle>Technical merit. On record.</DialogTitle>
          <DialogDescription>
            Earn experience through technical examinations. Your record stays in this browser.
          </DialogDescription>
          <div className="support-metrics">
            <div>
              <Zap />
              <b>{save.xp} XP</b>
              <small>EXPERIENCE</small>
            </div>
            <div>
              <FileCheck2 />
              <b>{save.receipts.length}</b>
              <small>RECEIPTS</small>
            </div>
          </div>
          <Button
            variant="game"
            className="primary"
            onClick={() => {
              setHelpOpen(false);
              setView("departments");
            }}
          >
            EXPLORE DEPARTMENTS <ArrowUpRight size={16} />
          </Button>
        </DialogContent>
      </Dialog>
      <Dialog open={reset} onOpenChange={setReset}>
        <DialogContent className="game-dialog">
          <small>DESTRUCTIVE PERSONNEL ACTION</small>
          <DialogTitle>Erase your record?</DialogTitle>
          <DialogDescription>
            This resets local XP, receipts, achievements, and challenge history in this browser.
          </DialogDescription>
          <div className="dialog-actions">
            <Button variant="game" className="secondary" onClick={() => setReset(false)}>
              CANCEL
            </Button>
            <Button
              variant="game"
              className="danger"
              onClick={() => {
                setSave({ ...initialSave, name: name || "ENGINEER_01" });
                setQ(null);
                setReset(false);
                setView("overview");
              }}
            >
              CONFIRM RESET
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
export function GameScreen() {
  const {
    save,
    setSave,
    view,
    setView,
    mobile,
    setMobile,
    q,
    setQ,
    cat,
    guesses,
    miss,
    hint,
    setHint,
    hintOpen,
    setHintOpen,
    result,
    search,
    setSearch,
    name,
    setName,
    reset,
    setReset,
    level,
    accuracy,
    display,
    receipts,
    start,
    guess,
    letters,
    finishLoss,
  } = useGame();
  return (
    <AnimatePresence mode="wait">
      {view === "overview" && (
        <motion.div
          key="home"
          className="page"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
        >
          <div className="eyebrow">
            <i /> EMPLOYEE PORTAL / PERFORMANCE REVIEW CYCLE 09
          </div>
          <div className="hero">
            <div>
              <h1>
                Good morning,
                <br />
                <em>{name}.</em>
              </h1>
              <p>Your promotion was denied. Again. Fortunately, the codebase is a witness.</p>
            </div>
            <div className="stamp">
              MERIT<strong>≠</strong>MANAGEMENT
            </div>
          </div>
          <div className="alert">
            <Activity size={18} />
            <section>
              <b>HR NOTICE // PROMOTION REVIEW REJECTED</b>
              <p>
                Reason: “Not a culture fit.” Technical evaluation: <strong>NOT CONDUCTED.</strong>
              </p>
            </section>
            <small>REF #VG-09-441</small>
          </div>
          <div className="section-title">
            <div>
              <small>YOUR CURRENT RECORD</small>
              <h2>Performance, quantified.</h2>
            </div>
            <label>LAST SYNC: JUST NOW</label>
          </div>
          <div className="stats">
            <Stat
              icon={Zap}
              label="TOTAL EXPERIENCE"
              value={save.xp.toLocaleString()}
              suffix="XP"
              note={`LEVEL ${level} // ENGINEER`}
            />
            <Stat
              icon={Gauge}
              label="CHALLENGE ACCURACY"
              value={String(accuracy)}
              suffix="%"
              note={`${save.correct} VERIFIED / ${save.attempts} ATTEMPTS`}
            />
            <Stat
              icon={Trophy}
              label="CURRENT STREAK"
              value={String(save.streak)}
              suffix="×"
              note={`BEST: ${save.bestStreak}`}
            />
            <Stat
              icon={FileCheck2}
              label="TECHNICAL RECEIPTS"
              value={String(save.receipts.length)}
              suffix=""
              note="PROOF > PROMISES"
            />
          </div>
          <div className="mode-selector" aria-label="Game modes">
            <Button variant="game" className="mode-button" onClick={() => start("ALL")}><Terminal size={21} /><section><b>Classic Hangman</b><small>40 TECHNICAL CHALLENGES</small></section><ArrowUpRight size={16} /></Button>
            <Button variant="game" className="mode-button" onClick={() => setView("lab")}><FlaskConical size={21} /><section><b>Engineering Lab</b><small>120 PRACTICAL SCENARIOS</small></section><ArrowUpRight size={16} /></Button>
            <Button variant="game" className="mode-button" onClick={() => setView("workshop")}><BookOpen size={21} /><section><b>Code Workshop</b><small>150 REVIEW EXERCISES</small></section><ArrowUpRight size={16} /></Button>
          </div>
          <div className="dash-grid">
            <section className="panel mission">
              <div className="panel-title">
                <div>
                  <small>PRIORITY ASSIGNMENT // 001</small>
                  <h3>Prove them wrong.</h3>
                </div>
                <span className="tag">ACTIVE MISSION</span>
              </div>
              <div className="mission-art">
                <div className="ghost">
                  root@vantage:~$
                  <br />
                  sudo verify_merit --all
                  <br />
                  <b>[ ACCESS DENIED ]</b>
                  <br />
                  reason: manager discretion
                </div>
                <div className="mission-copy">
                  <small>01 / 04</small>
                  <h2>
                    THE OFFICE OF
                    <br />
                    <em>BROKEN PROMISES</em>
                  </h2>
                  <p>Recover the missing engineering record. Start with the fundamentals.</p>
                  <Button variant="game" className="primary" onClick={() => start("ALL")}>
                    <Play size={14} fill="currentColor" /> BEGIN CHALLENGE{" "}
                    <ArrowUpRight size={14} />
                  </Button>
                </div>
              </div>
              <div className="mission-foot">
                <span>
                  <Lock size={12} /> NEXT: SERVER ROOM
                </span>
                <span>REWARD: 100–190 XP</span>
              </div>
            </section>
            <section className="panel career">
              <div className="panel-title">
                <div>
                  <small>CAREER TRACK</small>
                  <h3>Engineering level</h3>
                </div>
                <GraduationCap />
              </div>
              <div className="level">
                <strong>{String(level).padStart(2, "0")}</strong>
                <section>
                  <b>
                    {level < 3
                      ? "Junior Engineer"
                      : level < 6
                        ? "Software Engineer"
                        : level < 10
                          ? "Senior Engineer"
                          : "Principal Engineer"}
                  </b>
                  <small>LEVEL {level} // VANTAGE SYSTEMS</small>
                </section>
              </div>
              <div className="track">
                <i style={{ width: (save.xp % 500) / 5 + "%" }} />
              </div>
              <div className="xp-label">
                <span>{save.xp % 500} / 500 XP</span>
                <span>LEVEL {level + 1}</span>
              </div>
              <hr />
              <div className="metric">
                <span>MISSIONS COMPLETED</span>
                <b>{String(save.correct).padStart(2, "0")}</b>
              </div>
              <div className="metric">
                <span>ACHIEVEMENTS UNLOCKED</span>
                <b>{String(save.achievements.length).padStart(2, "0")}</b>
              </div>
              <Button variant="game" className="link" onClick={() => setView("profile")}>
                VIEW ENGINEER PROFILE <ArrowUpRight size={14} />
              </Button>
            </section>
          </div>
          <div className="section-title boss-title">
            <div>
              <small>THE MANAGEMENT TEAM</small>
              <h2>People standing in your way.</h2>
            </div>
            <Button variant="game" className="link" onClick={() => setView("departments")}>
              VIEW ALL DEPARTMENTS <ArrowUpRight size={14} />
            </Button>
          </div>
          <div className="boss-grid">
            {bosses.slice(0, 3).map((b, i) => (
              <Boss
                key={b.name}
                boss={b}
                index={i}
                onClick={() => start(i === 1 ? "Git" : i === 2 ? "Programming" : "Algorithms")}
              />
            ))}
          </div>
          <div className="page-foot">
            VANTAGE SYSTEMS © 2026 <span>REMEMBER: DOCUMENT EVERYTHING.</span>
            <span>YOU ARE NOT THE BUG.</span>
          </div>
        </motion.div>
      )}
      {view === "play" && (
        <motion.div
          key="play"
          className="page"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
        >
          <div className="eyebrow">
            <i /> LIVE EXAMINATION / TECHNICAL CHALLENGE
          </div>
          <div className="play-head">
            <div>
              <h1>
                Challenge <em>terminal.</em>
              </h1>
              <p>A little knowledge goes a long way. A little incompetence goes to the board.</p>
            </div>
            <Button variant="game" className="secondary" onClick={() => start(cat)}>
              <RotateCcw size={14} /> NEW CHALLENGE
            </Button>
          </div>
          <div className="play-grid">
            <section className="panel challenge">
              {!q ? (
                <div className="empty">
                  <Terminal size={30} />
                  <small>NO ACTIVE SESSION</small>
                  <h2>Choose your battlefield.</h2>
                  <p>Select a technical discipline to begin your examination.</p>
                  <div className="pick">
                    {cats.map((c) => (
                      <Button variant="game" onClick={() => start(c.name)} key={c.name}>
                        <c.icon size={15} />
                        {c.name}
                        <ChevronRight size={13} />
                      </Button>
                    ))}
                  </div>
                  <Button variant="game" className="primary wide" onClick={() => start("ALL")}>
                    <Play size={14} /> RANDOM CHALLENGE
                  </Button>
                </div>
              ) : (
                <>
                  <div className="challenge-top">
                    <div>
                      <small>BOSS BATTLE // {q.id.toUpperCase()}</small>
                      <div className="tags">
                        <span>{q.category}</span>
                        <span className={q.difficulty === "HARD" ? "red" : ""}>{q.difficulty}</span>
                      </div>
                    </div>
                    <div className="attempts">
                      <small>ATTEMPTS REMAINING</small>
                      <b>
                        {6 - miss}
                        <i>/ 6</i>
                      </b>
                    </div>
                  </div>
                  <div className="question">
                    <small>
                      <CircleHelp size={14} /> TECHNICAL QUESTION
                    </small>
                    <h2>{q.prompt}</h2>
                    <div className="answer" aria-label="Answer progress">
                      {display.map((c, i) => (
                        <span
                          className={q.answer[i] === " " ? "answer-space" : c ? "revealed" : ""}
                          key={i}
                        >
                          {c || " "}
                        </span>
                      ))}
                    </div>
                    <div className="answer-meta">
                      <span>{q.answer.replace(/[^A-Z0-9=]/gi, "").length} CHARACTERS</span>
                      <span>REWARD: {reward(q, miss, hint)} XP</span>
                    </div>
                  </div>
                  <div className="hang-row">
                    <EvidenceMeter miss={miss} />
                    <section>
                      <b className="await" role="status">
                        {result === "win"
                          ? "CHALLENGE VERIFIED"
                          : result === "loss"
                            ? "SESSION FAILED"
                            : "● AWAITING INPUT"}
                      </b>
                      <p>
                        {result === "win"
                          ? "The evidence speaks for itself. Receipt added to your record."
                          : result === "loss"
                            ? `Correct answer: ${q.answer}`
                            : "Select a character to reveal the technical term."}
                      </p>
                      {!result && (
                        <Button
                          variant="game"
                          className="hint"
                          aria-expanded={hintOpen}
                          onClick={() => {
                            setHintOpen(!hintOpen);
                            setHint(true);
                          }}
                        >
                          <Sparkles size={14} />
                          {hintOpen ? "HIDE HINT" : "REQUEST HINT"}{" "}
                          <small>{hint ? "USED" : "-25 XP"}</small>
                        </Button>
                      )}
                      {hintOpen && !result && <div className="hint-box">{q.hint}</div>}
                    </section>
                  </div>
                  <div className="keyboard" aria-label="Character keyboard">
                    {["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM", "0123456789="].map((row) => (
                      <div className="keyboard-row" key={row}>
                        {row.split("").map((l) => (
                          <Button
                            variant="game"
                            key={l}
                            disabled={guesses.includes(l) || !!result}
                            className={
                              guesses.includes(l)
                                ? q.answer.toUpperCase().includes(l)
                                  ? "correct"
                                  : "wrong"
                                : ""
                            }
                            onClick={() => guess(l)}
                          >
                            {l}
                          </Button>
                        ))}
                      </div>
                    ))}
                  </div>
                  {result && (
                    <div className={`result ${result}`} role="status">
                      <div>{result === "win" ? <Check /> : <X />}</div>
                      <section>
                        <b>
                          {result === "win"
                            ? "TECHNICAL MERIT ESTABLISHED"
                            : "MANAGEMENT CALLS THIS A LEARNING OPPORTUNITY"}
                        </b>
                        <p>
                          {result === "win" ? `+${reward(q, miss, hint)} XP awarded. ` : ""}
                          {q.explanation}
                        </p>
                      </section>
                      <Button variant="game" className="primary" onClick={() => start(cat)}>
                        CONTINUE <ChevronRight size={14} />
                      </Button>
                    </div>
                  )}
                  <div className="challenge-foot">
                    <span>
                      <Lock size={12} /> LOCAL SESSION // NO EXECUTABLE CODE RUNS
                    </span>
                    <Button variant="game" disabled={!!result} onClick={() => finishLoss()}>
                      FORFEIT CHALLENGE
                    </Button>
                  </div>
                </>
              )}
            </section>
            <aside>
              <div className="manager">
                <small>OPPOSITION // CURRENT MANAGER</small>
                <div
                  className={`manager-art executive-${q?.boss === "THE CREDIT THIEF" ? 1 : q?.boss === "THE NEPOTISM KING" || !q ? 0 : 2}`}
                >
                  <img src={portraits} alt="Executive opposition" />
                  <b>ERROR 403</b>
                </div>
                <h3>{q?.boss || "THE NEPOTISM KING"}</h3>
                <p>“I don't need to understand the code. I have people for that.”</p>
                <div className="meter">
                  <span>ARGUMENT INTEGRITY</span>
                  <b>{Math.max(0, 100 - miss * 16)}%</b>
                </div>
                <div className="track">
                  <i style={{ width: Math.max(0, 100 - miss * 16) + "%" }} />
                </div>
              </div>
              <div className="rules">
                <small>EXAMINATION PROTOCOL</small>
                {[
                  "Guess the technical term, one character at a time.",
                  "Six incorrect guesses end the examination.",
                  "Correct answers earn XP and a permanent Technical Receipt.",
                  "Hints reduce the reward. Your call.",
                ].map((x, i) => (
                  <div key={x}>
                    <b>0{i + 1}</b>
                    <p>{x}</p>
                  </div>
                ))}
              </div>
            </aside>
          </div>
        </motion.div>
      )}
      {view === "departments" && (
        <motion.div
          key="departments"
          className="page"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
        >
          <div className="eyebrow">
            <i /> VANTAGE HQ / DEPARTMENT DIRECTORY
          </div>
          <h1>
            Choose your <em>department.</em>
          </h1>
          <p className="sub">Ten disciplines. Four managers. One deeply flawed org chart.</p>
          <div className="departments">
            {cats.map((c, i) => (
              <Button variant="game" className="dept" key={c.name} onClick={() => start(c.name)}>
                <div className={`discipline tone-${i}`}>
                  <c.icon size={20} />
                </div>
                <small>
                  {c.code} / DEPT-{String(i + 1).padStart(2, "0")}
                </small>
                <h3>{c.name}</h3>
                <p>
                  {questions.filter((x) => x.category === c.name).length} field examinations
                  available
                </p>
                <footer>
                  ENTER DEPARTMENT <ArrowUpRight size={14} />
                </footer>
              </Button>
            ))}
          </div>
          <div className="section-title">
            <div>
              <small>EXECUTIVE FLOOR</small>
              <h2>Management directory.</h2>
            </div>
          </div>
          <div className="boss-grid">
            {bosses.map((b, i) => (
              <Boss
                key={b.name}
                boss={b}
                index={i}
                onClick={() => start(i === 1 ? "Git" : i === 2 ? "Programming" : "Algorithms")}
              />
            ))}
          </div>
        </motion.div>
      )}
      {view === "receipts" && (
        <motion.div
          key="receipts"
          className="page"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
        >
          <div className="eyebrow">
            <i /> EVIDENCE VAULT / VERIFIED CONTRIBUTIONS
          </div>
          <div className="play-head">
            <div>
              <h1>
                Technical <em>receipts.</em>
              </h1>
              <p>Management has opinions. You have a paper trail.</p>
            </div>
            <div className="receipt-count">
              <b>{String(save.receipts.length).padStart(2, "0")}</b>
              <small>VERIFIED RECORDS</small>
            </div>
          </div>
          <div className="receipt-toolbar">
            <div className="search">
              <Search size={15} />
              <input
                aria-label="Search receipts"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search evidence, category..."
              />
            </div>
            <small>SORTED: NEWEST FIRST</small>
          </div>
          {receipts.length ? (
            <div className="receipt-list">
              {receipts.map((r, i) => (
                <div className="receipt-row" key={r.id}>
                  <span>{String(i + 1).padStart(3, "0")}</span>
                  <FileCheck2 size={18} />
                  <section>
                    <b>{r.title}</b>
                    <small>
                      {r.category} / {r.detail}
                    </small>
                  </section>
                  <time>{new Date(r.date).toLocaleDateString()}</time>
                  <strong>+{r.points} XP</strong>
                  <label>
                    <Check size={12} /> VERIFIED
                  </label>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-receipts">
              <FileCheck2 size={30} />
              <h3>No evidence. Yet.</h3>
              <p>Complete a technical challenge to create your first verified receipt.</p>
              <Button variant="game" className="primary" onClick={() => start("ALL")}>
                <Play size={14} /> START EXAMINATION
              </Button>
            </div>
          )}
          <p className="disclaimer">
            <Lock size={13} /> Records are stored locally in this browser. They are game
            achievements, not externally verified employment credentials.
          </p>
        </motion.div>
      )}
      {view === "profile" && (
        <motion.div
          key="profile"
          className="page"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
        >
          <div className="eyebrow">
            <i /> PERSONNEL FILE / ENGINEERING RECORD
          </div>
          <h1>
            Engineer <em>profile.</em>
          </h1>
          <div className="profile">
            <section className="panel person">
              <div className="person-avatar">{name.slice(0, 2)}</div>
              <small>VANTAGE PERSONNEL ID / {String(level).padStart(3, "0")}</small>
              <h2>{name}</h2>
              <p>
                {level < 3
                  ? "Junior Engineer"
                  : level < 6
                    ? "Software Engineer"
                    : level < 10
                      ? "Senior Engineer"
                      : "Principal Engineer"}
              </p>
              <hr />
              <label>CALLSIGN / DISPLAY NAME</label>
              <input
                aria-label="Callsign"
                value={name}
                maxLength={20}
                onChange={(e) => setName(e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, ""))}
                onBlur={() => {
                  const value = name || "ENGINEER_01";
                  setName(value);
                  setSave((s) => ({ ...s, name: value }));
                }}
              />
              <hr />
              {[
                ["TOTAL XP", save.xp],
                ["BEST STREAK", save.bestStreak],
                ["ACCURACY", accuracy + "%"],
                ["RECEIPTS", save.receipts.length],
              ].map((x) => (
                <div className="profile-stat" key={x[0]}>
                  <span>{x[0]}</span>
                  <b>{x[1]}</b>
                </div>
              ))}
            </section>
            <section>
              <div className="panel achievements">
                <small>MERIT BADGES</small>
                <h3>Achievements.</h3>
                {[
                  {
                    id: "first",
                    name: "First Proof",
                    desc: "Complete your first technical examination.",
                  },
                  { id: "streak", name: "Consistency", desc: "Reach a three-challenge streak." },
                  { id: "receipts", name: "Paper Trail", desc: "Collect five Technical Receipts." },
                ].map((a) => (
                  <div
                    className={`achievement ${save.achievements.includes(a.id) ? "unlocked" : ""}`}
                    key={a.id}
                  >
                    <Award size={18} />
                    <section>
                      <b>{a.name}</b>
                      <small>{a.desc}</small>
                    </section>
                    <strong>{save.achievements.includes(a.id) ? "UNLOCKED" : "LOCKED"}</strong>
                  </div>
                ))}
              </div>
              <div className="panel reset-panel">
                <small>PERSONNEL ACTIONS</small>
                <h3>Local save data.</h3>
                <p>
                  Your progress is stored in this browser using localStorage. Clearing browser data
                  removes this record.
                </p>
                <Button variant="game" className="danger" onClick={() => setReset(true)}>
                  <RotateCcw size={14} /> RESET ALL PROGRESS
                </Button>
              </div>
            </section>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  suffix,
  note,
}: {
  icon: any;
  label: string;
  value: string;
  suffix: string;
  note: string;
}) {
  return (
    <div className="stat">
      <div>
        <Icon size={17} />
      </div>
      <small>{label}</small>
      <strong>
        {value}
        <i>{suffix}</i>
      </strong>
      <label>{note}</label>
    </div>
  );
}
function Boss({ boss, index, onClick }: { boss: any; index: number; onClick: () => void }) {
  return (
    <Button variant="game" className="boss-card" onClick={onClick}>
      <div className="boss-top">
        <small>{index === 0 ? "● ACTIVE THREAT" : "◌ CLASSIFIED"}</small>
        <span>EXEC-0{index + 1}</span>
      </div>
      <div className={`portrait p${index}`}>
        <img src={portraits} alt={boss.name} loading="lazy" />
        <b>V / G</b>
      </div>
      <h3>{boss.name}</h3>
      <p>{boss.role}</p>
      <div className="weak">
        <small>KNOWN WEAKNESS</small>
        <b>{boss.weak}</b>
      </div>
      <footer>
        INITIATE REVIEW <ArrowUpRight size={14} />
      </footer>
    </Button>
  );
}
function EvidenceMeter({ miss }: { miss: number }) {
  return (
    <div className="evidence-meter" role="img" aria-label={`${miss} incorrect guesses`}>
      <FileCheck2 size={42} />
      <div className="evidence-bars">
        {Array.from({ length: 6 }, (_, i) => (
          <i key={i} className={i < miss ? "depleted" : ""} />
        ))}
      </div>
      <small>EVIDENCE INTEGRITY</small>
    </div>
  );
}
