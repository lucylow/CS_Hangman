export type Category =
  | "Programming"
  | "Python"
  | "JavaScript"
  | "Algorithms"
  | "Databases"
  | "Networking"
  | "Cybersecurity"
  | "AI / ML"
  | "System Design"
  | "Git";
export interface Question {
  id: string;
  category: Category;
  difficulty: "EASY" | "MEDIUM" | "HARD";
  prompt: string;
  answer: string;
  hint: string;
  explanation: string;
  points: number;
  boss: string;
}
export interface Receipt {
  id: string;
  title: string;
  category: string;
  date: string;
  points: number;
  detail: string;
}
export interface Save {
  xp: number;
  score: number;
  streak: number;
  bestStreak: number;
  solved: string[];
  receipts: Receipt[];
  achievements: string[];
  attempts: number;
  correct: number;
  name: string;
}
