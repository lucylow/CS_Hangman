import { describe, expect, it } from "vitest";
import { initialSave, lose, masked, reward, solved, win } from "./game";
import { questions } from "../data/questions";

describe("Imported game rules", () => {
  const q = questions[0];
  if (!q) throw new Error("Question bank is empty");
  it("keeps all 40 authored questions and ten disciplines", () => {
    expect(questions).toHaveLength(40);
    expect(new Set(questions.map((q) => q.category)).size).toBe(10);
    expect(new Set(questions.map((q) => q.id)).size).toBe(40);
  });
  it("deducts 12 points per miss and 25 for a hint with a 20 point floor", () => {
    expect(reward(q, 2, true)).toBe(51);
    expect(reward(q, 6, true)).toBe(20);
  });
  it("requires a guess for the strict equality answer", () => {
    expect(solved("===", [])).toBe(false);
    expect(masked("===", [])).toEqual(["", "", ""]);
    expect(solved("===", ["="])).toBe(true);
  });
  it("records a loss as an attempt and resets the streak", () => {
    expect(lose({ ...initialSave, streak: 3, attempts: 4 })).toMatchObject({
      attempts: 5,
      correct: 0,
      streak: 0,
    });
  });
  it("awards XP and evidence without mutating prior achievements", () => {
    const previous = { ...initialSave, achievements: [] };
    const next = win(previous, q, 100);
    expect(next.xp).toBe(100);
    expect(next.receipts).toHaveLength(1);
    expect(next.correct).toBe(1);
    expect(next.achievements).toContain("first");
    expect(previous.achievements).toEqual([]);
  });
});
