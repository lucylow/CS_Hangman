import type { Question, Save, Receipt } from "../types";
export const initialSave: Save = {
  xp: 0,
  score: 0,
  streak: 0,
  bestStreak: 0,
  solved: [],
  receipts: [],
  achievements: [],
  attempts: 0,
  correct: 0,
  name: "ENGINEER_01",
};
const KEY = "cs-hangman-save-v1";
export function loadSave(): Save {
  try {
    return { ...initialSave, ...JSON.parse(localStorage.getItem(KEY) || "{}") };
  } catch {
    return initialSave;
  }
}
export function persistSave(s: Save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {}
}
export function masked(answer: string, guesses: string[]) {
  return answer
    .split("")
    .map((c) =>
      /[A-Z0-9=]/i.test(c) ? (guesses.includes(c.toUpperCase()) ? c.toUpperCase() : "") : c,
    );
}
export function solved(answer: string, guesses: string[]) {
  return answer.split("").every((c) => !/[A-Z0-9=]/i.test(c) || guesses.includes(c.toUpperCase()));
}
export function reward(q: Question, misses: number, hint: boolean) {
  return Math.max(20, q.points - misses * 12 - (hint ? 25 : 0));
}
export function win(s: Save, q: Question, points: number): Save {
  const r: Receipt = {
    id: crypto.randomUUID(),
    title: q.answer,
    category: q.category,
    date: new Date().toISOString(),
    points,
    detail: q.explanation,
  };
  const n = {
    ...s,
    achievements: [...s.achievements],
    xp: s.xp + points,
    score: s.score + points,
    streak: s.streak + 1,
    bestStreak: Math.max(s.bestStreak, s.streak + 1),
    solved: [...s.solved, q.id],
    receipts: [r, ...s.receipts],
    attempts: s.attempts + 1,
    correct: s.correct + 1,
  };
  if (!n.achievements.includes("first")) n.achievements.push("first");
  if (n.streak >= 3 && !n.achievements.includes("streak")) n.achievements.push("streak");
  if (n.receipts.length >= 5 && !n.achievements.includes("receipts"))
    n.achievements.push("receipts");
  return n;
}

export function lose(s: Save): Save {
  return { ...s, attempts: s.attempts + 1, streak: 0 };
}
